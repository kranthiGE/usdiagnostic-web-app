#region  Page Level Comments

/*******************************************************************************************
/*File Name	      :			DContact.cs
 *Project Name    :			USD 1.0
 *Object          :			DAL
 *Purpose         :			
 *Author          :			Padma A
 *Date            :			29-5-2006 
 *ModuleName      :			USD
 *This file is provided as part of Zaxis-USD project.
 *Copyright � 2004-07, Zaxis-USD Technologies, All rights reserved
 * ************************************ Revision History************************************
 *
 *  Date            Done by             Method             Change Description

*******************************************************************************************/

#endregion

#region  NameSpace Declaration

//System NameSpaces

using System;
using System.Data;
using System.Collections;

//Zaxis-USD NameSpaces
using Zaxis.DataAccess;

#endregion

namespace Zaxis.USD.DAL
{
	public class DContact : DALBase 
	{

		#region Constructor 

		/// <summary>
		///default constructor 
		/// </summary>
		public DContact()
		{
		}
		#endregion

		#region Create

		/// <summary>
		/// Inserts new record into database
		/// </summary>
		/// <param name="ProcedureID"></param>
		/// <param name="Name"></param>
		/// <param name="ProcedureCodeID"></param>
		/// <returns></returns>
		/// 
		public string Create(string ContactID, string FirstName, string MiddleName, string LastName, string Sex, string Address1, string Address2, string City, string State, string Zip, string Country, string HomePhone, string WorkPhone, string CellPhone, string Fax, string EMail, string URL, string Buffer01, string Buffer02, string Buffer03, string Buffer04, string Buffer05, string IsActive, IDbTransaction iTrans)
		{
			string strQuery = null;
			strQuery = @" INSERT INTO Contact(ContactID,FirstName,MiddleName,LastName,Sex,Address1,Address2,City,State,Zip,Country,HomePhone,WorkPhone,CellPhone,Fax,EMail,URL,Buffer01,Buffer02,Buffer03,Buffer04,Buffer05,IsActive)
			 VALUES('" + ContactID +" ', '" + FirstName +" ', '" + MiddleName +" ', '" + LastName +" ', '" + Sex +" ', '" + Address1 +" ', '" + Address2 +" ', '" + City +" ', '" + State +" ', '" + Zip +" ', '" + Country +" ', '" + HomePhone +" ', '" + WorkPhone +" ', '" + CellPhone +" ', '" + Fax +" ', '" + EMail +" ', '" + URL +" ', '" + Buffer01 +" ', '" + Buffer02 +" ', '" + Buffer03 +" ', '" + Buffer04 +" ', '" + Buffer05 +" ', '"+IsActive+"')";
			return dbInstance.ExecuteNonQuery(iTrans, CommandType.Text, strQuery).ToString();
		}


		/// <summary>
		/// 
		/// </summary>
		/// <param name="dsFormData"></param>
		/// <param name="strTableName"></param>
		/// <param name="iTrans"></param>
		/// <param name="ht"></param>
		/// <returns></returns>
		public string Create(DataSet dsFormData, string strTableName, IDbTransaction iTrans,Hashtable ht)
		{
			int iRowCount=0;
			int iRowCnt=0;
			if (dbInstance == null)
				throw new Exception("No Connection");

			DataRow drFormData; 
			try 
			{ 
				iRowCount = dsFormData.Tables[strTableName].Rows.Count; 
				for(iRowCnt = 0; iRowCnt < iRowCount; iRowCnt++) 
				{ 
					drFormData = dsFormData.Tables[strTableName].Rows[iRowCnt]; 
					Create(drFormData["ContactID"].ToString(), drFormData["FirstName"].ToString(), drFormData["MiddleName"].ToString(), drFormData["LastName"].ToString(), drFormData["Sex"].ToString(), drFormData["Address1"].ToString(), drFormData["Address2"].ToString(), drFormData["City"].ToString(), drFormData["State"].ToString(), drFormData["Zip"].ToString(), drFormData["Country"].ToString(), drFormData["HomePhone"].ToString(), drFormData["WorkPhone"].ToString(), drFormData["CellPhone"].ToString(), drFormData["Fax"].ToString(), drFormData["EMail"].ToString(), drFormData["URL"].ToString(), drFormData["Buffer01"].ToString(), drFormData["Buffer02"].ToString(), drFormData["Buffer03"].ToString(), drFormData["Buffer04"].ToString(), drFormData["Buffer05"].ToString(), drFormData["IsActive"].ToString(), iTrans);
				}
			} 
			catch(Zaxis.Definitions.ZaxisException ex) 
			{
				ex.RowNumber = iRowCnt + 1; 
				throw ex; 
			} 
			return "";
		}

		#endregion

		#region Update

		/// <summary>
		/// Updates the exsting record from Procedure Table
		/// </summary>
		/// <param name="ProcedureID"></param>
		/// <param name="Name"></param>
		/// <param name="ProcedureCodeID"></param>
		/// <returns>True/False</returns>
		private string Update (string ContactID, string FirstName, string MiddleName, string LastName, string Sex, string Address1, string Address2, string City, string State, string Zip, string Country, string HomePhone, string WorkPhone, string CellPhone, string Fax, string EMail, string URL, string Buffer01, string Buffer02, string Buffer03, string Buffer04, string Buffer05, string IsActive, IDbTransaction iTrans)
		{
			string strQuery = "";
			strQuery = "Update Contact SET FirstName = '"+FirstName+"',MiddleName = '"+MiddleName+"',LastName = '"+LastName+"',Sex = '"+Sex+"',Address1 = '"+Address1+"',Address2 = '"+Address2+"',City = '"+City+"',State = '"+State+"',Zip = '"+Zip+"',Country = '"+Country+"',HomePhone = '"+HomePhone+"',WorkPhone = '"+WorkPhone+"',CellPhone = '"+CellPhone+"',Fax = '"+Fax+"',EMail = '"+EMail+"',URL = '"+URL+"',Buffer01 = '"+Buffer01+"',Buffer02 = '"+Buffer02+"',Buffer03 = '"+Buffer03+"',Buffer04 = '"+Buffer04+"',Buffer05 = '"+Buffer05+"',IsActive = '"+IsActive+"'" + " where ContactID = '"+ContactID+"'";
			if(dbInstance.ExecuteNonQuery(iTrans, CommandType.Text, strQuery) < 1) 
			{ 
				Zaxis.Definitions.ZaxisException ex = new Zaxis.Definitions.ZaxisException(); 
				throw ex; 
			} 
			return ""; 
		} 

		/// <summary>
		/// 
		/// </summary>
		/// <param name="dsFormData"></param>
		/// <param name="strTableName"></param>
		/// <param name="iTrans"></param>
		/// <param name="ht"></param>
		/// <returns></returns>
		public string Update(DataSet dsFormData, string strTableName, IDbTransaction iTrans,Hashtable ht)
		{
			int iRowCount = 0;
			int iRowCnt = 0;
			if (dbInstance == null)
				throw new Exception("No Connection");
			DataRow drFormData;
			try
			{
				iRowCount = dsFormData.Tables[strTableName].Rows.Count;
				for(iRowCnt = 0; iRowCnt < iRowCount; iRowCnt++)
				{
					drFormData = dsFormData.Tables[strTableName].Rows[iRowCnt];
//					string Status = drFormData["RowStatus"].ToString();
//					switch(Status)
//					{
//						case "Insert":
//							Create(drFormData["ContactID"].ToString(), drFormData["FirstName"].ToString(), drFormData["MiddleName"].ToString(), drFormData["LastName"].ToString(), drFormData["Sex"].ToString(), drFormData["Address1"].ToString(), drFormData["Address2"].ToString(), drFormData["City"].ToString(), drFormData["State"].ToString(), drFormData["Zip"].ToString(), drFormData["Country"].ToString(), drFormData["HomePhone"].ToString(), drFormData["WorkPhone"].ToString(), drFormData["CellPhone"].ToString(), drFormData["Fax"].ToString(), drFormData["EMail"].ToString(), drFormData["URL"].ToString(), drFormData["Buffer01"].ToString(), drFormData["Buffer02"].ToString(), drFormData["Buffer03"].ToString(), drFormData["Buffer04"].ToString(), drFormData["Buffer05"].ToString(), drFormData["IsActive"].ToString(), iTrans);
//							break;
//						case "Update":
							Update(drFormData["ContactID"].ToString(), drFormData["FirstName"].ToString(), drFormData["MiddleName"].ToString(), drFormData["LastName"].ToString(), drFormData["Sex"].ToString(), drFormData["Address1"].ToString(), drFormData["Address2"].ToString(), drFormData["City"].ToString(), drFormData["State"].ToString(), drFormData["Zip"].ToString(), drFormData["Country"].ToString(), drFormData["HomePhone"].ToString(), drFormData["WorkPhone"].ToString(), drFormData["CellPhone"].ToString(), drFormData["Fax"].ToString(), drFormData["EMail"].ToString(), drFormData["URL"].ToString(), drFormData["Buffer01"].ToString(), drFormData["Buffer02"].ToString(), drFormData["Buffer03"].ToString(), drFormData["Buffer04"].ToString(), drFormData["Buffer05"].ToString(), drFormData["IsActive"].ToString(), iTrans);
//							break;
//						case "Delete":
//							Delete(drFormData["ContactID"].ToString(),iTrans);
//							break;
//					}
				}
			}
			catch(Zaxis.Definitions.ZaxisException ex)
			{
				ex.RowNumber = iRowCnt + 1;
				throw ex;
			}
			return "";
		}
		#endregion

		#region Delete
		/// <summary>
		/// 
		/// </summary>
		/// <param name="ContactID"></param>
		/// <param name="iTrans"></param>
		/// <returns></returns>
		private string Delete(string ContactID,IDbTransaction iTrans)
		{
			string strQuery = "";
			strQuery=" Update  Contact set IsActive = 0 WHERE  ContactID = '"+ ContactID +"'";
			if(dbInstance.ExecuteNonQuery(iTrans, CommandType.Text, strQuery) < 1) 
			{ 
				Zaxis.Definitions.ZaxisException ex = new Zaxis.Definitions.ZaxisException(); 
				throw ex; 
			} 
			return ""; 
		} 

		/// <summary>
		/// 
		/// </summary>
		/// <param name="dsFormData"></param>
		/// <param name="strTableName"></param>
		/// <param name="iTrans"></param>
		/// <returns></returns>
		public string Delete(DataSet dsFormData, string strTableName, IDbTransaction iTrans)
		{
			int iRowCnt=0;
			if (dbInstance == null)
				throw new Exception("No Connection");

			DataRow drFormData; 
			try 
			{ 
				int iRowCount = dsFormData.Tables[strTableName].Rows.Count; 
				for(iRowCnt = 0; iRowCnt < iRowCount; iRowCnt++) 
				{ 	
					drFormData = dsFormData.Tables[strTableName].Rows[iRowCnt]; 
					Delete(drFormData["ContactID"].ToString(),iTrans);
				}
			} 
			catch(Zaxis.Definitions.ZaxisException ex) 
			{
				ex.RowNumber = 1; 
				throw ex; 
			} 
			return "";
		}
		#endregion

	}
}
