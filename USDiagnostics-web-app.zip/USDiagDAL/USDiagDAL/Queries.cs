

using System;
using System;
using System.Xml;


namespace Zaxis.USD.DAL
{
	/// <summary>
	/// Summary description for Queries.
	/// </summary>
	public class Queries
	{
		public Queries()
		{
		}

		public static string GetQuery(string queryname, string wherestring)
		{
			string strQuery = string.Empty;
			switch(queryname)
			{

				// Security
				case "PermissionCheck":
					strQuery = "SELECT dbo.fUserPermissionCheck ('"+ GetNodeXml("UserID", wherestring) +"', '"+ GetNodeXml("PermissionID", wherestring) +"')";
					break;
				
				case "ModifyPermission":
					strQuery = "select top 1 modifyrecord from userinfo where userid = '"+ wherestring + "'";
					break;

				// Login 
				
				case "Login":
					strQuery = "SELECT UserID, (select isNull(MiddleName, '') + ' ' + isNull(FirstName, '') + ' ' + isNull(LastName, '') from Contact c where c.ContactID = u.ContactID) Name FROM UserInfo u where IsActive=1 and LoginID = '" + GetNodeXml("UserID", wherestring)  + "' and Password = '" + GetNodeXml("Password", wherestring) + "'";
					break;

				// Order Dispatch
				case "Technician":
					//strQuery = "SELECT (SELECT UserID from UserInfo p where p.ContactID = c.ContactID) UserID, c.ContactID, (isNull(MiddleName, '') + ' ' + isNull(FirstName, '') + ' ' + isNull(LastName, '')) Name FROM Contact c where c.IsActive = 1 and ContactID in (select ContactID from UserInfo)";
					strQuery = "select UserID, ContactID, (select isNull(c.MiddleName, '') + ' ' + isNull(c.FirstName, '') + ' ' + isNull(c.LastName, '') from contact c where c.ContactID = u.ContactID) Name from UserInfo u";

					break;

				case "TechnicianBind":
					//strQuery = "SELECT (SELECT UserID from UserInfo p where p.ContactID = c.ContactID) UserID, c.ContactID, (isNull(MiddleName, '') + ' ' + isNull(FirstName, '') + ' ' + isNull(LastName, '')) Name FROM Contact c where c.IsActive = 1 and ContactID in (select ContactID from UserInfo)";
					strQuery = "select UserID, ContactID, (select isNull(c.MiddleName, '') + ' ' + isNull(c.FirstName, '') + ' ' + isNull(c.LastName, '') from contact c where c.ContactID = u.ContactID) Name from UserInfo u where UserID in(select UserID from user_role where roleid='5') ";

					break;
				
				case "OrderDispatch":
					strQuery = @"SELECT   Orders.OrderID AS [OrderId], PatientID, TechnicianID, (select firstname from contact c where c.contactid = (select u.contactid from userinfo u where u.UserId = TechnicianID))  Name,  Orders.OrderNo AS [Order No], Procedures.Name AS [Test],
								(SELECT decode FROM code WHERE  code.codeid = Patient_Procedure.priorityid AND code.typeid = 3) AS [Priority], CONVERT(VARCHAR(10), Patient_Procedure.DueDate,101)  AS [Due Date],  CONVERT(VARCHAR(10), Patient_Procedure.DueDate,108)AS [Test Time],
								(SELECT codeid FROM code WHERE code.codeid = Patient_Procedure.StatusId AND code.typeid = 7) AS StatusId, (SELECT decode FROM code WHERE  code.codeid = Patient_Procedure.StatusId AND code.typeid = 7) AS [Status],Patient_Procedure.ProcedureID as [ProcedureID]
								FROM Patient_Procedure 
						INNER JOIN Orders ON Patient_Procedure.OrderID = Orders.OrderID 
						INNER JOIN Procedures ON Patient_Procedure.ProcedureID = Procedures.ProcedureID where Patient_Procedure.IsActive = 1 and Orders.IsActive = 1 and Orders.OrderID  = '"+ wherestring +"'";// and  Orders.OrderID = 'o1'";
					//strQuery = @"SELECT top 10 [ProcedureID] as [Order No], [Name] AS [Test], [ProcedureCodeID] AS Priority, getdate() AS [Due Date], '' AS  [Test Time] FROM [USDiag].[dbo].[Procedures]";//,'[Buffer04]' AS Status
					break;

				case "OrderDispatchTechnician":
					strQuery = @"SELECT   Orders.OrderID AS [OrderId], PatientID, TechnicianID, (select firstname from contact c where c.contactid = (select u.contactid from userinfo u where u.UserId = TechnicianID))  Name,  Orders.OrderNo AS [Order No], Procedures.Name AS [Test],
								(SELECT decode FROM code WHERE  code.codeid = Patient_Procedure.priorityid AND code.typeid = 3) AS [Priority], CONVERT(VARCHAR(10), Patient_Procedure.DueDate,101)  AS [Due Date],  CONVERT(VARCHAR(10), Patient_Procedure.DueDate,108)AS [Test Time],
								(SELECT codeid FROM code WHERE code.codeid = Patient_Procedure.StatusId AND code.typeid = 7) AS StatusId, (SELECT decode FROM code WHERE  code.codeid = Patient_Procedure.StatusId AND code.typeid = 7) AS [Status],Patient_Procedure.ProcedureID as [ProcedureID]
								FROM Patient_Procedure 
						INNER JOIN Orders ON Patient_Procedure.OrderID = Orders.OrderID 
						INNER JOIN Procedures ON Patient_Procedure.ProcedureID = Procedures.ProcedureID where Patient_Procedure.IsActive = 1 and Orders.IsActive=1 and Orders.OrderID = '"+ GetNodeXml("OrderID", wherestring) +"' and Patient_Procedure.TechnicianID = '"+ GetNodeXml("UserID", wherestring) +"'";// and  Orders.OrderID = 'o1'";
					//strQuery = @"SELECT top 10 [ProcedureID] as [Order No], [Name] AS [Test], [ProcedureCodeID] AS Priority, getdate() AS [Due Date], '' AS  [Test Time] FROM [USDiag].[dbo].[Procedures]";//,'[Buffer04]' AS Status
					break;

				case "OrderDispatchTechnicianAdmin":
					strQuery = @"SELECT   Orders.OrderID AS [OrderId], PatientID, TechnicianID, (select firstname from contact c where c.contactid = (select u.contactid from userinfo u where u.UserId = TechnicianID))  Name,  Orders.OrderNo AS [Order No], Procedures.Name AS [Test],
								(SELECT decode FROM code WHERE  code.codeid = Patient_Procedure.priorityid AND code.typeid = 3) AS [Priority], CONVERT(VARCHAR(10), Patient_Procedure.DueDate,101)  AS [Due Date],  CONVERT(VARCHAR(10), Patient_Procedure.DueDate,108)AS [Test Time],
								(SELECT codeid FROM code WHERE code.codeid = Patient_Procedure.StatusId AND code.typeid = 7) AS StatusId, (SELECT decode FROM code WHERE  code.codeid = Patient_Procedure.StatusId AND code.typeid = 7) AS [Status],Patient_Procedure.ProcedureID as [ProcedureID]
								FROM Patient_Procedure 
						INNER JOIN Orders ON Patient_Procedure.OrderID = Orders.OrderID 
						INNER JOIN Procedures ON Patient_Procedure.ProcedureID = Procedures.ProcedureID where Patient_Procedure.IsActive = 1 and Orders.IsActive=1 and Orders.OrderID = '"+ GetNodeXml("OrderID", wherestring) +"'";// and  Orders.OrderID = 'o1'";
					//strQuery = @"SELECT top 10 [ProcedureID] as [Order No], [Name] AS [Test], [ProcedureCodeID] AS Priority, getdate() AS [Due Date], '' AS  [Test Time] FROM [USDiag].[dbo].[Procedures]";//,'[Buffer04]' AS Status
					break;


				case "CodeType":
					strQuery = "select * from code where  isactive = 1 and TypeID = " + wherestring;
					break;

				case "DispatchStructure":
					strQuery = "select * from Patient_Procedure where  1=2";
					break;
					
				// Procedure Queries

				case "ProcedureStructure":
					strQuery = "SELECT ProcedureID, Name, ProcedureCodeID, Buffer01, Buffer02, Buffer03, Buffer04, Buffer05, IsActive FROM Procedures where 1=2";
					break;

//				case "ProcedureGridBind":
//					strQuery = "SELECT ProcedureID, ProcedureCodeID, (select Decode from code c where c.CodeId = p.ProcedureCodeID) Decode, Name, Active = case IsActive when 0 then 'Deleted' when 1 then 'Active' end from Procedures p WHERE p.IsActive = 1 order by p.ProcedureCodeID";
//					break;

				case "ProcedureGridBind":
					strQuery = "SELECT ProcedureID, ProcedureCodeID, Buffer01 Code, (select Decode from code c where c.CodeId = p.ProcedureCodeID) Decode, Name, Active = case IsActive when 0 then 'Deleted' when 1 then 'Active' end from Procedures p WHERE p.IsActive = 1 order by p.ProcedureCodeID";
					break;

				case "ProcedureType":
					strQuery = "SELECT CodeId, Decode FROM Code WHERE TypeID = 4 and IsActive = 1";
					break;
			
				case "UniqueProcedure":
					strQuery = "SELECT count(*) FROM " + GetNodeXml("TableName", wherestring) + " WHERE "+ GetNodeXml("ColumnName", wherestring) +" =  '"+ GetNodeXml("Name", wherestring) +"'";// and IsActive = 1";
					break;

				case "UniqueProcedureUpdate":
					strQuery = "SELECT count(*) FROM " + GetNodeXml("TableName", wherestring) + "  WHERE  "+ GetNodeXml("ColumnName", wherestring) +" = '"+ GetNodeXml("Name", wherestring) +"' and "+ GetNodeXml("PKColumn", wherestring) +" != '"+ GetNodeXml("ProcedureID", wherestring)  +"'"; //
					break;

				// Account Queries
				case "Roles":
					strQuery = "Select RoleID, Name from  Role where IsActive = 1";
					break;
				case "Codes":
					strQuery = "select CodeID, Decode from code where TypeID =" +  wherestring;
					break;

				case "AccountGridBind":
					strQuery = "Select UserID, LoginID, (select isNull(MiddleName, '') + ' ' + isNull(FirstName, '') + ' ' + isNull(LastName, '') from Contact c where c.ContactID=u.ContactID) FullName, (select isActive from Contact c where c.ContactID=u.ContactID) isActive, Modify = case ModifyRecord when 1 then 'No' when 0 then 'Yes' end from UserInfo u where isActive='1'";
					break;

				case "AccountBind":
					strQuery = "Select * from UserInfo where UserID = '" + wherestring + "' and IsActive = 1 ;Select * from Contact where ContactId = (Select u.ContactID from UserInfo u where u.UserID =  '" + wherestring + "') and IsActive = 1;SELECT ur.RoleID, ur.UserId, (SELECT Name FROM Role r Where r.RoleID = ur.RoleID) Name from user_role ur where UserID = '" + wherestring + "' and ur.IsActive=1";
					break;		
	
				case "AccountSearch":
					strQuery = "Select UserID, LoginID, ( isNull(c.MiddleName, '') + ' ' + isNull(c.FirstName, '') + ' ' + isNull(c.LastName, '')) FullName, (select IsActive = case isActive when 1 then 'Yes' when 0 then 'No' end from Contact c where c.ContactID=u.ContactID) isActive, Modify = case ModifyRecord when 1 then 'No' when 0 then 'Yes' end   from UserInfo u inner join Contact c  on u.ContactID = c.ContactID and u.isActive='1' " + wherestring;
					break;		
			
				// Order

				case "OrderGridBind":
					strQuery = "SELECT o.OrderID, o.OrderNo, (select isNull(c.MiddleName, '') + ' ' + isNull(c.FirstName, '') + ' ' + isNull(c.LastName, '') from Contact c where c.ContactID = p.ContactID) PatientName,  CONVERT(VARCHAR(10), o.OrderDate,101) OrderDate, p.SSN from Orders o, Patient p where p.PatientID = (select top 1 pp.PatientID from Patient_Procedure pp where pp.OrderID = o.OrderID and pp.IsActive = 1) and p.IsActive = 1";
					break;

				case "OrderSearchBind":
					strQuery = "SELECT distinct o.OrderID, o.OrderNo,  (select isNull(c.MiddleName, '') + ' ' + isNull(c.FirstName, '') + ' ' + isNull(c.LastName, '') from Contact c where c.ContactID = p.ContactID) PatientName, CONVERT(VARCHAR(10), o.OrderDate,101) OrderDate, c.FirstName, /*pp.TestDate,*/ p.SSN FROM Patient_Procedure pp INNER JOIN Patient p ON pp.PatientId=p.PatientId INNER JOIN Contact c ON p.ContactId=c.ContactId LEFT OUTER JOIN Orders o ON pp.OrderId=o.OrderId where pp.IsActive = 1 and o.IsActive = 1 and p.IsActive = 1 " + wherestring;
					break;
	
				case "OrderSearchPatient":
					//strQuery = "SELECT distinct o.OrderID, o.OrderNo,  (select isNull(c.MiddleName, '') + ' ' + isNull(c.FirstName, '') + ' ' + isNull(c.LastName, '') from Contact c where c.ContactID = p.ContactID) PatientName, CONVERT(VARCHAR(10), o.OrderDate,101) OrderDate, c.FirstName,  /*pp.TestDate,*/ p.SSN, p.MedicareNo, p.MedicaidNO, case c.sex when 0 then 'Male' when 1 then 'Female' end Sex, c.city FROM Patient_Procedure pp INNER JOIN Patient p ON pp.PatientId=p.PatientId INNER JOIN Contact c ON p.ContactId=c.ContactId LEFT OUTER JOIN Orders o ON pp.OrderId=o.OrderId where pp.IsActive = 1 and o.IsActive = 1 and p.IsActive = 1 " + wherestring;
					strQuery = "SELECT distinct p.PatientID, (select isNull(c.MiddleName, '') + ' ' + isNull(c.FirstName, '') + ' ' + isNull(c.LastName, '') from Contact c where c.ContactID = p.ContactID) PatientName,  c.FirstName,  /*pp.TestDate,*/ p.SSN, p.MedicareNo, p.MedicaidNO, case c.sex when 0 then 'Male' when 1 then 'Female' end Sex, c.city FROM Patient_Procedure pp INNER JOIN Patient p ON pp.PatientId=p.PatientId INNER JOIN Contact c ON p.ContactId=c.ContactId LEFT OUTER JOIN Orders o ON pp.OrderId=o.OrderId where pp.IsActive = 1  and p.IsActive = 1 "+ wherestring;
					break;

				case "OrderSearchOrder":
					strQuery = "SELECT distinct o.OrderID, o.OrderNo,  (select isNull(c.MiddleName, '') + ' ' + isNull(c.FirstName, '') + ' ' + isNull(c.LastName, '') from Contact c where c.ContactID = p.ContactID) PatientName, CONVERT(VARCHAR(10), o.OrderDate,101) OrderDate, c.FirstName,  /*pp.TestDate,*/ p.SSN, p.MedicareNo, p.MedicaidNO, c.sex, c.city FROM Patient_Procedure pp INNER JOIN Patient p ON pp.PatientId=p.PatientId INNER JOIN Contact c ON p.ContactId=c.ContactId LEFT OUTER JOIN Orders o ON pp.OrderId=o.OrderId where pp.IsActive = 1 and o.IsActive = 1 and p.IsActive = 1 " + wherestring;
					break;
				/*case "GetOrder":
				strQuery = "SELECT o.OrderID, o.OrderNo, CONVERT(VARCHAR(10), o.OrderDate, 101) OrderDate, o.Physician, o.OrderingNurse, o.SourceContactID, o.ContactTypeID, o.Signature, o.Diagnosis, o.CompanyID, o.BranchID, o.IsActive, c.FirstName, c.LastName, c.MiddleName, c.Zip, c.HomePhone, c.Fax  FROM Orders o, Contact c where  o.SourceContactID = c.ContactID and o.IsActive = 1 and o.OrderID = '" + wherestring + "'; SELECT     PatientID, c.FirstName, c.LastName, c.MiddleName, c.Sex, c.Address1, c.HomePhone, SSN, CONVERT(VARCHAR(10), DOB, 101) DOB, MedicareNo, MedicaidNO, RoomNo, p.ContactID, PatientInsuranceCode, InsuranceContactID, CompanyID, BranchID, p.IsActive FROM  Patient p, Contact c where  p.ContactID = c.ContactID and p.IsActive=1 and PatientID =  (SELECT top 1 PatientID from Patient_Procedure where OrderID = '" + wherestring + "' ); SELECT  ContactID, FirstName, MiddleName, LastName, Address1, Country, HomePhone, WorkPhone, CellPhone, Fax, EMail, City, Zip, IsActive FROM Contact  where ContactID = (SELECT InsuranceContactID FROM Patient where PatientID = (SELECT top 1 PatientID from Patient_Procedure where IsActive = 1 and OrderID = '" + wherestring + "')); SELECT     PatientID, ProcedureID, OrderID, TechnicianID, DueDate, TestDate, PriorityID, ZoneID, Comments, StatusID, OrderTyp, IsActive FROM Patient_Procedure Where IsActive = 1 and OrderID = '" + wherestring + "'";
				break;*/

				case "GetOrder":
					strQuery = "SELECT o.OrderID, o.OrderNo, CONVERT(VARCHAR(10), o.OrderDate, 101) OrderDate, o.Physician, o.OrderingNurse, o.SourceContactID, o.ContactTypeID, o.Signature, o.Diagnosis, o.CompanyID, o.BranchID, o.IsActive, c.FirstName, c.LastName, c.MiddleName, c.Address1, c.City, c.State, c.Zip, c.HomePhone, c.Fax, o.Buffer01  FROM Orders o, Contact c where  o.SourceContactID = c.ContactID and o.IsActive = 1 and o.OrderID = '" + wherestring + "'; SELECT     PatientID, c.FirstName, c.LastName, c.MiddleName, c.Sex, c.Address1, c.City, c.State, c.Zip, c.HomePhone, SSN, CONVERT(VARCHAR(10), DOB, 101) DOB, MedicareNo, MedicaidNO, RoomNo, p.ContactID, PatientInsuranceCode, InsuranceContactID, CompanyID, BranchID, p.IsActive, p.Comments FROM  Patient p, Contact c where  p.ContactID = c.ContactID and p.IsActive=1 and PatientID =  (SELECT top 1 PatientID from Patient_Order where OrderID = '" + wherestring + "' );SELECT  ContactID, FirstName, MiddleName, LastName, Address1, Country, HomePhone, WorkPhone, CellPhone, Fax, EMail, Address1, Address2, City, State, Zip, IsActive, Buffer01 FROM Contact  where ContactID = (SELECT InsuranceContactID FROM Patient where PatientID = (SELECT top 1 PatientID from Patient_Order where IsActive = 1 and OrderID = '" + wherestring + "')); SELECT     PatientID, ProcedureID, OrderID, TechnicianID, DueDate, TestDate, PriorityID, ZoneID, Comments, StatusID, OrderTyp, IsActive, Buffer01 FROM Patient_Procedure Where IsActive = 1 and OrderID = '" + wherestring + "'";
					break;				
//				case "OrderStructure":
//					strQuery = "SELECT OrderID, OrderDate, Physician, OrderingNurse, SourceContactID, ContactTypeID, Signature, Diagnosis, CompanyID, BranchID, IsActive, OrderNo FROM Orders where 1 = 2;SELECT     ContactID, FirstName, MiddleName, LastName, Sex, Address1, Address2, City, State, Zip, Country, HomePhone, WorkPhone, CellPhone, Fax, EMail, URL, IsActive FROM  Contact where 1 = 2;SELECT     PatientID, SSN, DOB, MedicareNo, MedicaidNO, RoomNo, ContactID, PatientInsuranceCode, InsuranceContactID, CompanyID, BranchID, IsActive FROM  Patient where 1 = 2;SELECT     PatientID, ProcedureID, OrderID, TechnicianID, DueDate, TestDate, PriorityID, ZoneID, Comments, StatusID, OrderTyp, IsActive FROM Patient_Procedure where 1 = 2";
//					break;

				case "OrderStructure":
					strQuery = "SELECT * FROM Orders where 1 = 2;SELECT * FROM  Contact where 1 = 2;SELECT * FROM  Patient where 1 = 2;SELECT * FROM Patient_Procedure where 1 = 2";
					break;
					
					
				// User Info

				case "UserInfo":
					strQuery = "select * from userinfo";
					break;
				case "UserInfoStructure":
					strQuery = "select * from userinfo where 1=2; select * from contact where 1=2; select * from user_role where 1=2";
					break;


				// Dispatch Controls
				case "DispatchGridBind1":
					strQuery = "SELECT op.PatientID, op.OrderID, op.ProcedureID, (select isNull(MiddleName, '') + ' ' + isNull(FirstName, '') + ' ' + isNull(LastName, '') from contact c where c.ContactID = (select p.ContactID from Patient p where p.PatientID = op.PatientID)) PatientName, (select o.orderdate from orders o where o.OrderID = op.OrderID) OrderDate, (SELECT ord.OrderNo from orders ord where ord.Orderid = op.OrderID) OrderNo  from Patient_Procedure op where op.StatusID = " + wherestring;
					break;

				case "DispatchGridBind2":
					strQuery = "SELECT cd.DeCode, c.ContactId, c.FirstName, COUNT(pp.OrderId) CurrentOrders, COUNT(CASE pp.OrderTyp WHEN 2 THEN pp.OrderId ELSE NULL END) ReportedOrders FROM UserInfo ui INNER JOIN Contact c ON ui.ContactId=c.ContactId	LEFT OUTER JOIN Patient_Procedure pp ON ui.UserId=pp.TechnicianId LEFT OUTER JOIN Procedures p ON pp.ProcedureId=p.ProcedureId LEFT OUTER JOIN Code cd ON p.ProcedureCodeId=cd.CodeId GROUP BY cd.DeCode, c.ContactId, c.FirstName";
					break;


					//Technician Queries 
				case "TechStatus":
					/*strQuery = @"SELECT Orders.OrderID as [Order No],( Contact.FirstName+' '+Contact.MiddleName+' '+ Contact.LastName) as [Patient Name], 
									Code.Decode as [Priority], Patient_Procedure.DueDate as [Due Date], 0 as [Due Time], 
									( select decode from code where Patient_Procedure.ZoneID = codeid) as Zone
								FROM   Orders 
								INNER JOIN Contact ON Orders.SourceContactID = Contact.ContactID 
								INNER JOIN Patient ON Contact.ContactID = Patient.ContactID 
								INNER JOIN Patient_Procedure ON Patient.PatientID = Patient_Procedure.PatientID 
								INNER JOIN Code ON Patient_Procedure.PriorityID = Code.CodeID and Orders.IsActive = 1";*/

					strQuery = @"SELECT  distinct  Orders.OrderID AS [OrderID] , Orders.OrderNo AS [Order No],Contact.FirstName as [Patient Name],(select decode from code where code.codeid = Patient_Procedure.priorityid and code.typeid = 3) as [Priority] , Patient_Procedure.DueDate as [Due Date], '' as [Due Time], Code.Decode as [Zone]
								FROM         Orders 
								INNER JOIN Patient_Procedure ON Orders.OrderID = Patient_Procedure.OrderID 
								INNER JOIN Patient ON Patient_Procedure.PatientID = Patient.PatientID 
								INNER JOIN Contact ON Patient.ContactID = Contact.ContactID 
								INNER JOIN Code ON Patient_Procedure.ZoneID = Code.CodeID and Orders.IsActive = 1" + wherestring;
					break;
				
				case "TechOrderStatus":
					/*strQuery = @"SELECT Orders.OrderID as [Order No],procedures.name as [Test],Code.Decode as [Priority], Patient_Procedure.DueDate as [Due Date], 0 as [Test Time], 
									( select codeid from code where Patient_Procedure.statusid = codeid) as StatusID,Patient_Procedure.PatientID as [PatientID]
								FROM   Orders 
								INNER JOIN Contact ON Orders.SourceContactID = Contact.ContactID 
								INNER JOIN Patient ON Contact.ContactID = Patient.ContactID 
								INNER JOIN Patient_Procedure ON Patient.PatientID = Patient_Procedure.PatientID 
								INNER JOIN Procedures on Patient_Procedure.procedureid = Procedures.procedureid
								INNER JOIN Code ON Patient_Procedure.PriorityID = Code.CodeID and Orders.IsActive = 1";
*/
					strQuery = @"SELECT   Orders.OrderID AS [OrderId],    Orders.OrderNo AS [Order No], Procedures.Name AS [Test],
								(SELECT decode FROM code WHERE  code.codeid = Patient_Procedure.priorityid AND code.typeid = 3) AS [Priority], Patient_Procedure.DueDate AS [Due Date], 00.00 AS [Test Time],
								(SELECT codeid FROM code WHERE code.codeid = Patient_Procedure.StatusId AND code.typeid = 7) AS StatusId,Patient_Procedure.ProcedureID as [ProcedureID]
								FROM Patient_Procedure 
						INNER JOIN Orders ON Patient_Procedure.OrderID = Orders.OrderID 
						INNER JOIN Procedures ON Patient_Procedure.ProcedureID = Procedures.ProcedureID "+wherestring;// and  Orders.OrderID = 'o1'";
					//strQuery = @"SELECT top 10 [ProcedureID] as [Order No], [Name] AS [Test], [ProcedureCodeID] AS Priority, getdate() AS [Due Date], '' AS  [Test Time] FROM [USDiag].[dbo].[Procedures]";//,'[Buffer04]' AS Status
					break;
				
				case "OrderType":
					strQuery = "SELECT CodeId, Decode FROM Code WHERE TypeID = 7 /*and IsActive = 1*/";
					break;
				case "TechStructure":
					strQuery = @"SELECT   Orders.OrderID AS [OrderId],    Orders.OrderNo AS [Order No], Procedures.Name AS [Test],
								(SELECT decode FROM code WHERE  code.codeid = Patient_Procedure.priorityid AND code.typeid = 3) AS [Priority], Patient_Procedure.DueDate AS [Due Date], 00.00 AS [Test Time],
								(SELECT codeid FROM code WHERE code.codeid = Patient_Procedure.StatusId AND code.typeid = 7) AS StatusId,Patient_Procedure.ProcedureID as [ProcedureID]
								FROM Patient_Procedure 
						INNER JOIN Orders ON Patient_Procedure.OrderID = Orders.OrderID 
						INNER JOIN Procedures ON Patient_Procedure.ProcedureID = Procedures.ProcedureID  and 1=0";
					break;

				case "OrdersPending":
					strQuery = @"SELECT DISTINCT 
                      Orders.OrderNo, Contact.FirstName AS [Patient Name], Procedures.Name AS [Test Name], Code.Decode AS [Test Type], 
                      Orders.OrderDate AS [Order Date], ' ' AS [Order Time]
FROM         Orders INNER JOIN
                      Patient_Procedure ON Orders.OrderID = Patient_Procedure.OrderID INNER JOIN
                      Patient ON Patient_Procedure.PatientID = Patient.PatientID INNER JOIN
                      Contact ON Patient.ContactID = Contact.ContactID INNER JOIN
                      Procedures ON Patient_Procedure.ProcedureID = Procedures.ProcedureID INNER JOIN
                      Code ON Procedures.ProcedureCodeID = Code.CodeID AND Patient_Procedure.StatusID = 27";
					break;

				case "OrdersCompleted":
					strQuery = @"SELECT DISTINCT 
                      Orders.OrderNo, Contact.FirstName AS [Patient Name], Procedures.Name AS [Test Name], Code.Decode AS [Test Type], 
                      Orders.OrderDate AS [Order Date], ' ' AS [Order Time]
FROM         Orders INNER JOIN
                      Patient_Procedure ON Orders.OrderID = Patient_Procedure.OrderID INNER JOIN
                      Patient ON Patient_Procedure.PatientID = Patient.PatientID INNER JOIN
                      Contact ON Patient.ContactID = Contact.ContactID INNER JOIN
                      Procedures ON Patient_Procedure.ProcedureID = Procedures.ProcedureID INNER JOIN
                      Code ON Procedures.ProcedureCodeID = Code.CodeID AND Patient_Procedure.StatusID = 25";
			
					break;
				case "OrdersDispatched":
					strQuery = @"SELECT DISTINCT 
                      Orders.OrderNo, Contact.FirstName AS [Patient Name], Procedures.Name AS [Test Name], Code.Decode AS [Test Type], 
                      Orders.OrderDate AS [Order Date], ' ' AS [Order Time]
FROM         Orders INNER JOIN
                      Patient_Procedure ON Orders.OrderID = Patient_Procedure.OrderID INNER JOIN
                      Patient ON Patient_Procedure.PatientID = Patient.PatientID INNER JOIN
                      Contact ON Patient.ContactID = Contact.ContactID INNER JOIN
                      Procedures ON Patient_Procedure.ProcedureID = Procedures.ProcedureID INNER JOIN
                      Code ON Procedures.ProcedureCodeID = Code.CodeID AND Patient_Procedure.StatusID = 26";
			
					break;

				// Technician New
				case "TechnicianGridBind":
					strQuery = "select distinct o.OrderID, o.OrderNo, (select isNull(c.MiddleName, '') + ' ' + isNull(c.FirstName, '') + ' ' + isNull(c.LastName, '') from Contact c where c.ContactID = (select p.ContactID from patient p where p.PatientID = pp.PatientID)) FullName, pp.PriorityID, (select c.decode from code c where c.codeid = pp.priorityID) priority, CONVERT(VARCHAR(10), pp.DueDate,101)  AS [Due Date],  CONVERT(VARCHAR(10), pp.DueDate,108)AS [Test Time]  from Orders o inner join patient_procedure pp on o.OrderId = pp.OrderID where pp.IsActive = 1 and  pp.TechnicianID = '"+ wherestring +"' and   CONVERT(VARCHAR(10),pp.duedate,120) >= CONVERT(VARCHAR(10), getdate(),120)";
					break;

				case "TechnicianAdminGridBind":
					strQuery = "select distinct o.OrderID, o.OrderNo, (select isNull(c.MiddleName, '') + ' ' + isNull(c.FirstName, '') + ' ' + isNull(c.LastName, '') from Contact c where c.ContactID = (select p.ContactID from patient p where p.PatientID = pp.PatientID)) FullName, pp.PriorityID, (select c.decode from code c where c.codeid = pp.priorityID) priority, CONVERT(VARCHAR(10), pp.DueDate,101)  AS [Due Date],  CONVERT(VARCHAR(10), pp.DueDate,108)AS [Test Time]  from Orders o inner join patient_procedure pp on o.OrderId = pp.OrderID where pp.IsActive = 1  and   CONVERT(VARCHAR(10),pp.duedate,120) >= CONVERT(VARCHAR(10), getdate(),120)";
					break;

				case "TechnicianStructure":
					strQuery = "Select * from Patient_Procedure where 1 = 2";
					break;
					
				case "Role":
					strQuery = "select RoleID, Name from Role where IsActive = 1 order by RoleID";
					break;

				case "MappedRoles":
					strQuery = "select RoleId from Role_permission  where RoleId = '"+ wherestring +"' and IsActive = 1 ;";
					break;

				case "Permission":
					strQuery = "select PermissionID,Name from Permission where IsActive=1 order by PermissionID;";
					break;

				case "MappedPermission":
					strQuery = "select PermissionID from Role_permission  where PermissionID = '"+ wherestring +"' and IsActive = 1 ;";
					break;

				case "MappedUnMappedRoles":
					strQuery ="select Name,RoleId from Role  where RoleId not in (select RoleId from Role_Permission where IsActive = 1) and IsActive=1  order by Name;"; 
					strQuery += "select(select R.Name from Role R where RP.RoleId = R.RoleId and R.IsActive = 1)Roles,(select P.Name from Permission P where P.PermissionId = RP.PermissionId and P.IsActive = 1 )Permission,Rp.RoleId from Role_Permission RP where isActive = 1 order by Roles asc,Permission";
					break;

				case "SelPermissions":	//gets complete permissions and mapped permissions
					strQuery = "select Name,PermissionID from Permission where IsActive = 1;";
					strQuery += "select (select P.Name from Permission P where P.PermissionId = RP.PermissionId) SelPerm,PermissionID from Role_Permission RP where RoleId = '"+ wherestring +"' and IsActive = 1 order by SelPerm;";
					break;

				case "MappedUnMappedUsers":
					strQuery ="select (select C.FirstName from Contact C where U.ContactId = C.ContactId)UserName,U.UserId ,U.ContactId from UserInfo U";
					strQuery += " where U.UserId not in (select UP.UserID from User_Permission UP where UP.IsActive = 1) and U.IsActive = 1 order by UserName;"; 
					strQuery += "select (select C.FirstName from Contact C where  C.ContactId = (select U.ContactId from UserInfo U where U.UserId = UP.UserId) )UserName,";
					strQuery += "(select P.Name from Permission P where P.PermissionID = UP.PermissionId)Permission, userId from User_Permission UP where UP.IsActive = 1 order by Username;";
					break;

				case "UsersPermissions":
					strQuery =  "select Name,PermissionID from Permission where IsActive = 1;";
					strQuery += "select (select P.Name from Permission P where P.PermissionId = UP.PermissionId) SelPerm, PermissionID from User_Permission UP where UserId = '"+ wherestring +"' and IsActive = 1 order by SelPerm;";
					break;

				case "OrderID":
					strQuery = "select top 1 orderid from orders where orderno = '"+wherestring+"'";
					break;
				
				case "UserRole":
					strQuery = "SELECT COUNT(*) FROM USER_ROLE WHERE ROLEID=2 AND USERID='"+wherestring+"'";
					break;

				case "ForgotPassword":
					strQuery = "select top 1 password from userinfo where loginid = '"+GetNodeXml("LoginID", wherestring)+"' and question = '"+GetNodeXml("Question", wherestring)+"' and answer ='"+GetNodeXml("Answer", wherestring)+"'";
					break;
				case "DeleteProcedure":
					strQuery = "select count(*) from patient_procedure where procedureid in ('"+wherestring+"')";
					break;

				case "GetAjaxPatientSearch":
					strQuery = "select p.PatientID, c.firstname firstname from patient p, contact c where c.Contactid = p.contactid and c.firstname like '"+wherestring+"%'";
					break;
				
				case "GetAjaxOrderSearch":
					strQuery = "select OrderID, (select OrderNO from orders o where o.orderid = po.orderid) OrderNo from Patient_order po where po.PatientID = '"+wherestring+"'";
					//strQuery = "select OrderID, OrderNo from orders where orderid in (select distinct orderid from patient_procedure pp where pp.PatientID = '"+wherestring+"')";
					break;

				case "GetAjaxOrderSearch1":
					strQuery = "select OrderID, OrderNo from orders where orderid in (select distinct orderid from patient_procedure pp where pp.PatientID = '"+GetNodeXml("PatientID", wherestring)+"') and Orderno like '"+GetNodeXml("OrderID", wherestring)+"%'";
					break;

				
				case "GetPatientSearch":
					strQuery = "select p.PatientID, c.firstname firstname from patient p, contact c where c.Contactid = p.contactid and c.firstname like '"+wherestring+"%'";
					break;

				case  "GetProcedureCategory":
					strQuery = "SELECT CodeID, Decode FROM CODE WHERE TypeID =4";
					break;

				case "GetProcedureData":
					strQuery = "select pp.OrderID, pp.PatientID, (SELECT ProcedureCodeID from procedures p where pp.ProcedureID = p.ProcedureID) CategoryID, pp.ProcedureID, (select buffer01 from procedures p where p.ProcedureID = pp.ProcedureID) Code, pp.buffer01 Views, pp.TechnicianID,  CONVERT(VARCHAR(10), pp.DueDate,101) DueDate, pp.PriorityID from Patient_procedure pp where Orderid='"+GetNodeXml("OrderID", wherestring)+"' and PatientID='"+GetNodeXml("PatientID", wherestring)+"'";
					break;

				case "GetOrderData":
					strQuery = "SELECT OrderID, OrderNo, OrderDate, '' as ServiceDate, Buffer01 Status FROM Orders o WHERE OrderID in (select OrderID from Patient_order where PatientID = '"+wherestring+"')";
					break;

				case "GetOrderProcedure":
					strQuery = "select ProcedureID, Buffer01 Code, ProcedurecodeID, Name,(select Decode from Code where codeid= p.procedurecodeid) category from procedures p where buffer01 = '"+wherestring+"'";
					break;
				case "GetOrderProcedureType":
					strQuery = "select ProcedureID, Name from procedures where procedurecodeid ='"+wherestring+"'";
					break;

				case "GetOrderProcedureCode":
					strQuery = "Select Buffer01 Code, ProcedureCodeID from procedures p where ProcedureID = '"+wherestring+"'";
					break;

			}
			return strQuery;
		
		}

		#region Xml API related Methods
		/// <summary>
		/// this method is used to get the specified node value from xml string
		/// </summary>
		/// <param name="strNodeText"></param>
		/// <param name="strXMLFile"></param>
		/// <returns></returns>
		
		private static string GetNodeXml(string strNodeText, string strXMLFile)
		{
			try
			{
				XmlDocument xmlDoc = new XmlDocument();
				XmlNodeList   xmlNode; 
				xmlDoc.LoadXml(strXMLFile);
				xmlNode = xmlDoc.DocumentElement.GetElementsByTagName(strNodeText);
				return xmlNode[0].InnerText;
			}
			catch(Exception )
			{
				return "";
			}
		}//end of getNodeText
		#endregion
	}
}
