#region  Page Level Comments

/*******************************************************************************************
/*File Name	      :			DUserPermission.cs
 *Project Name    :			USD 1.0
 *Object          :			DAL
 *Purpose         :			
 *Author          :			Adiseshu.D
 *Date            :			27-5-2006 
 *ModuleName      :			USD
 *This file is provided as part of Zaxis-USD project.
 *Copyright � 2004-07, Zaxis-USD Technologies, All rights reserved
 * ************************************ Revision History************************************
 *
 *  Date            Done by             Method             Change Description

*******************************************************************************************/

#endregion

#region  NameSpace Declaration

//System NameSpaces

using System;
using System.Data;
using System.Collections;
using System.Configuration;
using System.Data.SqlClient;
using Microsoft.Practices.EnterpriseLibrary.Data;

//Zaxis-USD NameSpaces
using Zaxis.DataAccess;

#endregion

namespace Zaxis.USD.DAL 
{
	public class DUserPermission : DALBase 
	{
		//default constructor 
		public DUserPermission()
		{
		}
		public string Create(string UserID, string PermissionID, string Buffer01, string Buffer02, string Buffer03, string Buffer04, string Buffer05, string IsActive, IDbTransaction iTrans)
		{
			string strQuery = null;
			strQuery = @" INSERT INTO User_Permission(UserID,PermissionID,Buffer01,Buffer02,Buffer03,Buffer04,Buffer05,IsActive)
			 VALUES('" + UserID +" ', '" + PermissionID +" ', '" + Buffer01 +" ', '" + Buffer02 +" ', '" + Buffer03 +" ', '" + Buffer04 +" ', '" + Buffer05 +" ', '"+IsActive+"')";
			return dbInstance.ExecuteNonQuery(iTrans, CommandType.Text, strQuery).ToString();
		}

		public string Create(DataSet dsFormData, string strTableName, IDbTransaction iTrans,Hashtable ht)
		{
			int iRowCount=0;
			int iRowCnt=0;
			if (dbInstance == null)
				throw new Exception("No Connection");

			DataRow drFormData; 
			try 
			{ 
				iRowCount = dsFormData.Tables[strTableName].Rows.Count; 
				for(iRowCnt = 0; iRowCnt < iRowCount; iRowCnt++) 
				{ 
					drFormData = dsFormData.Tables[strTableName].Rows[iRowCnt]; 
					Create(drFormData["UserID"].ToString(), drFormData["PermissionID"].ToString(), drFormData["Buffer01"].ToString(), drFormData["Buffer02"].ToString(), drFormData["Buffer03"].ToString(), drFormData["Buffer04"].ToString(), drFormData["Buffer05"].ToString(), drFormData["IsActive"].ToString(), iTrans);
				}
			} 
			catch(Zaxis.Definitions.ZaxisException ex) 
			{
				ex.RowNumber = iRowCnt + 1; 
				throw ex; 
			} 
			return "";
		}

		private string UpdateUserPer (string UserID, string PermissionID, IDbTransaction iTrans)
		{
			string strQuery = "";
			strQuery = "if(select PermissionId from User_Permission  where UserId = '"+ UserID +"' and PermissionId = '"+ PermissionID +"')is null  begin INSERT into User_Permission(UserID,PermissionID,IsActive) values ( '"+  UserID +"','"+ PermissionID +"','1') end  else UPDATE User_Permission set IsActive = '1' where UserID = '"+ UserID +"' and PermissionId = '"+ PermissionID +"';";
			if(dbInstance.ExecuteNonQuery(iTrans, CommandType.Text, strQuery) < 1)
			{ 
				Zaxis.Definitions.ZaxisException ex = new Zaxis.Definitions.ZaxisException(); 
				throw ex; 
			} 
			return ""; 
		} 

		private string UpdatePer (string UserID, string PermissionID, IDbTransaction iTrans)
		{
			string strQuery = "";
			
			strQuery = "if(select PermissionId from User_permission  where UserID = '" + UserID + "' and PermissionId = '" + PermissionID + "')is  not null	begin update User_Permission set IsActive = 0 where UserID = '" + UserID + "' and PermissionID = '" + PermissionID + "' end; ";
			try
			{
				dbInstance.ExecuteNonQuery(iTrans, CommandType.Text, strQuery);
			}
			catch (System.Exception e)
			{
				Zaxis.Definitions.ZaxisException ex = new Zaxis.Definitions.ZaxisException(); 
				throw ex;
			}
			return ""; 
		} 

		public string Update(DataSet dsFormData,IDbTransaction iTrans,Hashtable ht)
		{
			int iRowCount = 0;
			int iRowCnt = 0;
			string UserId = "";
			if (dbInstance == null)
				throw new Exception("No Connection");
			DataRow drFormData;
			try
			{
				UserId = dsFormData.Tables["Users"].Rows[0]["UserId"].ToString();
				iRowCount = dsFormData.Tables["UserPermissions"].Rows.Count;
				for(iRowCnt = 0; iRowCnt < iRowCount; iRowCnt++)
				{
					drFormData = dsFormData.Tables["UserPermissions"].Rows[iRowCnt];
					UpdateUserPer(UserId, drFormData["UserId"].ToString(), iTrans);
				}
				iRowCount = dsFormData.Tables["Permissions"].Rows.Count;
				for(iRowCnt = 0; iRowCnt < iRowCount; iRowCnt++)
				{
					drFormData = dsFormData.Tables["Permissions"].Rows[iRowCnt];
					UpdatePer(UserId, drFormData["PerId"].ToString(), iTrans);
				}
			}
			catch(Zaxis.Definitions.ZaxisException ex)
			{
				ex.RowNumber = iRowCnt + 1;
				throw ex;
			}
			return "";
		}

		private string Delete(string UserID,IDbTransaction iTrans)
		{
			string strQuery = "";
			strQuery=" DELETE  User_Permission WHERE  UserID = '"+UserID+"'";
			if(dbInstance.ExecuteNonQuery(iTrans, CommandType.Text, strQuery) < 1) 
			{ 
				Zaxis.Definitions.ZaxisException ex = new Zaxis.Definitions.ZaxisException(); 
				throw ex; 
			} 
			return ""; 
		} 

		public string Delete(DataSet dsFormData, string strTableName, IDbTransaction iTrans)
		{
			int iRowCount=0;
			int iRowCnt=0;
			if (dbInstance == null)
				throw new Exception("No Connection");

			DataRow drFormData; 
			try 
			{ 
				iRowCount = dsFormData.Tables[strTableName].Rows.Count; 
				for(iRowCnt = 0; iRowCnt < iRowCount; iRowCnt++) 
				{ 
					drFormData = dsFormData.Tables[strTableName].Rows[iRowCnt]; 
					Delete(drFormData["UserID"].ToString(),iTrans);
				}
			} 
			catch(Zaxis.Definitions.ZaxisException ex) 
			{
				ex.RowNumber = iRowCnt + 1; 
				throw ex; 
			} 
			return "";
		}
	}
}
