#region  Page Level Comments

/*******************************************************************************************
/*File Name	      :			DHistory.cs
 *Project Name    :			USD 1.0
 *Object          :			DAL
 *Purpose         :			
 *Author          :			Desayya N
 *Date            :			8-7-2006 
 *ModuleName      :			USD
 *This file is provided as part of Zaxis-USD project.
 *Copyright � 2004-07, Zaxis-USD Technologies, All rights reserved
 * ************************************ Revision History************************************
 *
 *  Date            Done by             Method             Change Description

*******************************************************************************************/

#endregion

#region  NameSpace Declaration

//System NameSpaces

using System;
using System.Data;
using System.Collections;

//Zaxis-USD NameSpaces
using Zaxis.DataAccess;

#endregion

namespace Zaxis.USD.DAL
{
	/// <summary>
	/// Summary description for DHistory.
	/// </summary>
	public class DHistory : DALBase 
	{

		#region Constructor

		/// <summary>
		/// Empty Constructory
		/// </summary>
		public DHistory()
		{
		}
		#endregion

		#region Storing History Info
		
		/// <summary>
		/// This method logs the data into History table based on the
		/// CRUD operations
		/// </summary>
		/// <param name="data"></param>
		public void Create(string UserID, string ActionID, string PermissionID, string SubjectID, string Description, IDbTransaction iTrans)
		{
			string strQuery = string.Empty;
			strQuery = "INSERT INTO HISTORY (HistoryID, ActionByID, ActionDate, ActionID, PermissionID, SubjectID, Description) VALUES(newid(), '"+UserID+"', getdate(), '"+ActionID+"', '"+PermissionID+"', '"+SubjectID+"', '"+Description+"')";
			dbInstance.ExecuteNonQuery(iTrans, CommandType.Text, strQuery);
		}
		
		#endregion

	}
}
