#region  Page Level Comments

/*******************************************************************************************
/*File Name	      :			DPatient.cs
 *Project Name    :			USD 1.0
 *Object          :			DAL
 *Purpose         :			
 *Author          :			Padma A
 *Date            :			27-5-2006 
 *ModuleName      :			USD
 *This file is provided as part of Zaxis-USD project.
 *Copyright � 2004-07, Zaxis-USD Technologies, All rights reserved
 * ************************************ Revision History************************************
 *
 *  Date            Done by             Method             Change Description

*******************************************************************************************/

#endregion

#region  NameSpace Declaration

//System NameSpaces

using System;
using System.Data;
using System.Collections;

//Zaxis-USD NameSpaces
using Zaxis.DataAccess;

#endregion

namespace Zaxis.USD.DAL 
{
	public class DPatient : DALBase 
	{

		#region Constructor
		/// <summary>
		///default constructor 
		/// </summary>
		public DPatient()
		{
		}
		#endregion

		#region Create

		/// <summary>
		/// Inserts new record into database
		/// </summary>
		/// <param name="ProcedureID"></param>
		/// <param name="Name"></param>
		/// <param name="ProcedureCodeID"></param>
		/// <returns></returns>
		public string Create(string PatientID, string DOB, string SSN, string MedicareNo, string MedicaidNO, string RoomNo, string ContactID, string PatientInsuranceCode, string InsuranceContactID, string CompanyID, string BranchID, string Buffer01, string Buffer02, string Buffer03, string Buffer04, string Buffer05, string IsActive, string Comments, IDbTransaction iTrans)
		{
			string strQuery = null;
			strQuery = @" INSERT INTO Patient(PatientID,DOB,SSN,MedicareNo,MedicaidNO,RoomNo,ContactID,PatientInsuranceCode,InsuranceContactID,CompanyID,BranchID,Buffer01,Buffer02,Buffer03,Buffer04,Buffer05,IsActive, Comments)
			 VALUES('" + PatientID +" ', '" + DOB +" ', '" + SSN +" ', '" + MedicareNo +" ', '" + MedicaidNO +" ', '" + RoomNo +" ', '" + ContactID +" ', '" + PatientInsuranceCode +" ', '" + InsuranceContactID +" ', '" + CompanyID +" ', '" + BranchID +" ', '" + Buffer01 +" ', '" + Buffer02 +" ', '" + Buffer03 +" ', '" + Buffer04 +" ', '" + Buffer05 +" ', '"+IsActive+"', '"+Comments+"')";
			return dbInstance.ExecuteNonQuery(iTrans, CommandType.Text, strQuery).ToString();
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="dsFormData"></param>
		/// <param name="strTableName"></param>
		/// <param name="iTrans"></param>
		/// <param name="ht"></param>
		/// <returns></returns>
		public string Create(DataSet dsFormData, string strTableName, IDbTransaction iTrans,Hashtable ht)
		{
			int iRowCount=0;
			int iRowCnt=0;
			if (dbInstance == null)
				throw new Exception("No Connection");

			DataRow drFormData; 
			try 
			{ 
				iRowCount = dsFormData.Tables[strTableName].Rows.Count; 
				for(iRowCnt = 0; iRowCnt < iRowCount; iRowCnt++) 
				{ 
					drFormData = dsFormData.Tables[strTableName].Rows[iRowCnt]; 
					Create(drFormData["PatientID"].ToString(), drFormData["DOB"].ToString(), drFormData["SSN"].ToString(), drFormData["MedicareNo"].ToString(), drFormData["MedicaidNO"].ToString(), drFormData["RoomNo"].ToString(), drFormData["ContactID"].ToString(), drFormData["PatientInsuranceCode"].ToString(), drFormData["InsuranceContactID"].ToString(), drFormData["CompanyID"].ToString(), drFormData["BranchID"].ToString(), drFormData["Buffer01"].ToString(), drFormData["Buffer02"].ToString(), drFormData["Buffer03"].ToString(), drFormData["Buffer04"].ToString(), drFormData["Buffer05"].ToString(), drFormData["IsActive"].ToString(), drFormData["Comments"].ToString(),iTrans);
				}
			} 
			catch(Zaxis.Definitions.ZaxisException ex) 
			{
				ex.RowNumber = iRowCnt + 1; 
				throw ex; 
			} 
			return "";
		}

		#endregion

		#region Update

		/// <summary>
		/// Updates the exsting record from Procedure Table
		/// </summary>
		/// <param name="ProcedureID"></param>
		/// <param name="Name"></param>
		/// <param name="ProcedureCodeID"></param>
		/// <returns>True/False</returns>
		private string Update (string PatientID, string DOB, string SSN, string MedicareNo, string MedicaidNO, string RoomNo, string ContactID, string PatientInsuranceCode, string InsuranceContactID, string CompanyID, string BranchID, string Buffer01, string Buffer02, string Buffer03, string Buffer04, string Buffer05, string IsActive, string Comments, IDbTransaction iTrans)
		{
			string strQuery = "";
			strQuery = "update Patient SET DOB = '"+DOB+"',SSN = '"+SSN+"', Comments='"+Comments+"', MedicareNo = '"+MedicareNo+"',MedicaidNO = '"+MedicaidNO+"',RoomNo = '"+RoomNo+"',ContactID = '"+ContactID+"',PatientInsuranceCode = '"+PatientInsuranceCode+"',InsuranceContactID = '"+InsuranceContactID+"',CompanyID = '"+CompanyID+"',BranchID = '"+BranchID+"',Buffer01 = '"+Buffer01+"',Buffer02 = '"+Buffer02+"',Buffer03 = '"+Buffer03+"',Buffer04 = '"+Buffer04+"',Buffer05 = '"+Buffer05+"',IsActive = '"+IsActive+"'" + " where PatientID = '"+PatientID+"'";
			if(dbInstance.ExecuteNonQuery(iTrans, CommandType.Text, strQuery) < 1) 
			{ 
				Zaxis.Definitions.ZaxisException ex = new Zaxis.Definitions.ZaxisException(); 
				throw ex; 
			} 
			return ""; 
		} 

		public string Update(DataSet dsFormData, string strTableName, IDbTransaction iTrans,Hashtable ht)
		{
			int iRowCount = 0;
			int iRowCnt = 0;
			if (dbInstance == null)
				throw new Exception("No Connection");
			DataRow drFormData;
			try
			{
				iRowCount = dsFormData.Tables[strTableName].Rows.Count;
				for(iRowCnt = 0; iRowCnt < iRowCount; iRowCnt++)
				{
					drFormData = dsFormData.Tables[strTableName].Rows[iRowCnt];
					Update(drFormData["PatientID"].ToString(), drFormData["DOB"].ToString(), drFormData["SSN"].ToString(), drFormData["MedicareNo"].ToString(), drFormData["MedicaidNO"].ToString(), drFormData["RoomNo"].ToString(), drFormData["ContactID"].ToString(), drFormData["PatientInsuranceCode"].ToString(), drFormData["InsuranceContactID"].ToString(), drFormData["CompanyID"].ToString(), drFormData["BranchID"].ToString(), drFormData["Buffer01"].ToString(), drFormData["Buffer02"].ToString(), drFormData["Buffer03"].ToString(), drFormData["Buffer04"].ToString(), drFormData["Buffer05"].ToString(), drFormData["IsActive"].ToString(), drFormData["Comments"].ToString(), iTrans);
				}
			}
			catch(Zaxis.Definitions.ZaxisException ex)
			{
				ex.RowNumber = iRowCnt + 1;
				throw ex;
			}
			return "";
		}

		#endregion

		#region Delete

		/// <summary>
		/// Deletes the Record from Database
		/// </summary>
		/// <param name="ProcedureID"></param>
		/// <param name="iTrans"></param>
		/// <returns></returns>		
		private string Delete(string PatientID,IDbTransaction iTrans)
		{
			string strQuery = "";
			strQuery=" update   Patient set isactive = 0 WHERE  PatientID = '"+PatientID+"'";
			if(dbInstance.ExecuteNonQuery(iTrans, CommandType.Text, strQuery) < 1) 
			{ 
				Zaxis.Definitions.ZaxisException ex = new Zaxis.Definitions.ZaxisException(); 
				throw ex; 
			} 
			return ""; 
		} 

		public string Delete(DataSet dsFormData, string strTableName, IDbTransaction iTrans)
		{
			int iRowCount=0;
			int iRowCnt=0;
			if (dbInstance == null)
				throw new Exception("No Connection");

			DataRow drFormData; 
			try 
			{ 
				iRowCount = dsFormData.Tables[strTableName].Rows.Count; 
				for(iRowCnt = 0; iRowCnt < iRowCount; iRowCnt++) 
				{ 
					drFormData = dsFormData.Tables[strTableName].Rows[iRowCnt]; 
					Delete(drFormData["PatientID"].ToString(),iTrans);
				}
			} 
			catch(Zaxis.Definitions.ZaxisException ex) 
			{
				ex.RowNumber = iRowCnt + 1; 
				throw ex; 
			} 
			return "";
		}
		#endregion
	}
}
