using System; 
using System.Collections; 
using System.Data;
using Microsoft.Practices.EnterpriseLibrary.Data;

using Zaxis.DataAccess;
using Zaxis.Definitions;

namespace Zaxis.USD.DAL 
{
	public class DTechnician : Zaxis.DataAccess.DAL 
	{
		
		private void GetReports()
		{
		}

		//default constructor 
		public DTechnician()
		{
			try
			{
			
				//Zaxis.DataAccess.DAL oDal = new DALBase();
				IDbConnection con = base.GetConnection();
				string strConn = con.ConnectionString;
			}
			catch(Exception ex)
			{
				string strEx = ex.Message;
			}

			
			
		}
		public string Create(IDbTransaction iTrans,string PatientID,string ProcedureID,string TechnicianID,string DueDate,string TestDate,string PriorityID,string ZoneID,string Comments,string StatusID,string OrderTyp,string Buffer01,string Buffer02,string Buffer03,string Buffer04,string Buffer05,string IsActive)
		{
			string strQuery = null;
			strQuery = @" INSERT INTO Patient_Procedure(PatientID,ProcedureID,TechnicianID,DueDate,TestDate,PriorityID,ZoneID,Comments,StatusID,OrderTyp,Buffer01,Buffer02,Buffer03,Buffer04,Buffer05,IsActive)
			 VALUES('"+PatientID+"','"+ProcedureID+"','"+TechnicianID+"','"+DueDate+"','"+TestDate+"','"+PriorityID+"','"+ZoneID+"','"+Comments+"','"+StatusID+"','"+OrderTyp+"','"+Buffer01+"','"+Buffer02+"','"+Buffer03+"','"+Buffer04+"','"+Buffer05+"','"+IsActive+"')";
			return dbInstance.ExecuteNonQuery(iTrans, CommandType.Text, strQuery).ToString();
		}

		public string Create(DataSet dsFormData, string strTableName, IDbTransaction iTrans,Hashtable ht)
		{
			int iRowCount=0;
			int iRowCnt=0;
			DataRow drFormData = null; 
			if (dbInstance == null)
				throw new Exception("No Connection");
			try 
			{ 
				iRowCount = dsFormData.Tables[strTableName].Rows.Count; 
				for(iRowCnt = 0; iRowCnt < iRowCount; iRowCnt++) 
				{ 
					drFormData = dsFormData.Tables[strTableName].Rows[iRowCnt]; 
					Create(iTrans,drFormData["PatientID"].ToString(),drFormData["ProcedureID"].ToString(),drFormData["TechnicianID"].ToString(),drFormData["DueDate"].ToString(),drFormData["TestDate"].ToString(),drFormData["PriorityID"].ToString(),drFormData["ZoneID"].ToString(),drFormData["Comments"].ToString(),drFormData["StatusID"].ToString(),drFormData["OrderTyp"].ToString(),drFormData["Buffer01"].ToString(),drFormData["Buffer02"].ToString(),drFormData["Buffer03"].ToString(),drFormData["Buffer04"].ToString(),drFormData["Buffer05"].ToString(),drFormData["IsActive"].ToString());
				}
			} 
			catch(Zaxis.Definitions.ZaxisException ex) 
			{
				ex.RowNumber = iRowCnt + 1; 
				throw ex; 
			} 
			return "";
		}

		private bool Update (IDbTransaction iTrans,string OrderID,string StatusID,string ProcedureID)
		{
			string strQuery = "";
			strQuery = "UPDATE Patient_Procedure SET StatusID = "+StatusID+" " + " where OrderID = '"+OrderID+"' and ProcedureID ='"+ProcedureID+"'";
			if(dbInstance.ExecuteNonQuery(iTrans, CommandType.Text, strQuery) < 1) 
			{ 
				//Zaxis.Definitions.ZaxisException ex = new Zaxis.Definitions.ZaxisException(); 
				//throw ex;
				return false;

			}
			else
			{
				return true;
			}
		} 

		public bool Update(DataSet dsFormData, string strTableName, IDbTransaction iTrans,Hashtable ht)
		{
			int iRowCount = 0;
			int iRowCnt = 0;
			if (dbInstance == null)
				throw new Exception("No Connection");
			DataRow drFormData;
			try
			{
				iRowCount = dsFormData.Tables[strTableName].Rows.Count;
				for(iRowCnt = 0; iRowCnt < iRowCount; iRowCnt++)
				{
					drFormData = dsFormData.Tables[strTableName].Rows[iRowCnt];
					string Status = drFormData["RowStatus"].ToString();
					switch(Status)
					{
						
						case "Update":
							if(Update(iTrans,drFormData["OrderID"].ToString(),drFormData["StatusID"].ToString(),drFormData["ProcedureID"].ToString()))
							{
								if(iRowCnt == iRowCount-1)
									return true;
							}
							break;
						
					}
				}

				return false;
			}
			catch(Zaxis.Definitions.ZaxisException ex)
			{
				ex.RowNumber = iRowCnt + 1;
				//throw ex;
				return false;
			}
			
		}

		private string Delete(string PatientID,IDbTransaction iTrans)
		{
			string strQuery = "";
			strQuery=" DELETE  Patient_Procedure WHERE  PatientID = '"+PatientID+"'";
			if(dbInstance.ExecuteNonQuery(iTrans, CommandType.Text, strQuery) < 1) 
			{ 
				Zaxis.Definitions.ZaxisException ex = new Zaxis.Definitions.ZaxisException(); 
				throw ex; 
			} 
			return ""; 
		} 

		public string Delete(DataSet dsFormData, string strTableName, IDbTransaction iTrans)
		{
			int iRowCount=0;
			int iRowCnt=0;
			DataRow drFormData = null;
			if (dbInstance == null)
				throw new Exception("No Connection");
			try 
			{ 
				iRowCount = dsFormData.Tables[strTableName].Rows.Count; 
				for(iRowCnt = 0; iRowCnt < iRowCount; iRowCnt++) 
				{ 
					drFormData = dsFormData.Tables[strTableName].Rows[iRowCnt]; 
					Delete(drFormData["PatientID"].ToString(),iTrans);
				}
			} 
			catch(Zaxis.Definitions.ZaxisException ex) 
			{
				ex.RowNumber = iRowCnt + 1; 
				throw ex; 
			} 
			return "";
		}

		public  DataSet GetDataSet(string strQuery)
		{
			try
			{
				return ExecuteDataset(CommandType.Text,strQuery);
			}
			catch(Exception ex)
			{
				string strEx= ex.Message;
				return null;
			}
		}

	
	}
}
