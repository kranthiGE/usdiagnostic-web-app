#region  Page Level Comments

/*******************************************************************************************
/*File Name	      :			DRolePermission.cs
 *Project Name    :			USD 1.0
 *Object          :			DAL
 *Purpose         :			
 *Author          :			Adiseshu.D
 *Date            :			27-5-2006 
 *ModuleName      :			USD
 *This file is provided as part of Zaxis-USD project.
 *Copyright � 2004-07, Zaxis-USD Technologies, All rights reserved
 * ************************************ Revision History************************************
 *
 *  Date            Done by             Method             Change Description

*******************************************************************************************/

#endregion

#region  NameSpace Declaration

//System NameSpaces

using System;
using System.Data;
using System.Collections;
using System.Configuration;
using System.Data.SqlClient;
using Microsoft.Practices.EnterpriseLibrary.Data;

//Zaxis-USD NameSpaces
using Zaxis.DataAccess;

#endregion

namespace Zaxis.USD.DAL 
{
	public class DRolePermission : DALBase 
	{
		//default constructor 
		public DRolePermission()
		{
		}
		public string Create(string RoleID, string PermissionID, string Buffer01, string Buffer02, string Buffer03, string Buffer04, string Buffer05, string IsActive, IDbTransaction iTrans)
		{
			string strQuery = null;
			strQuery = @" INSERT INTO Role_Permission(RoleID,PermissionID,Buffer01,Buffer02,Buffer03,Buffer04,Buffer05,IsActive)
			 VALUES('" + RoleID +" ', '" + PermissionID +" ', '" + Buffer01 +" ', '" + Buffer02 +" ', '" + Buffer03 +" ', '" + Buffer04 +" ', '" + Buffer05 +" ', '"+IsActive+"')";
			return dbInstance.ExecuteNonQuery(iTrans, CommandType.Text, strQuery).ToString();
		}

		public string Create(DataSet dsFormData, string strTableName, IDbTransaction iTrans,Hashtable ht)
		{
			int iRowCount=0;
			int iRowCnt=0;
			if (dbInstance == null)
				throw new Exception("No Connection");

			DataRow drFormData; 
			try 
			{ 
				iRowCount = dsFormData.Tables[strTableName].Rows.Count; 
				for(iRowCnt = 0; iRowCnt < iRowCount; iRowCnt++) 
				{ 
					drFormData = dsFormData.Tables[strTableName].Rows[iRowCnt]; 
					Create(drFormData["RoleID"].ToString(), drFormData["PermissionID"].ToString(), drFormData["Buffer01"].ToString(), drFormData["Buffer02"].ToString(), drFormData["Buffer03"].ToString(), drFormData["Buffer04"].ToString(), drFormData["Buffer05"].ToString(), drFormData["IsActive"].ToString(), iTrans);
				}
			} 
			catch(Zaxis.Definitions.ZaxisException ex) 
			{
				ex.RowNumber = iRowCnt + 1; 
				throw ex; 
			} 
			return "";
		}

		//updates the selected permission for the Roles accordingly
		private string UpdateRolePer (string RoleID, string PermissionID, IDbTransaction iTrans)
		{
			string strQuery = "";
			strQuery = "if(select PermissionId from Role_permission  where RoleId = '"+ RoleID +"' and PermissionId = '"+ PermissionID +"')is null  begin INSERT into Role_Permission(RoleID,PermissionID,IsActive) values ( '"+  RoleID +"','"+ PermissionID +"','1') end  else UPDATE Role_Permission set IsActive = '1' where RoleId = '"+ RoleID +"' and PermissionId = '"+ PermissionID +"';";
			if(dbInstance.ExecuteNonQuery(iTrans, CommandType.Text, strQuery) < 1)
			{ 
				Zaxis.Definitions.ZaxisException ex = new Zaxis.Definitions.ZaxisException(); 
				throw ex; 
			} 
			return ""; 
		} 

		//updates the unselected permissions for the Roles accordingly
		private string UpdatePer (string RoleID, string PermissionID, IDbTransaction iTrans)
		{
			string strQuery = "";
			strQuery = "DECLARE @per int SET @per = (select count(PermissionId) from Role_permission  where RoleId = '"+ RoleID +"'  and PermissionId = '"+ PermissionID +"'); if(@per > 0) begin update Role_Permission set IsActive = '0' where RoleId = '"+ RoleID +"' and PermissionId = '"+ PermissionID +"' end; ";
			try
			{
				//Database db = DatabaseFactory.CreateDatabase();
				//db.ExecuteNonQuery(CommandType.Text,strQuery);
				dbInstance.ExecuteNonQuery(iTrans, CommandType.Text, strQuery);
			}
			catch (System.Exception e)
			{
				Zaxis.Definitions.ZaxisException ex = new Zaxis.Definitions.ZaxisException(); 
				throw ex; 
			}
			return ""; 
		} 

		public string Update(DataSet dsFormData,IDbTransaction iTrans,Hashtable ht)
		{
			int iRowCount = 0;
			int iRowCnt = 0;
			string RoleId = "";
			if (dbInstance == null)
				throw new Exception("No Connection");
			DataRow drFormData;
			try
			{
				RoleId = dsFormData.Tables["Roles"].Rows[0]["RoleId"].ToString();
				iRowCount = dsFormData.Tables["SelectedPermissions"].Rows.Count;
				for(iRowCnt = 0; iRowCnt < iRowCount; iRowCnt++)
				{
					drFormData = dsFormData.Tables["SelectedPermissions"].Rows[iRowCnt];
					UpdateRolePer(RoleId, drFormData["PerId"].ToString(), iTrans);
						
				}
				iRowCount = dsFormData.Tables["Permissions"].Rows.Count;
				for(iRowCnt = 0; iRowCnt < iRowCount; iRowCnt++)
				{
					drFormData = dsFormData.Tables["Permissions"].Rows[iRowCnt];
					UpdatePer(RoleId, drFormData["PerId"].ToString(), iTrans);
						
				}
			}
			catch(Zaxis.Definitions.ZaxisException ex)
			{
				ex.RowNumber = iRowCnt + 1;
				throw ex;
			}
			return "";
		}

		private string Delete(string RoleID,IDbTransaction iTrans)
		{
			string strQuery = "";
			strQuery=" DELETE  Role_Permission WHERE  RoleID = '"+RoleID+"'";
			if(dbInstance.ExecuteNonQuery(iTrans, CommandType.Text, strQuery) < 1) 
			{ 
				Zaxis.Definitions.ZaxisException ex = new Zaxis.Definitions.ZaxisException(); 
				throw ex; 
			} 
			return ""; 
		} 

		public string Delete(DataSet dsFormData, string strTableName, IDbTransaction iTrans)
		{
			int iRowCount=0;
			int iRowCnt=0;
			if (dbInstance == null)
				throw new Exception("No Connection");

			DataRow drFormData; 
			try 
			{ 
				iRowCount = dsFormData.Tables[strTableName].Rows.Count; 
				for(iRowCnt = 0; iRowCnt < iRowCount; iRowCnt++) 
				{ 
					drFormData = dsFormData.Tables[strTableName].Rows[iRowCnt]; 
					Delete(drFormData["RoleID"].ToString(),iTrans);
				}
			} 
			catch(Zaxis.Definitions.ZaxisException ex) 
			{
				ex.RowNumber = iRowCnt + 1; 
				throw ex; 
			} 
			return "";
		}

	}
}
