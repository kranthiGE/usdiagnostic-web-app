using System; 
using System.Collections; 
using System.Data;
using Zaxis.DataAccess; 

namespace Zaxis.USD.DAL 
{
	public class test : DALBase 
	{
		//default constructor 
		public test()
		{
		}
		public string Create(string UserID, string LoginID, string Password, string Question, string Answer, string Technition, string ModifyRecord, string CompanyID, string BranchID, string Buffer01, string Buffer02, string Buffer03, string Buffer04, string Buffer05, string IsActive, string ContactID)
		{
			string strQuery = null;
			strQuery = @" INSERT INTO UserInfo(UserID,LoginID,Password,Question,Answer,Technition,ModifyRecord,CompanyID,BranchID,Buffer01,Buffer02,Buffer03,Buffer04,Buffer05,IsActive,ContactID)
			 VALUES('" + UserID +" ', '" + LoginID +" ', '" + Password +" ', '" + Question +" ', '" + Answer +" ', '" + Technition +" ', '" + ModifyRecord +" ', '" + CompanyID +" ', '" + BranchID +" ', '" + Buffer01 +" ', '" + Buffer02 +" ', '" + Buffer03 +" ', '" + Buffer04 +" ', '" + Buffer05 +" ', '" + IsActive +" ', '"+ContactID+"')";
			return dbInstance.ExecuteNonQuery(iTrans, CommandType.Text, strQuery).ToString();
		}

		public string Create(DataSet dsFormData, string strTableName, IDbTransaction iTrans,Hashtable ht)
		{
			int iRowCount=0;
			int iRowCnt=0;
			if (dbInstance == null)
				throw new Exception("No Connection");

			DataRow drFormData; 
			try 
			{ 
				iRowCount = dsFormData.Tables[strTableName].Rows.Count; 
				for(iRowCnt = 0; iRowCnt < iRowCount; iRowCnt++) 
				{ 
					drFormData = dsFormData.Tables[strTableName].Rows[iRowCnt]; 
					Create(drFormData["UserID"].ToString(), drFormData["LoginID"].ToString(), drFormData["Password"].ToString(), drFormData["Question"].ToString(), drFormData["Answer"].ToString(), drFormData["Technition"].ToString(), drFormData["ModifyRecord"].ToString(), drFormData["CompanyID"].ToString(), drFormData["BranchID"].ToString(), drFormData["Buffer01"].ToString(), drFormData["Buffer02"].ToString(), drFormData["Buffer03"].ToString(), drFormData["Buffer04"].ToString(), drFormData["Buffer05"].ToString(), drFormData["IsActive"].ToString(), drFormData["ContactID"].ToString());
				}
			} 
			catch(Zaxis.Definitions.ZaxisException ex) 
			{
				ex.RowNumber = iRowCnt + 1; 
				throw ex; 
			} 
			return "";
		}

		private string Update (string UserID, string LoginID, string Password, string Question, string Answer, string Technition, string ModifyRecord, string CompanyID, string BranchID, string Buffer01, string Buffer02, string Buffer03, string Buffer04, string Buffer05, string IsActive, string ContactID)
		{
			string strQuery = "";
			strQuery = "UserInfo SET LoginID = '"+LoginID+"',Password = '"+Password+"',Question = '"+Question+"',Answer = '"+Answer+"',Technition = '"+Technition+"',ModifyRecord = '"+ModifyRecord+"',CompanyID = '"+CompanyID+"',BranchID = '"+BranchID+"',Buffer01 = '"+Buffer01+"',Buffer02 = '"+Buffer02+"',Buffer03 = '"+Buffer03+"',Buffer04 = '"+Buffer04+"',Buffer05 = '"+Buffer05+"',IsActive = '"+IsActive+"',ContactID = '"+ContactID+"'" + " where UserID = '"+UserID+"'";
			if(dbInstance.ExecuteNonQuery(iTrans, CommandType.Text, strQuery) < 1) 
			{ 
				Zaxis.Definitions.ZaxisException ex = new Zaxis.Definitions.ZaxisException(); 
				throw ex; 
			} 
			return ""; 
		} 

		public string Update(DataSet dsFormData, string strTableName, IDbTransaction iTrans,Hashtable ht)
		{
			int iRowCount = 0;
			int iRowCnt = 0;
			if (dbInstance == null)
				throw new Exception("No Connection");
			DataRow drFormData;
			try
			{
				iRowCount = dsFormData.Tables[strTableName].Rows.Count;
				for(iRowCnt = 0; iRowCnt < iRowCount; iRowCnt++)
				{
					drFormData = dsFormData.Tables[strTableName].Rows[iRowCnt];
					string Status = drFormData["RowStatus"].ToString();
					switch(Status)
					{
						case "Insert":
							Create(drFormData["UserID"].ToString(), drFormData["LoginID"].ToString(), drFormData["Password"].ToString(), drFormData["Question"].ToString(), drFormData["Answer"].ToString(), drFormData["Technition"].ToString(), drFormData["ModifyRecord"].ToString(), drFormData["CompanyID"].ToString(), drFormData["BranchID"].ToString(), drFormData["Buffer01"].ToString(), drFormData["Buffer02"].ToString(), drFormData["Buffer03"].ToString(), drFormData["Buffer04"].ToString(), drFormData["Buffer05"].ToString(), drFormData["IsActive"].ToString(), drFormData["ContactID"].ToString());
							break;
						case "Update":
							Update(drFormData["UserID"].ToString(), drFormData["LoginID"].ToString(), drFormData["Password"].ToString(), drFormData["Question"].ToString(), drFormData["Answer"].ToString(), drFormData["Technition"].ToString(), drFormData["ModifyRecord"].ToString(), drFormData["CompanyID"].ToString(), drFormData["BranchID"].ToString(), drFormData["Buffer01"].ToString(), drFormData["Buffer02"].ToString(), drFormData["Buffer03"].ToString(), drFormData["Buffer04"].ToString(), drFormData["Buffer05"].ToString(), drFormData["IsActive"].ToString(), drFormData["ContactID"].ToString());
							break;
						case "Delete":
							Delete(drFormData["UserID"].ToString(),iTrans);
							break;
					}
				}
			}
			catch(Zaxis.Definitions.ZaxisException ex)
			{
				ex.RowNumber = iRowCnt + 1;
				throw ex;
			}
			return "";
		}

		private string Delete(string UserID,IDbTransaction iTrans)
		{
			string strQuery = "";
			strQuery=" DELETE  UserInfo WHERE  UserID = '"+UserID+"'";
			if(dbInstance.ExecuteNonQuery(iTrans, CommandType.Text, strQuery) < 1) 
			{ 
				Zaxis.Definitions.ZaxisException ex = new Zaxis.Definitions.ZaxisException(); 
				throw ex; 
			} 
			return ""; 
		} 

		public string Delete(DataSet dsFormData, string strTableName, IDbTransaction iTrans)
		{
			int iRowCount=0;
			int iRowCnt=0;
			if (dbInstance == null)
				throw new Exception("No Connection");

			DataRow drFormData; 
			try 
			{ 
				iRowCount = dsFormData.Tables[strTableName].Rows.Count; 
				for(iRowCnt = 0; iRowCnt < iRowCount; iRowCnt++) 
				{ 
					drFormData = dsFormData.Tables[strTableName].Rows[iRowCnt]; 
					Delete(drFormData["UserID"].ToString(),iTrans);
				}
			} 
			catch(Zaxis.Definitions.ZaxisException ex) 
			{
				ex.RowNumber = iRowCnt + 1; 
				throw ex; 
			} 
			return "";
		}

	}
}
