#region  Page Level Comments

/*******************************************************************************************
/*File Name	      :			DUserRole.cs
 *Project Name    :			USD 1.0
 *Object          :			Zaxis.USD.DAL
 *Purpose         :			
 *Author          :			Padma A
 *Date            :			27-5-2006 
 *ModuleName      :			USD
 *This file is provided as part of Zaxis-USD project.
 *Copyright � 2004-07, Zaxis-USD Technologies, All rights reserved
 * ************************************ Revision History************************************
 *
 *  Date            Done by             Method             Change Description

*******************************************************************************************/

#endregion

#region  NameSpace Declaration

//System NameSpaces

using System;
using System.Data;
using System.Collections;

//Zaxis-USD NameSpaces
using Zaxis.DataAccess;

#endregion

namespace Zaxis.USD.DAL 
{
	public class DUserRole : DALBase 
	{
	
		#region Constructor
		//default constructor 
		public DUserRole()
		{
		}

		#endregion

		#region Create

		/// <summary>
		/// Inserts new record into database
		/// </summary>
		/// <param name="ProcedureID"></param>
		/// <param name="Name"></param>
		/// <param name="ProcedureCodeID"></param>
		/// <returns></returns>
		public string Create(string RoleID, string UserID, string Buffer01, string Buffer02, string Buffer03, string Buffer04, string Buffer05, string IsActive, IDbTransaction iTrans)
		{
			string strQuery = null;
			strQuery = @" INSERT INTO User_Role(RoleID,UserID,Buffer01,Buffer02,Buffer03,Buffer04,Buffer05,IsActive)
			 VALUES('" + RoleID +" ', '" + UserID +" ', '" + Buffer01 +" ', '" + Buffer02 +" ', '" + Buffer03 +" ', '" + Buffer04 +" ', '" + Buffer05 +" ', '"+IsActive+"')";
			return dbInstance.ExecuteNonQuery(iTrans, CommandType.Text, strQuery).ToString();
		}

		/// <summary>
		/// Inserts new record into database
		/// </summary>
		/// <param name="dsFormData">Dataset</param>
		/// <param name="strTableName">Name of the table</param>
		/// <param name="iTrans">Transaction Object</param>
		/// <param name="ht">GLobal Values</param>
		/// <returns>True/False</returns>
		public string Create(DataSet dsFormData, string strTableName, IDbTransaction iTrans,Hashtable ht)
		{
			int iRowCount=0;
			int iRowCnt=0;
			if (dbInstance == null)
				throw new Exception("No Connection");

			DataRow drFormData; 
			try 
			{ 
				iRowCount = dsFormData.Tables[strTableName].Rows.Count; 
				for(iRowCnt = 0; iRowCnt < iRowCount; iRowCnt++) 
				{ 
					drFormData = dsFormData.Tables[strTableName].Rows[iRowCnt]; 
					Create(drFormData["RoleID"].ToString(), drFormData["UserID"].ToString(), drFormData["Buffer01"].ToString(), drFormData["Buffer02"].ToString(), drFormData["Buffer03"].ToString(), drFormData["Buffer04"].ToString(), drFormData["Buffer05"].ToString(), drFormData["IsActive"].ToString(), iTrans);
				}
			} 
			catch(Zaxis.Definitions.ZaxisException ex) 
			{
				ex.RowNumber = iRowCnt + 1; 
				throw ex; 
			} 
			return "";
		}

		#endregion

		#region Update

		/// <summary>
		/// Updates the exsting record from Procedure Table
		/// </summary>
		/// <param name="ProcedureID"></param>
		/// <param name="Name"></param>
		/// <param name="ProcedureCodeID"></param>
		/// <returns>True/False</returns>
		private string Update (string RoleID, string UserID, string Buffer01, string Buffer02, string Buffer03, string Buffer04, string Buffer05, string IsActive, IDbTransaction iTrans)
		{
			string strQuery = "";
			strQuery = "UPDATE User_Role SET UserID = '"+UserID+"',Buffer01 = '"+Buffer01+"',Buffer02 = '"+Buffer02+"',Buffer03 = '"+Buffer03+"',Buffer04 = '"+Buffer04+"',Buffer05 = '"+Buffer05+"',IsActive = '"+IsActive+"'" + " where RoleID = '"+RoleID+"'";
			if(dbInstance.ExecuteNonQuery(iTrans, CommandType.Text, strQuery) < 1) 
			{ 
				Zaxis.Definitions.ZaxisException ex = new Zaxis.Definitions.ZaxisException(); 
				throw ex; 
			} 
			return ""; 
		} 

		public string Update(DataSet dsFormData, string strTableName, IDbTransaction iTrans,Hashtable ht)
		{
			int iRowCount = 0;
			int iRowCnt = 0;
			if (dbInstance == null)
				throw new Exception("No Connection");
			DataRow drFormData;
			try
			{
				iRowCount = dsFormData.Tables[strTableName].Rows.Count;
				for(iRowCnt = 0; iRowCnt < iRowCount; iRowCnt++)
				{
					drFormData = dsFormData.Tables[strTableName].Rows[iRowCnt];
					string Status = drFormData["RowStatus"].ToString();
					switch(Status)
					{
						case "Insert":
							Create(drFormData["RoleID"].ToString(), drFormData["UserID"].ToString(), drFormData["Buffer01"].ToString(), drFormData["Buffer02"].ToString(), drFormData["Buffer03"].ToString(), drFormData["Buffer04"].ToString(), drFormData["Buffer05"].ToString(), drFormData["IsActive"].ToString(), iTrans);
							break;
						case "Update":
							Update(drFormData["RoleID"].ToString(), drFormData["UserID"].ToString(), drFormData["Buffer01"].ToString(), drFormData["Buffer02"].ToString(), drFormData["Buffer03"].ToString(), drFormData["Buffer04"].ToString(), drFormData["Buffer05"].ToString(), drFormData["IsActive"].ToString(), iTrans);
							break;
						case "Delete":
							Delete(drFormData["UserID"].ToString(), iTrans);
							break;
					}
				}
			}
			catch(Zaxis.Definitions.ZaxisException ex)
			{
				ex.RowNumber = iRowCnt + 1;
				throw ex;
			}
			return "";
		}
		#endregion

		#region Delete

		/// <summary>
		/// Deletes the Record from Database
		/// </summary>
		/// <param name="ProcedureID"></param>
		/// <param name="iTrans"></param>
		/// <returns></returns>
		private string Delete(string UserID, IDbTransaction iTrans)
		{
			string strQuery = "";
			strQuery=" Update  User_Role set IsActive = 0 WHERE  UserID = '"+ UserID +"'";
			dbInstance.ExecuteNonQuery(iTrans, CommandType.Text, strQuery);
			return ""; 
		} 

		public string Delete(DataSet dsFormData, string strTableName, IDbTransaction iTrans)
		{
			int iRowCnt=0;
			if (dbInstance == null)
				throw new Exception("No Connection");

			DataRow drFormData; 
			try 
			{ 
				int iRowCount = dsFormData.Tables[strTableName].Rows.Count; 
				for(iRowCnt = 0; iRowCnt < iRowCount; iRowCnt++) 
				{ 
					drFormData = dsFormData.Tables[strTableName].Rows[iRowCnt]; 
					Delete(drFormData["UserID"].ToString(), iTrans);
				}
			} 
			catch(Zaxis.Definitions.ZaxisException ex) 
			{
				ex.RowNumber = iRowCnt + 1; 
				throw ex; 
			} 
			return "";
		}
		#endregion
	}
}
