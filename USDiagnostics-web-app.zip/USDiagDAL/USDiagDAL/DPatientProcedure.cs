#region  Page Level Comments

/*******************************************************************************************
/*File Name	      :			DPatientProcedure.cs
 *Project Name    :			USD 1.0
 *Object          :			DAL
 *Purpose         :			
 *Author          :			Padma A
 *Date            :			27-5-2006 
 *ModuleName      :			USD
 *This file is provided as part of Zaxis-USD project.
 *Copyright � 2004-07, Zaxis-USD Technologies, All rights reserved
 * ************************************ Revision History************************************
 *
 *  Date            Done by             Method             Change Description

*******************************************************************************************/

#endregion

#region  NameSpace Declaration

//System NameSpaces

using System;
using System.Data;
using System.Collections;
using Microsoft.Practices.EnterpriseLibrary.Data;
//Zaxis-USD NameSpaces
using Zaxis.DataAccess;
using System.Data.SqlClient;

#endregion

namespace Zaxis.USD.DAL 
{
	public class DPatientProcedure : DALBase 
	{

		#region default constructor 

		/// <summary>
		///default constructor 
		/// </summary>
		public DPatientProcedure()
		{
		}
		
		#endregion

		#region Create

		/// <summary>
		/// Inserts new record into database
		/// </summary>
		/// <param name="ProcedureID"></param>
		/// <param name="Name"></param>
		/// <param name="ProcedureCodeID"></param>
		/// <returns></returns>
		/// 
		public string Create(string PatientID, string ProcedureID, string OrderID, string TechnicianID, string DueDate, string TestDate, string PriorityID, string ZoneID, string Comments, string StatusID, string OrderTyp, string Buffer01, string Buffer02, string Buffer03, string Buffer04, string Buffer05, string IsActive, IDbTransaction iTrans)
		{
			string strQuery = null;
			if(TechnicianID.Equals("null"))
				strQuery = @" INSERT INTO Patient_Procedure(PatientID, ProcedureID, OrderID, TechnicianID, DueDate, TestDate, PriorityID, ZoneID,Comments,StatusID,OrderTyp,Buffer01,Buffer02,Buffer03,Buffer04,Buffer05,IsActive)
					VALUES('" + PatientID +" ', '" + ProcedureID +" ', '" + OrderID +" ', "+ TechnicianID +", getdate(), '" + TestDate +" ', '" + PriorityID +" ', '" + ZoneID +" ', '" + Comments +" ', '" + StatusID +" ', '" + OrderTyp +" ', '" + Buffer01 +" ', '" + Buffer02 +" ', '" + Buffer03 +" ', '" + Buffer04 +" ', '" + Buffer05 +" ', '"+IsActive+"')";
			else
				strQuery = @" INSERT INTO Patient_Procedure(PatientID,ProcedureID,OrderID,TechnicianID,DueDate,TestDate,PriorityID,ZoneID,Comments,StatusID,OrderTyp,Buffer01,Buffer02,Buffer03,Buffer04,Buffer05,IsActive)
				VALUES('" + PatientID +" ', '" + ProcedureID +" ', '" + OrderID +" ', '"+ TechnicianID +" ', '" + DueDate +" ', '" + TestDate +" ', '" + PriorityID +" ', '" + ZoneID +" ', '" + Comments +" ', '" + StatusID +" ', '" + OrderTyp +" ', '" + Buffer01 +" ', '" + Buffer02 +" ', '" + Buffer03 +" ', '" + Buffer04 +" ', '" + Buffer05 +" ', '"+IsActive+"')";
			return dbInstance.ExecuteNonQuery(iTrans, CommandType.Text, strQuery).ToString();
		}

		public string Create(DataSet dsFormData, string strTableName, IDbTransaction iTrans,Hashtable ht)
		{
			int iRowCount=0;
			int iRowCnt=0;
			if (dbInstance == null)
				throw new Exception("No Connection");

			DataRow drFormData; 
			try 
			{ 
				iRowCount = dsFormData.Tables[strTableName].Rows.Count; 
				for(iRowCnt = 0; iRowCnt < iRowCount; iRowCnt++) 
				{ 
					drFormData = dsFormData.Tables[strTableName].Rows[iRowCnt]; 
					Create(drFormData["PatientID"].ToString(), drFormData["ProcedureID"].ToString(), drFormData["OrderID"].ToString(), drFormData["TechnicianID"].ToString(), drFormData["DueDate"].ToString(), drFormData["TestDate"].ToString(), drFormData["PriorityID"].ToString(), drFormData["ZoneID"].ToString(), drFormData["Comments"].ToString(), drFormData["StatusID"].ToString(), drFormData["OrderTyp"].ToString(), drFormData["Buffer01"].ToString(), drFormData["Buffer02"].ToString(), drFormData["Buffer03"].ToString(), drFormData["Buffer04"].ToString(), drFormData["Buffer05"].ToString(), drFormData["IsActive"].ToString(), iTrans);
				}
			} 
			catch(Zaxis.Definitions.ZaxisException ex) 
			{
				ex.RowNumber = iRowCnt + 1; 
				throw ex; 
			} 
			return "";
		}
		#endregion

		#region Update

		public string Update(string XmlString, IDbTransaction iTrans)
		{
//			Database db = DatabaseFactory.CreateDatabase();
//			DBCommandWrapper dbcw = db.GetStoredProcCommandWrapper("usp_UpdatePatientProcedure");
//			dbcw.AddInParameter("@inXmlDoc", DbType.String, XmlString);
			//db.ExecuteNonQuery(iTrans, 
			//SqlDataReader dr = (SqlDataReader)db.ExecuteReader(dbcw);
//			SqlParameter [] parms = {new SqlParameter("@inXmlDoc", SqlDbType.VarChar, 8000)};
//			parms[0].Value =  XmlString;
			Database db = DatabaseFactory.CreateDatabase();
			// Initialize the Stored Procedure
			DBCommandWrapper dbCommandWrapper = db.GetStoredProcCommandWrapper("usp_UpdatePatientProcedure");
			dbCommandWrapper.AddInParameter("@inXmlDoc", DbType.String, XmlString);
			//Execute the stored procedure
			db.ExecuteNonQuery(dbCommandWrapper, iTrans);


			//db.ExecuteNonQuery(dbcw);
			return "";
		}
	
		/// <summary>
		/// Updates the exsting record from Procedure Table
		/// </summary>
		/// <param name="ProcedureID"></param>
		/// <param name="Name"></param>
		/// <param name="ProcedureCodeID"></param>
		/// <returns>True/False</returns>
		private string Update (string PatientID, string ProcedureID, string OrderID, string TechnicianID, string DueDate, string TestDate, string PriorityID, string ZoneID, string Comments, string StatusID, string OrderTyp, string Buffer01, string Buffer02, string Buffer03, string Buffer04, string Buffer05, string IsActive, IDbTransaction iTrans)
		{
			string strQuery = "";
			strQuery = "Update Patient_Procedure SET TechnicianID = '"+TechnicianID+"',DueDate = '"+DueDate+"',TestDate = '"+TestDate+"',PriorityID = '"+PriorityID+"',ZoneID = '"+ZoneID+"',Comments = '"+Comments+"',StatusID = '"+StatusID+"',OrderTyp = '"+OrderTyp+"',Buffer01 = '"+Buffer01+"',Buffer02 = '"+Buffer02+"',Buffer03 = '"+Buffer03+"',Buffer04 = '"+Buffer04+"',Buffer05 = '"+Buffer05+"',IsActive = '"+IsActive+"'" + " where OrderID = '"+OrderID+"' and PatientID = '"+PatientID+"' AND ProcedureID = '"+ProcedureID+"' and isactive=1";
			if(dbInstance.ExecuteNonQuery(iTrans, CommandType.Text, strQuery) < 1) 
			{ 
				Zaxis.Definitions.ZaxisException ex = new Zaxis.Definitions.ZaxisException(); 
				throw ex; 
			} 
			return ""; 
		} 

		public string UpdateTechnician(DataSet dsFormData, string strTableName, IDbTransaction iTrans,Hashtable ht)
		{
			if (dbInstance == null)
				throw new Exception("No Connection");
			DataRow drFormData;
			try
			{
					drFormData = dsFormData.Tables[strTableName].Rows[0];
					string strQuery = "";
					strQuery = "Update Patient_Procedure SET StatusID = '"+drFormData["StatusID"].ToString()+"' where PatientID = '"+drFormData["PatientID"].ToString()+"' AND ProcedureID = '"+drFormData["ProcedureID"].ToString()+"'";
					if(dbInstance.ExecuteNonQuery(iTrans, CommandType.Text, strQuery) < 1) 
					{ 
						Zaxis.Definitions.ZaxisException ex = new Zaxis.Definitions.ZaxisException(); 
						throw ex; 
					} 
			}
			catch(Zaxis.Definitions.ZaxisException ex)
			{
				ex.RowNumber =  1;
				throw ex;
			}
			return "";
		}

		public string Update(DataSet dsFormData, string strTableName, IDbTransaction iTrans,Hashtable ht)
		{
			int iRowCount = 0;
			int iRowCnt = 0;
			if (dbInstance == null)
				throw new Exception("No Connection");
			DataRow drFormData;
			try
			{
				iRowCount = dsFormData.Tables[strTableName].Rows.Count;
				for(iRowCnt = 0; iRowCnt < iRowCount; iRowCnt++)
				{
					drFormData = dsFormData.Tables[strTableName].Rows[iRowCnt];
//					string Status = drFormData["RowStatus"].ToString();
//					switch(Status)
//					{
//						case "Insert":
//							Create(drFormData["PatientID"].ToString(), drFormData["ProcedureID"].ToString(), drFormData["OrderID"].ToString(), drFormData["TechnicianID"].ToString(), drFormData["DueDate"].ToString(), drFormData["TestDate"].ToString(), drFormData["PriorityID"].ToString(), drFormData["ZoneID"].ToString(), drFormData["Comments"].ToString(), drFormData["StatusID"].ToString(), drFormData["OrderTyp"].ToString(), drFormData["Buffer01"].ToString(), drFormData["Buffer02"].ToString(), drFormData["Buffer03"].ToString(), drFormData["Buffer04"].ToString(), drFormData["Buffer05"].ToString(), drFormData["IsActive"].ToString(), iTrans);
//							break;
//						case "Update":
							Update(drFormData["PatientID"].ToString(), drFormData["ProcedureID"].ToString(), drFormData["OrderID"].ToString(), drFormData["TechnicianID"].ToString(), drFormData["DueDate"].ToString(), drFormData["TestDate"].ToString(), drFormData["PriorityID"].ToString(), drFormData["ZoneID"].ToString(), drFormData["Comments"].ToString(), drFormData["StatusID"].ToString(), drFormData["OrderTyp"].ToString(), drFormData["Buffer01"].ToString(), drFormData["Buffer02"].ToString(), drFormData["Buffer03"].ToString(), drFormData["Buffer04"].ToString(), drFormData["Buffer05"].ToString(), drFormData["IsActive"].ToString(), iTrans);
							break;
//						case "Delete":
//							Delete(drFormData["PatientID"].ToString(),iTrans);
//							break;
//					}
				}
			}
			catch(Zaxis.Definitions.ZaxisException ex)
			{
				ex.RowNumber = iRowCnt + 1;
				throw ex;
			}
			return "";
		}
		#endregion

		#region Delete

		/// <summary>
		/// Deletes the Record from Database
		/// </summary>
		/// <param name="ProcedureID"></param>
		/// <param name="iTrans"></param>
		/// <returns></returns>
		private string Delete(string PatientID, string OrderID, IDbTransaction iTrans)
		{
			string strQuery = "";
			strQuery=" UPDATE Patient_Procedure SET IsActive = 0 WHERE  PatientID = '"+PatientID+"' and OrderID ='"+OrderID+"'";
			if(dbInstance.ExecuteNonQuery(iTrans, CommandType.Text, strQuery) < 1) 
			{ 
				Zaxis.Definitions.ZaxisException ex = new Zaxis.Definitions.ZaxisException(); 
				throw ex; 
			} 
			return ""; 
		} 

		public string Delete(DataSet dsFormData, string strTableName, IDbTransaction iTrans)
		{
			int iRowCnt=0;
			if (dbInstance == null)
				throw new Exception("No Connection");

			try 
			{ 
				if (dsFormData.Tables[strTableName].Rows.Count > 0)
					Delete(dsFormData.Tables[strTableName].Rows[0]["PatientID"].ToString(), dsFormData.Tables[strTableName].Rows[0]["OrderID"].ToString(), iTrans);

			} 
			catch(Zaxis.Definitions.ZaxisException ex) 
			{
				ex.RowNumber = iRowCnt + 1; 
				throw ex; 
			} 
			return "";
		}
		#endregion

	}
}
