#region  Page Level Comments

/*******************************************************************************************
/*File Name	      :			DOrder.cs
 *Project Name    :			USD 1.0
 *Object          :			DAL
 *Purpose         :			
 *Author          :			Padma A
 *Date            :			27-5-2006 
 *ModuleName      :			USD
 *This file is provided as part of Zaxis-USD project.
 *Copyright � 2004-07, Zaxis-USD Technologies, All rights reserved
 * ************************************ Revision History************************************
 *
 *  Date            Done by             Method             Change Description

*******************************************************************************************/

#endregion

#region  NameSpace Declaration

//System NameSpaces

using System;
using System.Data;
using System.Collections;

//Zaxis-USD NameSpaces
using Zaxis.DataAccess;

#endregion

namespace Zaxis.USD.DAL
{
	public class DOrder : DALBase 
	{

		#region default constructor 

		/// <summary>
		///default constructor 
		/// </summary>
		public DOrder()
		{
		}

		#endregion
	
		#region Create

		/// <summary>
		/// Inserts new record into database
		/// </summary>
		/// <param name="ProcedureID"></param>
		/// <param name="Name"></param>
		/// <param name="ProcedureCodeID"></param>
		/// <returns></returns>
		public string Create(string OrderID, string OrderDate, string Physician, string OrderingNurse, string SourceContactID, string ContactTypeID, string Signature, string Diagnosis, string CompanyID, string BranchID, string Buffer01, string Buffer02, string Buffer03, string Buffer04, string Buffer05, string IsActive, string OrderNo, IDbTransaction iTrans)
		{
			string strQuery = null;
			strQuery = @" INSERT INTO Orders(OrderID,OrderDate,Physician,OrderingNurse,SourceContactID,ContactTypeID,Signature,Diagnosis,CompanyID,BranchID, Buffer02,Buffer03,Buffer04,Buffer05,IsActive,OrderNo)
			 VALUES('"+ OrderID +" ', '"+ OrderDate +" ', '"+ Physician +" ', '"+ OrderingNurse +" ', '"+ SourceContactID +" ', '"+ ContactTypeID +" ', '"+ Signature +" ', '"+ Diagnosis +" ', '"+ CompanyID +" ', '"+ BranchID +" ', '"+ Buffer02 +" ', '"+ Buffer03 +" ', '"+ Buffer04 +" ', '"+ Buffer05 +" ', '"+ IsActive +" ', '"+OrderNo+"')";
			return dbInstance.ExecuteNonQuery(iTrans, CommandType.Text, strQuery).ToString();
		}


		public string Create(DataSet dsFormData, string strTableName, IDbTransaction iTrans,Hashtable ht)
		{
			int iRowCount=0;
			int iRowCnt=0;
			if (dbInstance == null)
				throw new Exception("No Connection");

			DataRow drFormData; 
			try 
			{ 
				iRowCount = dsFormData.Tables[strTableName].Rows.Count; 
				for(iRowCnt = 0; iRowCnt < iRowCount; iRowCnt++) 
				{ 
					drFormData = dsFormData.Tables[strTableName].Rows[iRowCnt]; 
					Create(drFormData["OrderID"].ToString(), drFormData["OrderDate"].ToString(), drFormData["Physician"].ToString(), drFormData["OrderingNurse"].ToString(), drFormData["SourceContactID"].ToString(), drFormData["ContactTypeID"].ToString(), drFormData["Signature"].ToString(), drFormData["Diagnosis"].ToString(), drFormData["CompanyID"].ToString(), drFormData["BranchID"].ToString(), drFormData["Buffer01"].ToString(), drFormData["Buffer02"].ToString(), drFormData["Buffer03"].ToString(), drFormData["Buffer04"].ToString(), drFormData["Buffer05"].ToString(), drFormData["IsActive"].ToString(), drFormData["OrderNo"].ToString(), iTrans);
				}
			} 
			catch(Zaxis.Definitions.ZaxisException ex) 
			{
				ex.RowNumber = iRowCnt + 1; 
				throw ex; 
			} 
			return "";
		}
		#endregion

		#region Update

		public int Update(string OrderID,  IDbTransaction iTrans)
		{
			string strQuery =  @"update Orders set OrderNo = OrderNo + '-' + cast(buffer01 as varchar) where OrderId='"+OrderID+"'"; 
			//string strQuery =  "update Orders set OrderNo = OrderNo + '-' + buffer01 where OrderId='"+OrderID+"'";
			return dbInstance.ExecuteNonQuery(iTrans, CommandType.Text,strQuery);
		}

		/// <summary>
		/// Updates the exsting record from Procedure Table
		/// </summary>
		/// <param name="ProcedureID"></param>
		/// <param name="Name"></param>
		/// <param name="ProcedureCodeID"></param>
		/// <returns>True/False</returns>
		private string Update (string OrderID, string OrderDate, string Physician, string OrderingNurse, string SourceContactID, string ContactTypeID, string Signature, string Diagnosis, string CompanyID, string BranchID, string Buffer01, string Buffer02, string Buffer03, string Buffer04, string Buffer05, string IsActive, string OrderNo, IDbTransaction iTrans)
		{
			string strQuery = "";
			strQuery = "update Orders SET OrderDate = '"+OrderDate+"',Physician = '"+Physician+"',OrderingNurse = '"+OrderingNurse+"',SourceContactID = '"+SourceContactID+"',ContactTypeID = '"+ContactTypeID+"',Signature = '"+Signature+"',Diagnosis = '"+Diagnosis+"',CompanyID = '"+CompanyID+"',BranchID = '"+BranchID+"', Buffer02 = '"+Buffer02+"',Buffer03 = '"+Buffer03+"',Buffer04 = '"+Buffer04+"',Buffer05 = '"+Buffer05+"',IsActive = '"+IsActive+"',OrderNo = '"+OrderNo+"'"+ " where OrderID = '"+OrderID+"'";
			if(dbInstance.ExecuteNonQuery(iTrans, CommandType.Text, strQuery) < 1) 
			{ 
				Zaxis.Definitions.ZaxisException ex = new Zaxis.Definitions.ZaxisException(); 
				throw ex; 
			} 
			return ""; 
		} 

		public string Update(DataSet dsFormData, string strTableName, IDbTransaction iTrans,Hashtable ht)
		{
			int iRowCount = 0;
			int iRowCnt = 0;
			if (dbInstance == null)
				throw new Exception("No Connection");
			DataRow drFormData;
			try
			{
				iRowCount = dsFormData.Tables[strTableName].Rows.Count;
				for(iRowCnt = 0; iRowCnt < iRowCount; iRowCnt++)
				{
					drFormData = dsFormData.Tables[strTableName].Rows[iRowCnt];
//					string Status = drFormData["RowStatus"].ToString();
//					switch(Status)
//					{
//						case "Insert":
//							Create(drFormData["OrderID"].ToString(), drFormData["OrderDate"].ToString(), drFormData["Physician"].ToString(), drFormData["OrderingNurse"].ToString(), drFormData["SourceContactID"].ToString(), drFormData["ContactTypeID"].ToString(), drFormData["Signature"].ToString(), drFormData["Diagnosis"].ToString(), drFormData["CompanyID"].ToString(), drFormData["BranchID"].ToString(), drFormData["Buffer01"].ToString(), drFormData["Buffer02"].ToString(), drFormData["Buffer03"].ToString(), drFormData["Buffer04"].ToString(), drFormData["Buffer05"].ToString(), drFormData["IsActive"].ToString(), drFormData["OrderNo"].ToString(), iTrans);
//							break;
//						case "Update":
							Update(drFormData["OrderID"].ToString(), drFormData["OrderDate"].ToString(), drFormData["Physician"].ToString(), drFormData["OrderingNurse"].ToString(), drFormData["SourceContactID"].ToString(), drFormData["ContactTypeID"].ToString(), drFormData["Signature"].ToString(), drFormData["Diagnosis"].ToString(), drFormData["CompanyID"].ToString(), drFormData["BranchID"].ToString(), drFormData["Buffer01"].ToString(), drFormData["Buffer02"].ToString(), drFormData["Buffer03"].ToString(), drFormData["Buffer04"].ToString(), drFormData["Buffer05"].ToString(), drFormData["IsActive"].ToString(), drFormData["OrderNo"].ToString(), iTrans);
//							break;
//						case "Delete":
//							Delete(drFormData["OrderID"].ToString(),iTrans);
//							break;
//					}
				}
			}
			catch(Zaxis.Definitions.ZaxisException ex)
			{
				ex.RowNumber = iRowCnt + 1;
				throw ex;
			}
			return "";
		}
		#endregion

		#region Delete

		/// <summary>
		/// Deletes the Record from Database
		/// </summary>
		/// <param name="ProcedureID"></param>
		/// <param name="iTrans"></param>
		/// <returns></returns>
		private string Delete(string OrderID,IDbTransaction iTrans)
		{
			string strQuery = "";
			strQuery=" update Orders set isactive = 0 WHERE  OrderID = '"+OrderID+"'";
			if(dbInstance.ExecuteNonQuery(iTrans, CommandType.Text, strQuery) < 1) 
			{ 
				Zaxis.Definitions.ZaxisException ex = new Zaxis.Definitions.ZaxisException(); 
				throw ex; 
			} 
			return ""; 
		} 

		public string Delete(DataSet dsFormData, string strTableName, IDbTransaction iTrans)
		{
			int iRowCount=0;
			int iRowCnt=0;
			if (dbInstance == null)
				throw new Exception("No Connection");

			DataRow drFormData; 
			try 
			{ 
				iRowCount = dsFormData.Tables[strTableName].Rows.Count; 
				for(iRowCnt = 0; iRowCnt < iRowCount; iRowCnt++) 
				{ 
					drFormData = dsFormData.Tables[strTableName].Rows[iRowCnt]; 
					Delete(drFormData["OrderID"].ToString(),iTrans);
				}
			} 
			catch(Zaxis.Definitions.ZaxisException ex) 
			{
				ex.RowNumber = iRowCnt + 1; 
				throw ex; 
			} 
			return "";
		}
		#endregion

	}
}
