#region  Page Level Comments

/*******************************************************************************************
/*File Name	      :			UserInfo.cs
 *Project Name    :			USD 1.0
 *Object          :			Zaxis.USD.DAL
 *Purpose         :			
 *Author          :			Padma A
 *Date            :			27-5-2006 
 *ModuleName      :			USD
 *This file is provided as part of Zaxis-USD project.
 *Copyright � 2004-07, Zaxis-USD Technologies, All rights reserved
 * ************************************ Revision History************************************
 *
 *  Date            Done by             Method             Change Description

*******************************************************************************************/

#endregion

#region  NameSpace Declaration

//System NameSpaces

using System;
using System.Data;
using System.Collections;

//Zaxis-USD NameSpaces
using Zaxis.DataAccess;

#endregion


namespace Zaxis.USD.DAL 
{
	public class DUserInfo : DALBase
	{
		#region Constructor
		//default constructor 
		public DUserInfo()
		{
		}
		#endregion

		#region Create

		/// <summary>
		/// 
		/// </summary>
		/// <param name="UserID"></param>
		/// <param name="LoginID"></param>
		/// <param name="Password"></param>
		/// <param name="Question"></param>
		/// <param name="Answer"></param>
		/// <param name="Technition"></param>
		/// <param name="ModifyRecord"></param>
		/// <param name="CompanyID"></param>
		/// <param name="BranchID"></param>
		/// <param name="Buffer01"></param>
		/// <param name="Buffer02"></param>
		/// <param name="Buffer03"></param>
		/// <param name="Buffer04"></param>
		/// <param name="Buffer05"></param>
		/// <param name="IsActive"></param>
		/// <param name="ContactID"></param>
		/// <param name="iTrans"></param>
		/// <returns></returns>

		public string Create(string UserID, string LoginID, string Password, string Question, string Answer, string Technition, string ModifyRecord, string CompanyID, string BranchID, string Buffer01, string Buffer02, string Buffer03, string Buffer04, string Buffer05, string IsActive, string ContactID, IDbTransaction iTrans)
		{
			string strQuery = @" INSERT INTO UserInfo(UserID, LoginID, Password, Question, Answer, Technition, ModifyRecord, CompanyID, BranchID, Buffer01, Buffer02, Buffer03, Buffer04, Buffer05, IsActive, ContactID) VALUES ('"+ UserID +"', '"+ LoginID +"', '"+ Password +"', '"+ Question +"', '"+ Answer +"', '"+ Technition +"', '"+ ModifyRecord +"', '"+ CompanyID +"', '"+ BranchID +"', '"+ Buffer01 +"', '"+ Buffer02 +"', '"+ Buffer03 +"', '"+ Buffer04 +"', '"+ Buffer05 +"', '"+ IsActive +"', '"+ ContactID +"')";
			return dbInstance.ExecuteNonQuery(iTrans,  CommandType.Text,  strQuery).ToString();
		}

		public string Create(DataSet dsFormData,  string strTableName,  IDbTransaction iTrans, Hashtable ht)
		{
			int iRowCount=0;
			int iRowCnt=0;
			
			if (dbInstance == null)
				throw new Exception("No Connection");
			DataRow drFormData;
			try 
			{ 
				iRowCount = dsFormData.Tables[strTableName].Rows.Count; 
				for(iRowCnt = 0; iRowCnt < iRowCount; iRowCnt++) 
				{ 
					drFormData = dsFormData.Tables[strTableName].Rows[iRowCnt]; 
					Create(drFormData["UserID"].ToString(), drFormData["LoginID"].ToString(), drFormData["Password"].ToString(), drFormData["Question"].ToString(), drFormData["Answer"].ToString(), drFormData["Technition"].ToString(), drFormData["ModifyRecord"].ToString(), drFormData["CompanyID"].ToString(), drFormData["BranchID"].ToString(), drFormData["Buffer01"].ToString(), drFormData["Buffer02"].ToString(), drFormData["Buffer03"].ToString(), drFormData["Buffer04"].ToString(), drFormData["Buffer05"].ToString(), drFormData["IsActive"].ToString(), drFormData["ContactID"].ToString(), iTrans);
				}
			} 
			catch(Zaxis.Definitions.ZaxisException ex) 
			{
				ex.RowNumber = iRowCnt + 1; 
				throw ex; 
			} 
			return "";
		}
		#endregion

		#region Update

		private string Update (string UserID, string LoginID, string Password, string Question, string Answer, string Technition, string ModifyRecord, string CompanyID, string BranchID, string Buffer01, string Buffer02, string Buffer03, string Buffer04, string Buffer05, string IsActive, string ContactID, IDbTransaction iTrans)
		{
			string strQuery = "";
			strQuery = "update UserInfo SET LoginID = '"+ LoginID +"', Password = '"+ Password +"', Question = '"+ Question +"', Answer = '"+ Answer +"', Technition = '"+ Technition +"', ModifyRecord = '"+ ModifyRecord +"', CompanyID = '"+ CompanyID +"', BranchID = '"+ BranchID +"', Buffer01 = '"+ Buffer01 +"', Buffer02 = '"+ Buffer02 +"', Buffer03 = '"+ Buffer03 +"', Buffer04 = '"+ Buffer04 +"', Buffer05 = '"+ Buffer05 +"', IsActive = '"+ IsActive +"', ContactID = '"+ ContactID +"'" + " where UserID = '"+ UserID +"'";
			if(dbInstance.ExecuteNonQuery(iTrans,  CommandType.Text,  strQuery) < 1) 
			{ 
				Zaxis.Definitions.ZaxisException ex = new Zaxis.Definitions.ZaxisException(); 
				throw ex; 
			} 
			return ""; 
		} 

		public string Update(DataSet dsFormData,  string strTableName,  IDbTransaction iTrans, Hashtable ht)
		{
			int iRowCount = 0;
			int iRowCnt = 0;
			if (dbInstance == null)
				throw new Exception("No Connection");
			DataRow drFormData;
			try
			{
				iRowCount = dsFormData.Tables[strTableName].Rows.Count;
				for(iRowCnt = 0; iRowCnt < iRowCount; iRowCnt++)
				{
					drFormData = dsFormData.Tables[strTableName].Rows[iRowCnt];
//					string Status = drFormData["RowStatus"].ToString();
//					switch(Status)
//					{
//						case "Insert":
//							Create(drFormData["UserID"].ToString(), drFormData["LoginID"].ToString(), drFormData["Password"].ToString(), drFormData["Question"].ToString(), drFormData["Answer"].ToString(), drFormData["Technition"].ToString(), drFormData["ModifyRecord"].ToString(), drFormData["CompanyID"].ToString(), drFormData["BranchID"].ToString(), drFormData["Buffer01"].ToString(), drFormData["Buffer02"].ToString(), drFormData["Buffer03"].ToString(), drFormData["Buffer04"].ToString(), drFormData["Buffer05"].ToString(), drFormData["IsActive"].ToString(), drFormData["ContactID"].ToString(), iTrans);
//							break;
//						case "Update":
							Update(drFormData["UserID"].ToString(), drFormData["LoginID"].ToString(), drFormData["Password"].ToString(), drFormData["Question"].ToString(), drFormData["Answer"].ToString(), drFormData["Technition"].ToString(), drFormData["ModifyRecord"].ToString(), drFormData["CompanyID"].ToString(), drFormData["BranchID"].ToString(), drFormData["Buffer01"].ToString(), drFormData["Buffer02"].ToString(), drFormData["Buffer03"].ToString(), drFormData["Buffer04"].ToString(), drFormData["Buffer05"].ToString(), drFormData["IsActive"].ToString(), drFormData["ContactID"].ToString(), iTrans);
//							break;
//						case "Delete":
//							Delete(drFormData["UserID"].ToString(), iTrans);
//							break;
//					}
				}
			}
			catch(Zaxis.Definitions.ZaxisException ex)
			{
				ex.RowNumber = iRowCnt + 1;
				throw ex;
			}
			return "";
		}

		#endregion

		#region Delete

		/// <summary>
		/// 
		/// </summary>
		/// <param name="UserID"></param>
		/// <param name="iTrans"></param>
		/// <returns></returns>

		private string Delete(string UserID, IDbTransaction iTrans)
		{
			string strQuery = "";
			strQuery=" Update UserInfo set IsActive = 0 WHERE  UserID = '"+ UserID +"'";
			return dbInstance.ExecuteNonQuery(iTrans,  CommandType.Text,  strQuery).ToString();
//			if(dbInstance.ExecuteNonQuery(iTrans,  CommandType.Text,  strQuery) < 1) 
//			{ 
//				Zaxis.Definitions.ZaxisException ex = new Zaxis.Definitions.ZaxisException(); 
//				throw ex; 
//			} 
			//return ""; 
		} 

		public string Delete(DataSet dsFormData,  string strTableName,  IDbTransaction iTrans)
		{
			int iRowCnt = 0;
			if (dbInstance == null)
				throw new Exception("No Connection");
			DataRow drFormData;
			try 
			{
				int iRowCount = dsFormData.Tables[strTableName].Rows.Count; 
				for(iRowCnt = 0; iRowCnt < iRowCount; iRowCnt++) 
				{
					drFormData = dsFormData.Tables[strTableName].Rows[iRowCnt]; 
					Delete(drFormData["UserID"].ToString(), iTrans);
				}
			} 
			catch(Zaxis.Definitions.ZaxisException ex) 
			{
				ex.RowNumber = 1; 
				throw ex; 
			} 
			return "";
		}

		#endregion
	}
}
