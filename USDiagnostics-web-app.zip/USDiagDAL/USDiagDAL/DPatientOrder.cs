#region  Page Level Comments

/*******************************************************************************************
/*File Name	      :			DOrder.cs
 *Project Name    :			USD 1.0
 *Object          :			DAL
 *Purpose         :			
 *Author          :			Desayya N
 *Date            :			27-5-2006 
 *ModuleName      :			USD
 *This file is provided as part of Zaxis-USD project.
 *Copyright � 2004-07, Zaxis-USD Technologies, All rights reserved
 * ************************************ Revision History************************************
 *
 *  Date            Done by             Method             Change Description

*******************************************************************************************/

#endregion

#region  NameSpace Declaration

//System NameSpaces

using System;
using System.Data;
using System.Collections;

//Zaxis-USD NameSpaces
using Zaxis.DataAccess;

#endregion
namespace Zaxis.USD.DAL
{
	public class DPatientOrder : DALBase
	{
		//default constructor 
		public DPatientOrder()
		{
		}

		public string Create(string PatientID, string OrderID, IDbTransaction iTrans)
		{
			string strQuery = null;
			strQuery = " INSERT INTO Patient_Order(PatientID,OrderID)VALUES('"+PatientID+"','"+OrderID+"')";
			return dbInstance.ExecuteNonQuery(iTrans, CommandType.Text, strQuery).ToString();
		}

		public string Create(DataSet dsFormData, string strTableName, IDbTransaction iTrans,Hashtable ht)
		{
			int iRowCount=0;
			int iRowCnt=0;
			if (dbInstance == null)
				throw new Exception("No Connection");
			DataRow drFormData; 
			try 
			{ 
				iRowCount = dsFormData.Tables[strTableName].Rows.Count; 
				for(iRowCnt = 0; iRowCnt < iRowCount; iRowCnt++) 
				{ 
					drFormData = dsFormData.Tables[strTableName].Rows[iRowCnt]; 
					Create(drFormData["PatientID"].ToString(),drFormData["OrderID"].ToString(), iTrans);
				}
			} 
			catch(Zaxis.Definitions.ZaxisException ex) 
			{
				ex.RowNumber = iRowCnt + 1; 
				throw ex; 
			} 
			return "";
		}

		private string Update (string PatientID, string OrderID, IDbTransaction iTrans)
		{
			string strQuery = "";
			strQuery = "Patient_Order SET OrderID = '"+OrderID+"'" + " where PatientID = '"+PatientID+"'";
			if(dbInstance.ExecuteNonQuery(iTrans, CommandType.Text, strQuery) < 1) 
			{ 
				Zaxis.Definitions.ZaxisException ex = new Zaxis.Definitions.ZaxisException(); 
				throw ex;
			} 
			return ""; 
		} 

		public string Update(DataSet dsFormData, string strTableName, IDbTransaction iTrans,Hashtable ht)
		{
			int iRowCount = 0;
			int iRowCnt = 0;
			if (dbInstance == null)
				throw new Exception("No Connection");
			DataRow drFormData;
			try
			{
				iRowCount = dsFormData.Tables[strTableName].Rows.Count;
				for(iRowCnt = 0; iRowCnt < iRowCount; iRowCnt++)
				{
					drFormData = dsFormData.Tables[strTableName].Rows[iRowCnt];
					string Status = drFormData["RowStatus"].ToString();
					switch(Status)
					{
						case "Insert":
							Create(drFormData["PatientID"].ToString(),drFormData["OrderID"].ToString(), iTrans);
							break;
						case "Update":
							Update(drFormData["PatientID"].ToString(),drFormData["OrderID"].ToString(), iTrans);
							break;
						case "Delete":
							Delete(drFormData["PatientID"].ToString(),iTrans);
							break;
					}
				}
			}
			catch(Zaxis.Definitions.ZaxisException ex)
			{
				ex.RowNumber = iRowCnt + 1;
				throw ex;
			}
			return "";
		}

		private string Delete(string PatientID,IDbTransaction iTrans)
		{
			string strQuery = "";
			strQuery=" DELETE  Patient_Order WHERE  PatientID = '"+PatientID+"'";
			if(dbInstance.ExecuteNonQuery(iTrans, CommandType.Text, strQuery) < 1) 
			{ 
				Zaxis.Definitions.ZaxisException ex = new Zaxis.Definitions.ZaxisException(); 
				throw ex; 
			} 
			return ""; 
		} 

		public string Delete(DataSet dsFormData, string strTableName, IDbTransaction iTrans)
		{
			int iRowCount=0;
			int iRowCnt=0;
			if (dbInstance == null)
				throw new Exception("No Connection");

			DataRow drFormData; 
			try 
			{ 
				iRowCount = dsFormData.Tables[strTableName].Rows.Count; 
				for(iRowCnt = 0; iRowCnt < iRowCount; iRowCnt++) 
				{ 
					drFormData = dsFormData.Tables[strTableName].Rows[iRowCnt]; 
					Delete(drFormData["PatientID"].ToString(),iTrans);
				}
			} 
			catch(Zaxis.Definitions.ZaxisException ex) 
			{
				ex.RowNumber = iRowCnt + 1; 
				throw ex; 
			} 
			return "";
		}

	}
}
