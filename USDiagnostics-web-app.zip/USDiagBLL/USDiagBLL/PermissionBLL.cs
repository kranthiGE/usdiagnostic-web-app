#region  Page Level Comments

/*******************************************************************************************
/*File Name	      :			PermissionBLL.cs
 *Project Name    :			USD 1.0
 *Object          :			Business Logic
 *Purpose         :			
 *Author          :			Adiseshu.D
 *Date            :			27-5-2006 
 *ModuleName      :			USD
 *This file is provided as part of Zaxis-USD project.
 *Copyright � 2004-07, Zaxis-USD Technologies, All rights reserved
 * ************************************ Revision History************************************
 *
 *  Date            Done by             Method             Change Description

*******************************************************************************************/

#endregion

#region  NameSpace Declaration

//System NameSpaces

using System;
using System.Data;

//Zaxis-USD NameSpaces
using Zaxis.Definitions;
using Zaxis.BaseClasses;
using Zaxis.USD.DAL;

#endregion

namespace Zaxis.USD.BusinessLogic
{
	/// <summary>
	/// Summary description for Permissions.
	/// </summary>
	public class PermissionBLL :FBase
	{
		public PermissionBLL()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		#region Create

		/// <summary>
		/// Inserts new data into database
		/// and executes the business logic
		/// </summary>
		/// <param name="data">Business Data Object</param>
		private void Create(BusinessData data)
		{

			DPermission permission = null;
			try
			{
				permission = new DPermission();				
				permission.Create("",data.NewEntity.Tables[0].Rows[0].ItemArray[1].ToString(),"1", data.Transaction);
			}
			catch(ZaxisException ex)
			{
				data.Response.ExceptionObject = ex;
				data.Response.Status = Zaxis.Definitions.Common.Status.Failed;
			}
			catch(Exception ex)
			{
				ZaxisException exception = new ZaxisException();
				exception.MessageString = ex.Message;
				data.Response.ExceptionObject = exception;
				data.Response.Status = Zaxis.Definitions.Common.Status.Failed;
				exception = null;
			}
			finally
			{
				permission = null;
			}

		}

		#endregion

		#region Update

		/// <summary>
		/// Update the data from database
		/// </summary>
		/// <param name="data">Business Data Object</param>
		private void Update(BusinessData data)
		{
			DPermission permission = null;
			try
			{
				permission = new DPermission();
				//role.Create("",data.NewEntity.Tables[0].Rows[0].ItemArray[1].ToString(),"1", data.Transaction);
				permission.Update(data.NewEntity, "Permission", data.Transaction, null);
			}
			catch(ZaxisException ex)
			{
				data.Response.ExceptionObject = ex;
				data.Response.Status = Zaxis.Definitions.Common.Status.Failed;
			}
			catch(Exception ex)
			{
				ZaxisException exception = new ZaxisException();
				exception.MessageString = ex.Message;
				data.Response.ExceptionObject = exception;
				data.Response.Status = Zaxis.Definitions.Common.Status.Failed;
				exception = null;
			}
			finally
			{
				permission = null;
			}	
		}

		#endregion

		#region Delete

		/// <summary>
		/// Delete record from the database
		/// </summary>
		/// <param name="data">Business Data Object</param>
		private void Delete(BusinessData data)
		{
			DPermission permission = null;
			try
			{
				permission = new DPermission();
				permission.Delete(data.NewEntity, "Permission", data.Transaction);
			}
			catch(ZaxisException ex)
			{
				data.Response.ExceptionObject = ex;
				data.Response.Status = Zaxis.Definitions.Common.Status.Failed;
			}
			catch(Exception ex)
			{
				ZaxisException exception = new ZaxisException();
				exception.MessageString = ex.Message;
				data.Response.ExceptionObject = exception;
				data.Response.Status = Zaxis.Definitions.Common.Status.Failed;
				exception = null;
				data.Transaction.Rollback();
			}
			finally
			{
				permission = null;
			}	
		}

		#endregion
	}
}
