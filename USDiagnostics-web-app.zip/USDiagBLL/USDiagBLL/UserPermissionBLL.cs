#region  Page Level Comments

/*******************************************************************************************
/*File Name	      :			UserPermissionBLL.cs
 *Project Name    :			USD 1.0
 *Object          :			Business Logic
 *Purpose         :			
 *Author          :			Adiseshu.D
 *Date            :			27-5-2006 
 *ModuleName      :			USD
 *This file is provided as part of Zaxis-USD project.
 *Copyright � 2004-07, Zaxis-USD Technologies, All rights reserved
 * ************************************ Revision History************************************
 *
 *  Date            Done by             Method             Change Description

*******************************************************************************************/

#endregion

#region  NameSpace Declaration

//System NameSpaces

using System;
using System.Data;

//Zaxis-USD NameSpaces
using Zaxis.Definitions;
using Zaxis.BaseClasses;
using Zaxis.USD.DAL;

#endregion


namespace Zaxis.USD.BusinessLogic
{
	/// <summary>
	/// Summary description for UserPermissionBLL.
	/// </summary>
	public class UserPermissionBLL :FBase
	{
		public UserPermissionBLL()
		{
			//
			// TODO: Add constructor logic here
			//
		}
		#region Update

		/// <summary>
		/// Update the data from database
		/// </summary>
		/// <param name="data">Business Data Object</param>
		private void Update(BusinessData data)
		{
			DUserPermission UserPer = null;
			try
			{
				UserPer = new DUserPermission();
				UserPer.Update(data.NewEntity,data.Transaction, null);
				
				// Inserting the data into History Table
				DHistory history = new DHistory();
				history.Create(data.UserID, "8", data.Action, data.NewEntity.Tables["Users"].Rows[0]["UserId"].ToString(),"", data.Transaction);
				history = null;
			}
			catch(ZaxisException ex)
			{
				data.Response.ExceptionObject = ex;
				data.Response.Status = Zaxis.Definitions.Common.Status.Failed;
				
			}
			catch(Exception ex)
			{
				ZaxisException exception = new ZaxisException();
				exception.MessageString = ex.Message;
				data.Response.ExceptionObject = exception;
				data.Response.Status = Zaxis.Definitions.Common.Status.Failed;
				exception = null;
			}
			finally
			{
				UserPer = null;
			}	
		}

		#endregion
	}
}
