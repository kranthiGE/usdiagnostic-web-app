
#region  Page Level Comments

/*******************************************************************************************
/*File Name	      :			AccountBLL.cs
 *Project Name    :			USD 1.0
 *Object          :			Business Logic
 *Purpose         :			
 *Author          :			Padma A
 *Date            :			27-5-2006 
 *ModuleName      :			USD
 *This file is provided as part of Zaxis-USD project.
 *Copyright � 2004-07, Zaxis-USD Technologies, All rights reserved
 * ************************************ Revision History************************************
 *
 *  Date            Done by             Method             Change Description

*******************************************************************************************/

#endregion

#region  NameSpace Declaration

//System NameSpaces

using System;
using System.Data;

//Zaxis-USD NameSpaces
using Zaxis.Definitions;
using Zaxis.BaseClasses;
using Zaxis.USD.DAL;

#endregion

namespace Zaxis.USD.BusinessLogic
{

	/// <summary>
	/// Business logic for Accounts. This Class will validate the 
	/// Data and pass the data to DAL layer for CRUD operations
	/// </summary>
	public class AccountBLL : FBase
	{

		#region Constructor

		/// <summary>
		/// Empty Construtor
		/// </summary>
		public AccountBLL()
		{
		}
		#endregion

		#region Create

		/// <summary>
		/// Inserts new data into database
		/// and executes the business logic
		/// </summary>
		/// <param name="data">Business Data Object</param>
		private void Create(BusinessData data)
		{
			DUserInfo user = null;
			DContact contact = null;
			DUserRole userrole = null;

			string strContactID = Guid.NewGuid().ToString();
			DataSet dsUser = data.NewEntity;
			try
			{
				contact = new DContact();
				dsUser.Tables["Contact"].Rows[0]["ContactID"] = strContactID;
				contact.Create(data.NewEntity, "Contact", data.Transaction, data.HashValues); 

				user = new DUserInfo();
				dsUser.Tables["UserInfo"].Rows[0]["ContactID"] = strContactID;
				user.Create(data.NewEntity, "UserInfo", data.Transaction, data.HashValues); 
				
				
				userrole = new DUserRole();
				userrole.Create(data.NewEntity, "UserRole", data.Transaction, data.HashValues); 

				// Inserting the data into History Table
				DHistory history = new DHistory();
				history.Create(data.UserID, "7", data.Action, data.NewEntity.Tables["UserInfo"].Rows[0]["UserID"].ToString(),  "", data.Transaction);
				history = null;

			}
			catch(ZaxisException ex)
			{
				data.Response.ExceptionObject = ex;
				data.Response.Status = Zaxis.Definitions.Common.Status.Failed;
			}
			catch(Exception ex)
			{
				ZaxisException exception = new ZaxisException();
				exception.MessageString = ex.Message;
				data.Response.ExceptionObject = exception;
				data.Response.Status = Zaxis.Definitions.Common.Status.Failed;
				exception = null;
			}
			finally
			{
				user = null;
				contact = null;
				userrole = null;
			}
		}

		#endregion

		#region Update

		/// <summary>
		/// Update the data from database
		/// </summary>
		/// <param name="data">Business Data Object</param>
		private void Update(BusinessData data)
		{
			DUserInfo user = null;
			DContact contact = null;
			DUserRole userrole = null;
			DataSet dsUser = data.NewEntity;
			try
			{
				contact = new DContact();
				contact.Update(dsUser, "Contact", data.Transaction, data.HashValues); 
				dsUser.Tables["UserInfo"].Rows[0]["ContactID"] = dsUser.Tables["Contact"].Rows[0]["ContactID"];
				user = new DUserInfo();
				user.Update(dsUser, "UserInfo", data.Transaction, data.HashValues); 
				
				userrole = new DUserRole();
				userrole.Delete(dsUser, "UserRole", data.Transaction);
				userrole.Create(dsUser, "UserRole", data.Transaction, data.HashValues); 

				// Inserting the data into History Table
				DHistory history = new DHistory();
				history.Create(data.UserID, "8", data.Action, data.NewEntity.Tables["UserInfo"].Rows[0]["UserID"].ToString(),"", data.Transaction);
				history = null;

			}
			catch(ZaxisException ex)
			{
				data.Response.ExceptionObject = ex;
				data.Response.Status = Zaxis.Definitions.Common.Status.Failed;
			}
			catch(Exception ex)
			{
				ZaxisException exception = new ZaxisException();
				exception.MessageString = ex.Message;
				data.Response.ExceptionObject = exception;
				data.Response.Status = Zaxis.Definitions.Common.Status.Failed;
				exception = null;
			}
			finally
			{
				user = null;
				contact = null;
				userrole = null;
			}
		}

		#endregion

		#region Delete

		/// <summary>
		/// Delete record from the database
		/// </summary>
		/// <param name="data">Business Data Object</param>
		private void Delete(BusinessData data)
		{
			DUserInfo user = null;
			DContact contact = null;
			DUserRole userrole = null;
			try
			{
				contact = new DContact();
				contact.Delete(data.NewEntity, "Contact", data.Transaction); 
				user = new DUserInfo();
				user.Delete(data.NewEntity, "UserInfo", data.Transaction); 
				userrole = new DUserRole();
				userrole.Delete(data.NewEntity, "UserRole", data.Transaction); 

				// Inserting the data into History Table
				DHistory history = new DHistory();
				for(int iCount=0; iCount < data.NewEntity.Tables["UserInfo"].Rows.Count; iCount++)
					history.Create(data.UserID, "6", data.Action, data.NewEntity.Tables["UserInfo"].Rows[iCount]["UserID"].ToString(),"", data.Transaction);
				history = null;

			}
			catch(ZaxisException ex)
			{
				data.Response.ExceptionObject = ex;
				data.Response.Status = Zaxis.Definitions.Common.Status.Failed;
			}
			catch(Exception ex)
			{
				ZaxisException exception = new ZaxisException();
				exception.MessageString = ex.Message;
				data.Response.ExceptionObject = exception;
				data.Response.Status = Zaxis.Definitions.Common.Status.Failed;
				exception = null;
			}
			finally
			{
				user = null;
				contact = null;
				userrole = null;
			}
		}

		#endregion
	}
}
