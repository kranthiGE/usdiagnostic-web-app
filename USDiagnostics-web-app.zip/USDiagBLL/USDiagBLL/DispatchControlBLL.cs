#region  Page Level Comments

/*******************************************************************************************
/*File Name	      :			DispatchControlBLL.cs
 *Project Name    :			USD 1.0
 *Object          :			Business Logic
 *Purpose         :			
 *Author          :			Desayya.N
 *Date            :			4-7-2006 
 *ModuleName      :			USD
 *This file is provided as part of Zaxis-USD project.
 *Copyright � 2004-07, Zaxis-USD Technologies, All rights reserved
 * ************************************ Revision History************************************
 *
 *  Date            Done by             Method             Change Description

*******************************************************************************************/

#endregion

#region  NameSpace Declaration

//System NameSpaces

using System;
using System.Data;
using System.Collections;
using System.Data.SqlClient;
//Zaxis-USD NameSpaces
using Zaxis.Definitions;
using Zaxis.BaseClasses;
using Zaxis.USD.DAL;


#endregion

namespace Zaxis.USD.BusinessLogic
{
	/// <summary>
	/// Summary description for DispatchControlBLL.
	/// </summary>
	public class DispatchControlBLL : FBase
	{
		#region Constructor

		public DispatchControlBLL()
		{
		}

		#endregion

		#region Getdata

		/// <summary>
		/// 
		/// 
		/// </summary>
		/// <param name="strProcedureName"></param>
		/// <param name="htValues"></param>
		/// <returns></returns>
		#endregion

	}
}
