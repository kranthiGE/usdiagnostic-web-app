
#region  Page Level Comments

/*******************************************************************************************
/*File Name	      :			ProcedureBLL.cs
 *Project Name    :			USD 1.0
 *Object          :			Business Logic
 *Purpose         :			
 *Author          :			Padma A
 *Date            :			27-5-2006 
 *ModuleName      :			USD
 *This file is provided as part of Zaxis-USD project.
 *Copyright � 2004-07, Zaxis-USD Technologies, All rights reserved
 * ************************************ Revision History************************************
 *
 *  Date            Done by             Method             Change Description

*******************************************************************************************/

#endregion

#region  NameSpace Declaration

//System NameSpaces

using System;
using System.Data;

//Zaxis-USD NameSpaces
using Zaxis.Definitions;
using Zaxis.BaseClasses;
using Zaxis.USD.DAL;

#endregion

namespace Zaxis.USD.BusinessLogic
{
	/// <summary>
	/// Summary description for ProcedureBLL.
	/// </summary>
	public class ProcedureBLL : FBase
	{

		#region Constructor

		/// <summary>
		/// Empty Construtor
		/// </summary>
		public ProcedureBLL()
		{
		}

		#endregion
		
		#region Create

		/// <summary>
		/// Inserts new data into database
		/// and executes the business logic
		/// </summary>
		/// <param name="data">Business Data Object</param>
		private void Create(BusinessData data)
		{

			DProcedure procedure = null;
			try
			{
				procedure = new DProcedure();
				procedure.Create(data.NewEntity, "UserInfo", data.Transaction, null);

				// Inserting the data into History Table
				DHistory history = new DHistory();
				history.Create(data.UserID, "7", data.Action, data.NewEntity.Tables["UserInfo"].Rows[0]["ProcedureID"].ToString(), "", data.Transaction);
				history = null;

			}
			catch(ZaxisException ex)
			{
				data.Response.ExceptionObject = ex;
				data.Response.Status = Zaxis.Definitions.Common.Status.Failed;
			}
			catch(Exception ex)
			{
				ZaxisException exception = new ZaxisException();
				exception.MessageString = ex.Message;
				data.Response.ExceptionObject = exception;
				data.Response.Status = Zaxis.Definitions.Common.Status.Failed;
				exception = null;
			}
			finally
			{
				procedure = null;
			}

		}

		#endregion

		#region Update

		/// <summary>
		/// Update the data from database
		/// </summary>
		/// <param name="data">Business Data Object</param>
		private void Update(BusinessData data)
		{
			DProcedure procedure = null;
			try
			{
				procedure = new DProcedure();
				procedure.Update(data.NewEntity, "UserInfo", data.Transaction, null);

				// Inserting the data into History Table
				DHistory history = new DHistory();
				history.Create(data.UserID, "8", data.Action, data.NewEntity.Tables["UserInfo"].Rows[0]["ProcedureID"].ToString(),"", data.Transaction);
				history = null;

			}
			catch(ZaxisException ex)
			{
				data.Response.ExceptionObject = ex;
				data.Response.Status = Zaxis.Definitions.Common.Status.Failed;
			}
			catch(Exception ex)
			{
				ZaxisException exception = new ZaxisException();
				exception.MessageString = ex.Message;
				data.Response.ExceptionObject = exception;
				data.Response.Status = Zaxis.Definitions.Common.Status.Failed;
				exception = null;
			}
			finally
			{
				procedure = null;
			}	
		}

		#endregion

		#region Delete

		/// <summary>
		/// Delete record from the database
		/// </summary>
		/// <param name="data">Business Data Object</param>
		private void Delete(BusinessData data)
		{
			DProcedure procedure = null;
			try
			{
				procedure = new DProcedure();
				procedure.Delete(data.NewEntity, "UserInfo", data.Transaction);

				// Inserting the data into History Table
				DHistory history = new DHistory();
				for(int iCount=0; iCount < data.NewEntity.Tables["UserInfo"].Rows.Count; iCount++)
					history.Create(data.UserID, "6", data.Action, data.NewEntity.Tables["UserInfo"].Rows[iCount]["ProcedureID"].ToString(),"", data.Transaction);
				history = null;

			}
			catch(ZaxisException ex)
			{
				data.Response.ExceptionObject = ex;
				data.Response.Status = Zaxis.Definitions.Common.Status.Failed;
			}
			catch(Exception ex)
			{
				ZaxisException exception = new ZaxisException();
				exception.MessageString = ex.Message;
				data.Response.ExceptionObject = exception;
				data.Response.Status = Zaxis.Definitions.Common.Status.Failed;
				exception = null;
			}
			finally
			{
				procedure = null;
			}	
		}

		#endregion
	}
}
