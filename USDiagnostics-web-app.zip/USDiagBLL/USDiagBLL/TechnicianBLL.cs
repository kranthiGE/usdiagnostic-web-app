using System;
using System.Data;
using System.Collections;

using Zaxis.BaseClasses;
using Zaxis.Common;
using Zaxis.Definitions;
using Zaxis.USD.DAL;

using System.Data.SqlClient;

using System.Collections;
namespace Zaxis.USD.BusinessLogic
{
	/// <summary>
	/// Summary description for Class1.
	/// </summary>
	public class TechnicianBLL : FBase
	{
		private  Zaxis.USD.DAL.DTechnician objTecDal = new DTechnician();
		public TechnicianBLL()
		{
			//
			// TODO: Add constructor logic here
			//
			
		}

		public DataSet GetData(string strProcedureName)
		{
			try
			{
				return objTecDal.ExecuteDataset(CommandType.StoredProcedure, strProcedureName);
			}
			catch(Exception ex)
			{
				return null;
			}
		
		}

		public DataSet GetData(string strProcedureName,Hashtable htValues)
		{
			try

			{
				
				int iParamCount = htValues.Count;
				int iCtr = 0;
				IDictionaryEnumerator oEnum = htValues.GetEnumerator();
				

				SqlParameter[] arParams = new SqlParameter[iParamCount];

				
				while(oEnum.MoveNext())
				{
				
					arParams[iCtr] = new SqlParameter(oEnum.Key.ToString(), oEnum.Value);
					iCtr++;
				}
								
							
				return objTecDal.ExecuteDataset(CommandType.StoredProcedure, strProcedureName, arParams);
			}
			catch(Exception ex)
			{
				return null;
			}
		
		}
		public void Create(BusinessData data)
		{
		
		}
		
		/// <summary>
		/// Update the data from database
		/// </summary>
		/// <param name="data">Business Data Object</param>
		private void Update(BusinessData data)
		{
			DTechnician oTechnician = null;
			try
			{
				oTechnician = new DTechnician();
				oTechnician.Update(data.NewEntity, "TechOrderStatus", data.Transaction, null);

				// Inserting the data into History Table
				DHistory history = new DHistory();
				history.Create(data.UserID, "8", data.Action, data.NewEntity.Tables["TechOrderStatus"].Rows[0]["OrderID"].ToString(),"", data.Transaction);
				history = null;

			}
			catch(ZaxisException ex)
			{
				data.Response.ExceptionObject = ex;
				data.Response.Status = Zaxis.Definitions.Common.Status.Failed;
			}
			catch(Exception ex)
			{
				ZaxisException exception = new ZaxisException();
				exception.MessageString = ex.Message;
				data.Response.ExceptionObject = exception;
				data.Response.Status = Zaxis.Definitions.Common.Status.Failed;
				exception = null;
			}
			finally
			{
				oTechnician = null;
			}	
		}
		public  DataSet GetDataSet(string strQuery)
		{
			 
			objTecDal = new DTechnician();
			DataSet dsData = objTecDal.GetDataSet(strQuery);
			return dsData;
			
		}
		
	}

	public class Oueries
	{
		public Oueries()
		{
			//
			// TODO: Add constructor logic here
			//
		}
		public static string GetQuery(string strQueryName,string strWhere)
		{
			return Queries.GetQuery(strQueryName,strWhere);
		}
	}

	
}
