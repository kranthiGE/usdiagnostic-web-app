#region  Page Level Comments

/*******************************************************************************************
/*File Name	      :			RoleBLL.cs
 *Project Name    :			USD 1.0
 *Object          :			Business Logic
 *Purpose         :			
 *Author          :			Adiseshu.D
 *Date            :			27-5-2006 
 *ModuleName      :			USD
 *This file is provided as part of Zaxis-USD project.
 *Copyright � 2004-07, Zaxis-USD Technologies, All rights reserved
 * ************************************ Revision History************************************
 *
 *  Date            Done by             Method             Change Description

*******************************************************************************************/

#endregion

#region  NameSpace Declaration

//System NameSpaces

using System;
using System.Data;

//Zaxis-USD NameSpaces
using Zaxis.Definitions;
using Zaxis.BaseClasses;
using Zaxis.USD.DAL;

#endregion

namespace Zaxis.USD.BusinessLogic
{
	/// <summary>
	/// Summary description for RoleBLL.
	/// </summary>
	public class RoleBLL :FBase
	{
		public RoleBLL()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		#region Create

		/// <summary>
		/// Inserts new data into database
		/// and executes the business logic
		/// </summary>
		/// <param name="data">Business Data Object</param>
		private void Create(BusinessData data)
		{

			DRole role = null;
			try
			{
				role = new DRole();				
				string strRoleID = role.Create("",data.NewEntity.Tables[0].Rows[0].ItemArray[1].ToString(),"1", data.Transaction);

				// Inserting the data into History Table
				DHistory history = new DHistory();
				history.Create(data.UserID, "7", data.Action, strRoleID, "", data.Transaction);
				history = null;

			}
			catch(ZaxisException ex)
			{
				data.Response.ExceptionObject = ex;
				data.Response.Status = Zaxis.Definitions.Common.Status.Failed;
			}
			catch(Exception ex)
			{
				ZaxisException exception = new ZaxisException();
				exception.MessageString = ex.Message;
				data.Response.ExceptionObject = exception;
				data.Response.Status = Zaxis.Definitions.Common.Status.Failed;
				exception = null;
			}
			finally
			{
				role = null;
			}

		}

		#endregion

		#region Update

		/// <summary>
		/// Update the data from database
		/// </summary>
		/// <param name="data">Business Data Object</param>
		private void Update(BusinessData data)
		{
			DRole role = null;
			try
			{
				role = new DRole();
				//role.Create("",data.NewEntity.Tables[0].Rows[0].ItemArray[1].ToString(),"1", data.Transaction);
				role.Update(data.NewEntity, "Role", data.Transaction, null);

				// Inserting the data into History Table
				DHistory history = new DHistory();
				history.Create(data.UserID, "8", data.Action, data.NewEntity.Tables["Role"].Rows[0]["RoleID"].ToString(), "", data.Transaction);
				history = null;

			}
			catch(ZaxisException ex)
			{
				data.Response.ExceptionObject = ex;
				data.Response.Status = Zaxis.Definitions.Common.Status.Failed;
			}
			catch(Exception ex)
			{
				ZaxisException exception = new ZaxisException();
				exception.MessageString = ex.Message;
				data.Response.ExceptionObject = exception;
				data.Response.Status = Zaxis.Definitions.Common.Status.Failed;
				exception = null;
			}
			finally
			{
				role = null;
			}	
		}

		#endregion

		#region Delete

		/// <summary>
		/// Delete record from the database
		/// </summary>
		/// <param name="data">Business Data Object</param>
		private void Delete(BusinessData data)
		{
			DRole role = null;
			try
			{
				role = new DRole();
				role.Delete(data.NewEntity, "Role", data.Transaction);
				
				// Inserting the data into History Table
				DHistory history = new DHistory();
				history.Create(data.UserID, "6", data.Action, data.NewEntity.Tables["Role"].Rows[0]["RoleID"].ToString(), "", data.Transaction);
				history = null;


			}
			catch(ZaxisException ex)
			{
				data.Response.ExceptionObject = ex;
				data.Response.Status = Zaxis.Definitions.Common.Status.Failed;
			}
			catch(Exception ex)
			{
				ZaxisException exception = new ZaxisException();
				exception.MessageString = ex.Message;
				data.Response.ExceptionObject = exception;
				data.Response.Status = Zaxis.Definitions.Common.Status.Failed;
				exception = null;
				data.Transaction.Rollback();
			}
			finally
			{
				role = null;
			}	
		}

		#endregion
	}
}
