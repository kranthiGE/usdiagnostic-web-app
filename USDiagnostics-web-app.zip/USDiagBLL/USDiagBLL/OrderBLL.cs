
#region  Page Level Comments

/*******************************************************************************************
/*File Name	      :			OrderBLL.cs
 *Project Name    :			USD 1.0
 *Object          :			Business Logic
 *Purpose         :			
 *Author          :			Padma A
 *Date            :			27-5-2006 
 *ModuleName      :			USD
 *This file is provided as part of Zaxis-USD project.
 *Copyright � 2004-07, Zaxis-USD Technologies, All rights reserved
 * ************************************ Revision History************************************
 *
 *  Date            Done by             Method             Change Description

*******************************************************************************************/

#endregion

#region  NameSpace Declaration

//System NameSpaces

using System;
using System.Data;

//Zaxis-USD NameSpaces
using Zaxis.Definitions;
using Zaxis.BaseClasses;
using Zaxis.USD.DAL;
using Zaxis.Common;
using Microsoft.Practices.EnterpriseLibrary.Data;

#endregion

namespace Zaxis.USD.BusinessLogic
{
	/// <summary>
	/// Summary description for ProcedureBLL.
	/// </summary>
	public class OrderBLL : FBase
	{

		#region Constructor

		/// <summary>
		/// Empty Construtor
		/// </summary>
		public OrderBLL()
		{
		}

		#endregion
		
		#region Create

		/// <summary>
		/// Inserts new data into database
		/// and executes the business logic
		/// </summary>
		/// <param name="data">Business Data Object</param>
		private void Create(BusinessData data)
		{

			string strOrderID = Guid.NewGuid().ToString();
			string strPatientID = Guid.NewGuid().ToString();
			string strPatientContactID = Guid.NewGuid().ToString();
			string strPatientInsuranceID = Guid.NewGuid().ToString();
			string strOrderContactID = Guid.NewGuid().ToString();

			try
			{

				DataSet dsOrder = data.NewEntity;
				dsOrder.Tables["OrderContact"].Rows[0]["ContactID"] = strOrderContactID;
				


				dsOrder.Tables["Orders"].Rows[0]["OrderID"] = strOrderID;
				dsOrder.Tables["Orders"].Rows[0]["SourceContactID"] = strOrderContactID;
				string strMode = "";
				if(dsOrder.Tables["Patient"].Rows[0]["PatientID"].ToString().Equals("") ||dsOrder.Tables["Patient"].Rows[0]["PatientID"].ToString().Equals(string.Empty))
				{
					strMode = "New";
					dsOrder.Tables["Patient"].Rows[0]["PatientID"] = strPatientID;
					dsOrder.Tables["PatientContact"].Rows[0]["ContactID"] = strPatientContactID;
					dsOrder.Tables["PatientInsuranceContact"].Rows[0]["ContactID"] = strPatientInsuranceID;
					dsOrder.Tables["Patient"].Rows[0]["ContactID"] = strPatientContactID;
					dsOrder.Tables["Patient"].Rows[0]["InsuranceContactID"] = strPatientInsuranceID;
				}
				else
				{
					strMode = "Update";
					strPatientID = dsOrder.Tables["Patient"].Rows[0]["PatientID"].ToString();
					strPatientContactID = dsOrder.Tables["PatientContact"].Rows[0]["ContactID"].ToString();
					strPatientInsuranceID = dsOrder.Tables["PatientInsuranceContact"].Rows[0]["ContactID"].ToString();
					strPatientContactID = dsOrder.Tables["Patient"].Rows[0]["ContactID"].ToString();
					strPatientInsuranceID = dsOrder.Tables["Patient"].Rows[0]["InsuranceContactID"].ToString();
				}

				int iRowCount = dsOrder.Tables["Procedure"].Rows.Count;
				for(int iCount = 0; iCount < iRowCount; iCount++)
				{
					dsOrder.Tables["Procedure"].Rows[iCount]["PatientID"] = strPatientID;
					dsOrder.Tables["Procedure"].Rows[iCount]["OrderID"] = strOrderID;
				}

				// Inserting Patient, insurenace, order cantact information
				DContact contact = new DContact();	
				contact.Create(dsOrder, "OrderContact", data.Transaction, data.HashValues);
				if(strMode.Equals("New"))
				{
					contact.Create(dsOrder, "PatientContact", data.Transaction, data.HashValues);
					contact.Create(dsOrder, "PatientInsuranceContact", data.Transaction, data.HashValues);
				}
				else if(strMode.Equals("Update"))
				{
					contact.Update(dsOrder, "PatientContact", data.Transaction, data.HashValues);
					contact.Update(dsOrder, "PatientInsuranceContact", data.Transaction, data.HashValues);
				}

				// Inserting Order Data
				DOrder order = new DOrder();
				order.Create(dsOrder, "Orders", data.Transaction, data.HashValues);
				order.Update(strOrderID,  data.Transaction);
				order = null; // // distroying the object
				
				DPatientOrder patientorder = new DPatientOrder();
				patientorder.Create(strPatientID, strOrderID, data.Transaction);
				patientorder = null;

				// Inserting Patient Data
				DPatient patient = new DPatient();
				if(strMode.Equals("New"))
					patient.Create(dsOrder, "Patient", data.Transaction, data.HashValues);
				else if(strMode.Equals("Update"))
					patient.Update(dsOrder, "Patient", data.Transaction, data.HashValues);

				patient = null; // distroying the object
		
				// Inserting Procedure Data
				DPatientProcedure procedure = new DPatientProcedure();
				procedure.Create(dsOrder, "Procedure", data.Transaction, data.HashValues);
				procedure = null; // distroying the object
	
				// Inserting the data into History Table
				DHistory history = new DHistory();
				history.Create(data.UserID, "7", data.Action, data.NewEntity.Tables["Orders"].Rows[0]["OrderID"].ToString(), "", data.Transaction);
				history = null;
				contact = null; // distroying the object
			}
			catch(ZaxisException ex)
			{
				data.Response.ExceptionObject = ex;
				data.Response.Status = Zaxis.Definitions.Common.Status.Failed;
			}
			catch(Exception ex)
			{
				ZaxisException exception = new ZaxisException();
				exception.MessageString = ex.Message;
				data.Response.ExceptionObject = exception;
				data.Response.Status = Zaxis.Definitions.Common.Status.Failed;
				exception = null;
			}
			

		}

		#endregion

		#region Update

		/// <summary>
		/// Update the data from database
		/// </summary>
		/// <param name="data">Business Data Object</param>
		private void Update(BusinessData data)
		{

			try
			{

				DataSet dsOrder = data.NewEntity;

				// Updating Patient, insurenace, order cantact information
				DContact contact = new DContact();	
				contact.Update(dsOrder, "OrderContact", data.Transaction, data.HashValues);
				contact.Update(dsOrder, "PatientContact", data.Transaction, data.HashValues);
				contact.Update(dsOrder, "PatientInsuranceContact", data.Transaction, data.HashValues);
				contact = null; // distroying the object

				// Updating Order Data
				DOrder order = new DOrder();
				order.Update(dsOrder, "Orders", data.Transaction, data.HashValues);
				order = null; // // distroying the object
				
				// Updating Patient Data
				DPatient patient = new DPatient();
				patient.Update(dsOrder, "Patient", data.Transaction, data.HashValues);
				patient = null; // distroying the object
		
				// Updating Procedure Data
				DPatientProcedure procedure = new DPatientProcedure();
				string strXml = dsOrder.GetXml();
				strXml = strXml.Replace("\t","");
				strXml = strXml.Replace("\n","");
				strXml = strXml.Replace("\r","");
				procedure.Update(strXml, data.Transaction);
				//procedure.Delete(dsOrder, "Procedure", data.Transaction);
				//procedure.Create(dsOrder, "Procedure", data.Transaction, data.HashValues);
				procedure = null; // distroying the object
		
				// Inserting the data into History Table
				DHistory history = new DHistory();
				history.Create(data.UserID, "8", data.Action, data.NewEntity.Tables["Orders"].Rows[0]["OrderID"].ToString(), "", data.Transaction);
				history = null;
			}
			catch(ZaxisException ex)
			{
				data.Response.ExceptionObject = ex;
				data.Response.Status = Zaxis.Definitions.Common.Status.Failed;
			}
			catch(Exception ex)
			{
				ZaxisException exception = new ZaxisException();
				exception.MessageString = ex.Message;
				data.Response.ExceptionObject = exception;
				data.Response.Status = Zaxis.Definitions.Common.Status.Failed;
				exception = null;
			}
			
		}


		/// <summary>
		/// Execute the Businesss logic for Dispatch Control
		/// </summary>
		/// <param name="data"></param>
		private void UpdateDispatch(BusinessData data)
		{
			try
			{

				DataSet dsOrder = data.NewEntity;

				// Updating Procedure Data
				DPatientProcedure procedure = new DPatientProcedure();
				procedure.Update(dsOrder, "Procedure", data.Transaction, data.HashValues);
				procedure = null; // distroying the object
		
			}
			catch(ZaxisException ex)
			{
				data.Response.ExceptionObject = ex;
				data.Response.Status = Zaxis.Definitions.Common.Status.Failed;
			}
			catch(Exception ex)
			{
				ZaxisException exception = new ZaxisException();
				exception.MessageString = ex.Message;
				data.Response.ExceptionObject = exception;
				data.Response.Status = Zaxis.Definitions.Common.Status.Failed;
				exception = null;
			}	
		}

		/// <summary>
		/// Execute the Businesss logic for Dispatch Control
		/// </summary>
		/// <param name="data"></param>
		private void UpdateTechnician(BusinessData data)
		{
			try
			{

				DataSet dsOrder = data.NewEntity;

				// Updating Procedure Data
				DPatientProcedure procedure = new DPatientProcedure();
				procedure.UpdateTechnician(dsOrder, "Procedure", data.Transaction, data.HashValues);
				procedure = null; // distroying the object
		
			}
			catch(ZaxisException ex)
			{
				data.Response.ExceptionObject = ex;
				data.Response.Status = Zaxis.Definitions.Common.Status.Failed;
			}
			catch(Exception ex)
			{
				ZaxisException exception = new ZaxisException();
				exception.MessageString = ex.Message;
				data.Response.ExceptionObject = exception;
				data.Response.Status = Zaxis.Definitions.Common.Status.Failed;
				exception = null;
			}	
		}

		#endregion

		#region Delete

		/// <summary>
		/// Delete record from the database
		/// </summary>
		/// <param name="data">Business Data Object</param>
		private void Delete(BusinessData data)
		{
			try
			{

				DataSet dsOrder;
				int iRowCount = data.NewEntity.Tables[0].Rows.Count;
				string strPK = string.Empty;
				string strQuery = string.Empty;
				Database  dbInstance = DatabaseFactory.CreateDatabase();  
				CommonBase common = new CommonBase();
				DHistory history = new DHistory();
				for(int iCount =0; iCount < iRowCount; iCount++)
				{
					strPK = data.NewEntity.Tables[0].Rows[iCount]["OrderID"].ToString();
					dsOrder = dbInstance.ExecuteDataSet(CommandType.Text, Zaxis.USD.DAL.Queries.GetQuery("GetOrder", strPK));
					dsOrder.Tables[0].TableName = "Order";
					dsOrder.Tables[1].TableName = "Patient";
					dsOrder.Tables[2].TableName = "Insurance";
					dsOrder.Tables[3].TableName = "Procedures";
					strQuery = "update contact set isactive = 0 where contactid = '"+dsOrder.Tables[0].Rows[0]["SourceContactID"].ToString()+"'";
					dbInstance.ExecuteNonQuery(data.Transaction, CommandType.Text, strQuery);
					strQuery = "update contact set isactive = 0 where contactid = '"+dsOrder.Tables[1].Rows[0]["ContactID"].ToString()+"'";
					dbInstance.ExecuteNonQuery(data.Transaction, CommandType.Text, strQuery);
					strQuery = "update contact set isactive = 0 where contactid = '"+dsOrder.Tables[2].Rows[0]["ContactID"].ToString()+"'";
					dbInstance.ExecuteNonQuery(data.Transaction, CommandType.Text, strQuery);
					strQuery = "update orders set isactive = 0 where orderid = '"+dsOrder.Tables[0].Rows[0]["OrderID"].ToString()+"'";
					dbInstance.ExecuteNonQuery(data.Transaction, CommandType.Text, strQuery);
					strQuery = "update Patient set isactive = 0 where PatientID = '"+dsOrder.Tables[1].Rows[0]["PatientID"].ToString()+"'";
					dbInstance.ExecuteNonQuery(data.Transaction, CommandType.Text, strQuery);
					strQuery = "update Patient_Procedure set isactive = 0 where PatientID = '"+dsOrder.Tables[1].Rows[0]["PatientID"].ToString()+"' and OrderID = '"+dsOrder.Tables[0].Rows[0]["OrderID"].ToString()+"'";
					dbInstance.ExecuteNonQuery(data.Transaction, CommandType.Text, strQuery);
					// Inserting the data into History Table for Order Delete
					history.Create(data.UserID, "6", data.Action, data.NewEntity.Tables[0].Rows[iCount]["OrderID"].ToString(), "", data.Transaction);

					// Commiting the data 
					data.Transaction.Commit();
					data.Transaction = common.GetTransaction();

					
					/*delete contact where contactid = ''
delete orders where orderid = ''
delete patient where patientid = ''
delete patient_procedure where orderid='' and patientid = ''
*/

				}
				common = null;
				history = null;
				dbInstance = null;
			
			}
			catch(ZaxisException ex)
			{
				data.Response.ExceptionObject = ex;
				data.Response.Status = Zaxis.Definitions.Common.Status.Failed;
			}
			catch(Exception ex)
			{
				ZaxisException exception = new ZaxisException();
				exception.MessageString = ex.Message;
				data.Response.ExceptionObject = exception;
				data.Response.Status = Zaxis.Definitions.Common.Status.Failed;
				exception = null;
			}
		}

		#endregion
	}
}
