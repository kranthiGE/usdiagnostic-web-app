using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
namespace Zaxis.USD.Web
{
	/// <summary>
	/// Summary description for Ajax.
	/// </summary>
	public class AjaxSample : PageBase
	{
		private void Page_Load(object sender, System.EventArgs e)
		{
			Ajax.Utility.RegisterTypeForAjax(typeof(AjaxSample));
			// Put user code to initialize the page here
		}

		[Ajax.AjaxMethod()]
		public string[] FindMatches(string searchCriteria)
		{
			DataSet dsData = GetDataset("GetPatientSearch", searchCriteria);
			int iRowCount = dsData.Tables[0].Rows.Count;
			if (iRowCount > 0)
			{          
				string[] found = new string[iRowCount];
				//copy the into a string array
				for (int i = 0; i < iRowCount; ++i)
				{
					found[i] = dsData.Tables[0].Rows[i][0].ToString();
				}
				return found;
			}
			return null;     
		}
	

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Load += new System.EventHandler(this.Page_Load);
		}
		#endregion
	}
}
