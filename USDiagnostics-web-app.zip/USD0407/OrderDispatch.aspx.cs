
#region  Page Level Comments

/*******************************************************************************************
/*File Name	      :			OrderDispatch.cs
 *Project Name    :			USD 1.0
 *Object          :			Code Behind
 *Purpose         :			
 *Author          :			Padma A
 *Date            :			1-6-2006 
 *ModuleName      :			USD
 *This file is provided as part of Zaxis-USD project.
 *Copyright � 2004-07, Zaxis-USD Technologies, All rights reserved
 * ************************************ Revision History************************************
 *
 *  Date            Done by             Method             Change Description

*******************************************************************************************/

#endregion

#region NameSpaces

using System.Data;
using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.Configuration;

//Zaxis Namespaces
using Zaxis.USD.BusinessLogic;
using Zaxis.Definitions;

#endregion

namespace Zaxis.USD.Web
{
	/// <summary>
	/// Summary description for OrderDispatch.
	/// </summary>
	public class OrderDispatch : PageBase
	{
		#region Local Variables

		protected System.Web.UI.WebControls.Label lblFindOrderNo;
		protected System.Web.UI.WebControls.TextBox txtFindOrderNo;
		protected System.Web.UI.WebControls.Label lblFindSex;
		protected System.Web.UI.WebControls.Label lblFindFirstName;
		protected System.Web.UI.WebControls.TextBox txtFindFirstName;
		protected System.Web.UI.WebControls.Label lblFindDOB;
		protected System.Web.UI.WebControls.TextBox txtFindDOB;
		protected System.Web.UI.WebControls.Label lblFindLastname;
		protected System.Web.UI.WebControls.TextBox txtFindLastName;
		protected System.Web.UI.WebControls.Label lblFindSSN;
		protected System.Web.UI.WebControls.TextBox txtFindSSN;
		protected System.Web.UI.WebControls.Button btnGetSSN;
		protected System.Web.UI.WebControls.Label lblFindAny;
		protected System.Web.UI.WebControls.TextBox txtFindAny;
		protected System.Web.UI.WebControls.Button btnGetAny;
		protected System.Web.UI.WebControls.Button btnNew;
		protected System.Web.UI.WebControls.Button btnEdit;
		protected System.Web.UI.WebControls.Button btnSave;
		protected System.Web.UI.WebControls.Button btnCancel;
		protected System.Web.UI.WebControls.DataGrid dgTechnician;
		protected System.Web.UI.WebControls.Label lblOrderDispatchPendings;
		protected System.Web.UI.WebControls.Label lblOrder;
		protected System.Web.UI.WebControls.Label lblOrderRes;
		protected System.Web.UI.WebControls.Label lblPatientName;
		protected System.Web.UI.WebControls.Label lblPatientNameRes;
		protected System.Web.UI.WebControls.Label lblPatientAddress;
		protected System.Web.UI.WebControls.Label lblPatientAddressRes;
		protected System.Web.UI.WebControls.Label lblContactPhone;
		protected System.Web.UI.WebControls.Label lblContactPhoneRes;
		protected System.Web.UI.WebControls.Label lblReqPhysician;
		protected System.Web.UI.WebControls.Label lblReqPhysicianRes;
		protected System.Web.UI.WebControls.Label lblUPinNo;
		protected System.Web.UI.WebControls.Label lblUPinNoRes;
		protected System.Web.UI.WebControls.Label lblOrderingNurse;
		protected System.Web.UI.WebControls.Label lblOrderingNurseRes;
		protected System.Web.UI.WebControls.Label lblPhoneNo;
		protected System.Web.UI.WebControls.Label lblPhoneNoRes;
		protected System.Web.UI.WebControls.Label lblFaxNo;
		protected System.Web.UI.WebControls.Label lblFaxNoRes;
		protected System.Web.UI.WebControls.Label lblDate;
		protected System.Web.UI.WebControls.Label lblDateRes;
		protected System.Web.UI.WebControls.Label lblSignature;
		protected System.Web.UI.WebControls.Label lblSignatureRes;
		protected System.Web.UI.WebControls.Label lblDiagnosis;
		protected System.Web.UI.WebControls.Label lblDiagnosisRes;
		protected System.Web.UI.WebControls.Label lblEnteredBy;
		protected System.Web.UI.WebControls.Label lblEnteredByRes;
		protected System.Web.UI.WebControls.Label lblCustomer;
		protected System.Web.UI.WebControls.Label lblCustomerRes;
		protected System.Web.UI.WebControls.Label lblDOB;
		protected System.Web.UI.WebControls.Label lblDOBRes;
		protected System.Web.UI.WebControls.Label lblSex;
		protected System.Web.UI.WebControls.Label lblSexRes;
		protected System.Web.UI.WebControls.Label lblRoom;
		protected System.Web.UI.WebControls.Label lblRoomRes;
		protected System.Web.UI.WebControls.Label lblHeader;
		protected System.Web.UI.WebControls.Label lblInsuranceName;
		protected System.Web.UI.WebControls.Label lblInsuranceNameRes;
		protected System.Web.UI.WebControls.Label lblInsurancePhone;
		protected System.Web.UI.WebControls.Label lblInsurancePhoneRes;
		protected System.Web.UI.WebControls.Label lblInsuranceFax;
		protected System.Web.UI.WebControls.Label lblInsuranceFaxRes;
		protected System.Web.UI.WebControls.Label lblInsuranceAuth;
		protected System.Web.UI.WebControls.Label lblInsuranceAuthRes;
		protected System.Web.UI.WebControls.Label lblStreetAddress;
		protected System.Web.UI.WebControls.Label lblStreetAddressRes;
		protected System.Web.UI.WebControls.DataGrid dgOrder;
		protected System.Web.UI.WebControls.Button btnPostback;
		protected System.Web.UI.WebControls.DropDownList ddlSex;
		protected System.Web.UI.WebControls.Button btDelete;
		protected System.Web.UI.HtmlControls.HtmlImage imgCalender1;
		protected System.Web.UI.WebControls.Label lblSearchResults;
		protected System.Web.UI.WebControls.Label lblState;
		protected System.Web.UI.WebControls.Label lblZip;
		protected System.Web.UI.WebControls.Label lblZipRes;
		protected System.Web.UI.WebControls.Label lblinsuranceCity;
		protected System.Web.UI.WebControls.Label lblinsuranceCityRes;
		protected System.Web.UI.WebControls.Label lblinsuranceState;
		protected System.Web.UI.WebControls.Label lblinsuranceStateRes;
		protected System.Web.UI.WebControls.Label lblinsuranceZipRes;
		protected System.Web.UI.WebControls.Label lblCity;
		protected System.Web.UI.WebControls.Label lblCityRes;
		protected System.Web.UI.WebControls.Label lblinsuranceZip;
		protected System.Web.UI.WebControls.Label lblStateRes;
		public string strTodaysDate = string.Empty;

		#endregion

		#region Page Load

		/// <summary>
		/// Page Load Event
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			//ViewState["RecordsCount"] = dsAccountInfo.Tables[0].Rows.Count;
			bCheckUserID = true;
			strTodaysDate = DateTime.Now.Date.ToString();

			string strID = "";
			try
			{
				strID = Request.QueryString["ID"].ToString();
				bCheckUserID = false;
			}
			catch(Exception)
			{
				strID = "";
			}

			if(!IsPostBack)
			{
				// Setting the Permission ID to Screen
				PermissionID = "5";
				Search = " and 1=2";
				GridBind(dgOrder, "OrderSearchBind", Search);
				//GridBind(dgOrder, "OrderGridBind", "");
				GridBind(dgTechnician, "OrderDispatch", "-1");
			}
			ViewState["Order"] = GetDataset("DispatchStructure", "");

			if(!strID.Equals(""))
			{
				string strPK = GetValue("OrderID", strID).ToString();
				PrimaryKey = strPK;
				PopulateOrder();
			}

//			toolbarUsrAcc.Items["tbtnSave"].Attributes.Add("onclick","return IsRequired()");
//			toolbarUsrAcc.Items["tbtnDelete"].Attributes.Add("onclick","return IsDelete()");
		}
		
		#endregion

		#region Clear Controls
		/// <summary>
		/// Cleara the Lable information
		/// </summary>
		private void CleaerControls()
		{
			lblOrderRes.Text = string.Empty;
			lblPatientNameRes.Text = string.Empty;
			lblPatientAddressRes.Text = string.Empty;
			lblCityRes.Text = string.Empty;
			lblStateRes.Text = string.Empty;
			lblZipRes.Text = string.Empty;
			lblContactPhoneRes.Text = string.Empty;
			lblReqPhysicianRes.Text = string.Empty;
			lblUPinNoRes.Text = string.Empty;
			lblOrderingNurseRes.Text = string.Empty;
			lblPhoneNoRes.Text = string.Empty;
			lblFaxNoRes.Text = string.Empty;
			lblDateRes.Text = string.Empty;
			lblSignatureRes.Text = string.Empty;
			lblDiagnosisRes.Text = string.Empty;
			lblEnteredByRes.Text = string.Empty;
			lblCustomerRes.Text = string.Empty;
			lblDOBRes.Text = string.Empty;
			lblSexRes.Text = string.Empty;
			lblRoomRes.Text = string.Empty;
			lblInsuranceNameRes.Text = string.Empty;
			lblInsurancePhoneRes.Text = string.Empty;
			lblInsuranceFaxRes.Text = string.Empty;
			lblInsuranceAuthRes.Text = string.Empty;
			lblStreetAddressRes.Text = string.Empty;
			lblinsuranceCityRes.Text = string.Empty;
			lblinsuranceStateRes.Text = string.Empty;
			lblinsuranceZipRes.Text = string.Empty;
			
		}
		#endregion

		#region Grid Events and Methods

		/// <summary>
		/// Technician Selected Index Change Event
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		public void dgTechnician_select(object sender, System.EventArgs e)
		{
			Label lblOrderID = (Label) dgTechnician.SelectedItem.FindControl("lblOrderID");
//			Label lblProcedureID = (Label) dgTechnician.SelectedItem.FindControl("lblProcedureID");
//			Label lblPatientID = (Label) dgTechnician.SelectedItem.FindControl("lblPatientID");
			AssignData(GetDataset("GetOrder", lblOrderID.Text));

		}

	
		/// <summary>
		/// Order Select Event
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		public void dgOrder_select(object sender,System.EventArgs e)
		{
			PrimaryKey = dgOrder.SelectedItem.Cells[0].Text;
			GridBind(dgTechnician, "OrderDispatch", PrimaryKey);
			AssignData(GetDataset("GetOrder", PrimaryKey));
		}


		/// <summary>
		/// Bind the Technician data to drop downliast
		/// </summary>
		/// <returns></returns>
		protected DataSet GetTechnician()
		{
			return GetDataset("TechnicianBind", "");
		}

	
		/// <summary>
		/// Fills the Priority Drop Downlist
		/// </summary>
		/// <returns></returns>
		protected DataSet GetPriority()
		{
			return GetDataset("CodeType", "3");
		}


		/// <summary>
		/// Updates the Data into Database
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		public void dgTechnician_Update(object sender, DataGridCommandEventArgs e) 
		{
			Label lblOrderID = (Label) e.Item.FindControl("lblOrderID");
			Label lblProcedureID = (Label) e.Item.FindControl("lblProcedureID");
			Label lblPatientID = (Label) e.Item.FindControl("lblPatientID");
			DropDownList ddlTechnician = (DropDownList) e.Item.FindControl("ddlTechnician");
			DropDownList ddlPriority = (DropDownList) e.Item.FindControl("ddlPriority");
			TextBox txtDueDate = (TextBox)e.Item.FindControl("txtDueDate");
			TextBox txtTestTime = (TextBox)e.Item.FindControl("txtTestTime");

			DataSet dsOrder = (DataSet)ViewState["Order"];

			DataRow dr = dsOrder.Tables[0].NewRow();
			dsOrder.Tables[0].TableName = "Procedure";
			dr["PatientID"] = lblPatientID.Text;
			dr["ProcedureID"] = lblProcedureID.Text;
			dr["OrderID"] = lblOrderID.Text;
			dr["TechnicianID"] = ddlTechnician.SelectedValue;
			dr["DueDate"] = txtDueDate.Text + " " + txtTestTime.Text;
			dr["PriorityID"] = ddlPriority.SelectedValue;
			dr["StatusID"] = 27;
			dr["IsActive"] = 1;
			dsOrder.Tables[0].Rows.Add(dr);

			BusinessData data = new BusinessData();
			data.MethodName = "UpdateDispatch";
			data.NewEntity = dsOrder;
			OrderBLL order = new OrderBLL();
			Response response = order.Save(data);
			
			dgTechnician.EditItemIndex = -1;
			GridBind(dgTechnician, "OrderDispatch", PrimaryKey);
		}


		/// <summary>
		/// Grid Edit Event
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		public void dgTechnician_Edit(object sender, DataGridCommandEventArgs e) 
		{
			if(!UpdatePermission())
				ALertMessage("You dont have Update Permission", "txtFindLastName");
			else
			{
				ViewState["RowState"] = "Update";
				string strProcedureID = string.Empty;
				try
				{
					strProcedureID = dgTechnician.DataKeys[e.Item.ItemIndex].ToString();
				}
				catch(Exception)
				{
					strProcedureID = "";
				}
				if (strProcedureID.Equals(""))
					dgTechnician.EditItemIndex = -1 ;
				else
				{
					Label lbl = (Label)e.Item.FindControl("lblTechinician");
					ViewState["TechnicianID"] = lbl.Text;

					lbl = (Label)e.Item.FindControl("lblStatusID");
					string strStatus = lbl.Text;
					if(!Session["UserID"].ToString().Equals("6") && strStatus.Equals("25"))
					{
						ALertMessage("Procedure already closed, Unable to modify the procedure",  "dgTechnician");
						dgTechnician.EditItemIndex = -1 ;
					}
					else
					{
						dgTechnician.EditItemIndex = e.Item.ItemIndex;
					}
					ViewState["ProcedureID"] = strProcedureID;
					lbl = (Label)e.Item.FindControl("lblPriority");
					ViewState["Priority"] = lbl.Text;
				}
			}
			GridBind(dgTechnician, "OrderDispatch", PrimaryKey);
		}
		
		/// <summary>
		/// Cancle the Technician Grid selection
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		public void dgTechnician_Cancel(object sender, DataGridCommandEventArgs e) 
		{
			dgTechnician.EditItemIndex = -1;
			GridBind(dgTechnician, "OrderDispatch", PrimaryKey);
		}
		
		/// <summary>
		/// Item Databound Event
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		public void dgTechnician_ItemDataBound(object sender, DataGridItemEventArgs e) 
		{
			if (dgTechnician.EditItemIndex != -1 && (e.Item.ItemIndex == dgTechnician.EditItemIndex))
			{
				DropDownList ddl = (DropDownList) e.Item.Cells[3].Controls[1];
				ListItem li = ddl.Items.FindByText(ViewState["TechnicianID"].ToString());
				if (li != null)
				{
					ddl.SelectedIndex = -1;
					li.Selected = true;
				}
				ddl = (DropDownList) e.Item.Cells[4].Controls[1];
				li = ddl.Items.FindByText(ViewState["Priority"].ToString());
				if (li != null)
				{
					ddl.SelectedIndex = -1;
					li.Selected = true;
				}
			}
		}
		
		/// <summary>
		/// Item Creaeted Event
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		public void dgTechnician_ItemCreated(object sender, DataGridItemEventArgs e)
		{
			switch (e.Item.ItemType )
			{
				case ListItemType.Item:
				case ListItemType.AlternatingItem:
				case ListItemType.EditItem:
//					LinkButton lnkDelete=(LinkButton) e.Item.Cells[10].Controls[0] ;
//					lnkDelete.Attributes.Add("onclick", "return confirm('Are you Sure you want to delete this company?');");
					break;
			}
		}
		#endregion

		#region AlertMessage

		private void ALertMessage(string text, string focus)
		{
			string strScript = "<script language=javascript>";
			if(!text.Equals(""))
				strScript += "alert('"+ text +"');";
			if(focus == "")
				strScript += "document.getElementById('txtPermission.Text').focus();";
			strScript += "</script>";
			RegisterStartupScript("MM", strScript);
		}

		#endregion

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.btnGetSSN.Click += new System.EventHandler(this.btnGetSSN_Click);
			this.btnGetAny.Click += new System.EventHandler(this.btnGetAny_Click);
			this.dgOrder.ItemDataBound += new System.Web.UI.WebControls.DataGridItemEventHandler(this.dgOrder_ItemDataBound);
			this.btnPostback.Click += new System.EventHandler(this.btnPostback_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		#region Assign Data
		/// <summary>
		/// Assigns the Order data to Controls
		/// </summary>
		private void AssignData(DataSet dsOrder)
		{
			lblOrderRes.Text = dsOrder.Tables[0].Rows[0]["OrderNo"].ToString();
			lblPatientNameRes.Text = dsOrder.Tables[1].Rows[0]["FirstName"].ToString();
			lblPatientAddressRes.Text = dsOrder.Tables[1].Rows[0]["Address1"].ToString();
			lblCityRes.Text = dsOrder.Tables[1].Rows[0]["City"].ToString();
			lblStateRes.Text = dsOrder.Tables[1].Rows[0]["State"].ToString();
			lblZipRes.Text = dsOrder.Tables[1].Rows[0]["Zip"].ToString();

			lblContactPhoneRes.Text = dsOrder.Tables[1].Rows[0]["HomePhone"].ToString();
			lblReqPhysicianRes.Text = dsOrder.Tables[0].Rows[0]["Physician"].ToString();
			lblUPinNoRes.Text = dsOrder.Tables[0].Rows[0]["Zip"].ToString();
			lblOrderingNurseRes.Text = dsOrder.Tables[0].Rows[0]["OrderingNurse"].ToString();
			lblPhoneNoRes.Text = dsOrder.Tables[0].Rows[0]["HomePhone"].ToString();
			lblFaxNoRes.Text = dsOrder.Tables[0].Rows[0]["Fax"].ToString();
			lblDateRes.Text = dsOrder.Tables[0].Rows[0]["OrderDate"].ToString();
			lblSignatureRes.Text = dsOrder.Tables[0].Rows[0]["Signature"].ToString();
			lblDiagnosisRes.Text = dsOrder.Tables[0].Rows[0]["Diagnosis"].ToString();
			//lblEnteredByRes.Text = dsOrder.Tables[0].Rows[0][""].ToString();
			lblCustomerRes.Text = dsOrder.Tables[0].Rows[0]["FirstName"].ToString();
			lblDOBRes.Text = dsOrder.Tables[1].Rows[0]["DOB"].ToString();
			if(dsOrder.Tables[1].Rows[0]["Sex"].ToString().Equals("1"))
				lblSexRes.Text = "Female";
			else
				lblSexRes.Text = "Male";
			
			lblRoomRes.Text = dsOrder.Tables[1].Rows[0]["RoomNo"].ToString();
			if(dsOrder.Tables[2].Rows.Count > 0)
			{
				lblInsuranceNameRes.Text = dsOrder.Tables[2].Rows[0]["FirstName"].ToString();
				lblInsurancePhoneRes.Text = dsOrder.Tables[2].Rows[0]["HomePhone"].ToString();
				lblInsuranceFaxRes.Text = dsOrder.Tables[2].Rows[0]["Fax"].ToString();
				lblInsuranceAuthRes.Text = "";
				lblStreetAddressRes.Text = dsOrder.Tables[2].Rows[0]["Address1"].ToString();
				lblinsuranceCityRes.Text =  dsOrder.Tables[2].Rows[0]["City"].ToString();
				lblinsuranceStateRes.Text =  dsOrder.Tables[2].Rows[0]["State"].ToString();
				lblinsuranceZipRes.Text =  dsOrder.Tables[2].Rows[0]["Zip"].ToString();
			}
		}

		#endregion

		#region Attaching DobuleClick
		/// <summary>
		/// Attaches Double click event and sends RoleId and RoleName as arguments to GetPostBackClientEvent
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void dgOrder_ItemDataBound(object sender, System.Web.UI.WebControls.DataGridItemEventArgs e)
		{
			if(e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem || e.Item.ItemType == ListItemType.SelectedItem )
			{
				if(e.Item.Cells[0].Text.ToString() != "&nbsp;")
				{
					string strArgs = e.Item.Cells[0].Text + ";" + e.Item.ItemIndex;
					e.Item.Cells[0].Attributes.Add("onclick", Page.GetPostBackClientEvent(btnPostback, strArgs));
					e.Item.Cells[1].Attributes.Add("onclick", Page.GetPostBackClientEvent(btnPostback, strArgs));
					e.Item.Cells[2].Attributes.Add("onclick", Page.GetPostBackClientEvent(btnPostback, strArgs));
					e.Item.Cells[3].Attributes.Add("onclick", Page.GetPostBackClientEvent(btnPostback, strArgs));
					e.Item.Cells[4].Attributes.Add("onclick", Page.GetPostBackClientEvent(btnPostback, strArgs));
					//e.Item.Cells[5].Attributes.Add("ondblclick", Page.GetPostBackClientEvent(btnPostback, strArgs));
				}
			}
			
		}

		#endregion

		#region doubleclick postback event
		/// <summary>
		/// fires when cell is doubleclicked and gets RoleName and RoleId values in respective textboxes
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void btnPostback_Click(object sender, System.EventArgs e)
		{
			string strArguments = this.Page.Request["__EVENTARGUMENT"];
			string[] _strArgs = strArguments.Split(new char[]{';'});
			
			PrimaryKey = _strArgs[0];
			PopulateOrder();
			//GridBind(dgOrder, "OrderGridBind", "");
			dgOrder.Items[Convert.ToInt32(_strArgs[1])].CssClass = "GridSelectedItemStyle";
			
			//EnableControls(true, true, true, false, false, toolbarUsrAcc);

		}

		/// <summary>
		///  Assigns the Data to Controls
		/// </summary>
		private void PopulateOrder()
		{
			GridBind(dgTechnician, "OrderDispatch", PrimaryKey);
			AssignData(GetDataset("GetOrder", PrimaryKey));

			GridBind(dgOrder, "OrderSearchBind", Search);	
		}

		#endregion

		#region Search

		/// <summary>
		/// Returns the Dataset Based on the Search Criteria
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void btnGetSSN_Click(object sender, System.EventArgs e)
		{
			string strWhere = string.Empty;
			if(txtFindOrderNo.Text.Trim().Length > 0)
			{
				strWhere = " or o.OrderNo like '" + txtFindOrderNo.Text + "%'";
			}
			if(txtFindFirstName.Text.Trim().Length > 0)
			{
				strWhere = strWhere +  " or c.FirstName like '" + txtFindFirstName.Text + "%'";
			}
			
			if(txtFindLastName.Text.Trim().Length > 0)
			{
				strWhere = strWhere +  " or c.LastName like '" + txtFindLastName.Text + "%'";
			}

			if(txtFindSSN.Text.Trim().Length > 0)
			{
				strWhere = strWhere +  " or p.SSN like '" + txtFindSSN.Text + "%'";
			}
			
			if(txtFindDOB.Text.Trim().Length > 0)
			{
				strWhere = strWhere +  " or CONVERT(VARCHAR(10), p.DOB, 101) like '" + txtFindDOB.Text + "%'";
			}

			if(!ddlSex.SelectedValue.Equals("-1"))
			{
				strWhere = strWhere + " or c.Sex = " + ddlSex.SelectedValue;
			}

			if (strWhere.StartsWith(" or"))
			{
				strWhere = strWhere.Substring(3);
				strWhere = " and ( " + strWhere + " ) ";
			}

			//
//			if(strWhere.Trim().Length > 1)
//				strWhere = " where " + strWhere;
			
			Search = strWhere;

			//GridBind(dgOrder, "OrderSearchBind", Search);
			Binddata();
			//EnableControls(true, false, false, false, false, toolbarUsrAcc); 	
		
		}

		/// <summary>
		/// Binds the data to search grid based on the search criteria
		/// </summary>
		private void Binddata()
		{
			CleaerControls();
			GridBind(dgTechnician, "OrderDispatch", "-1");
			DataSet ds = GetDataset("OrderSearchBind", Search);
			lblSearchResults.Text = ds.Tables[0].Rows.Count + " Orders Found";
			if(ds.Tables[0].Rows.Count == 1)
			{
				PrimaryKey = ds.Tables[0].Rows[0]["OrderID"].ToString();
				PopulateOrder();
			}
			AddDummyRows(ds, 0, Convert.ToInt32(ConfigurationSettings.AppSettings["GridRows"]));
			dgOrder.DataSource = ds;
			dgOrder.DataBind();
		}

		/// <summary>
		/// Returns the Dataset Based on the Search Criteria
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void btnGetAny_Click(object sender, System.EventArgs e)
		{
			string strWhere = string.Empty;
			if(txtFindAny.Text.Trim().Length > 0)
			{
				strWhere = " and ( o.OrderNo like '" + txtFindAny.Text + "%'";
				strWhere = strWhere +  " or c.FirstName like '" + txtFindAny.Text + "%'";
				strWhere = strWhere +  " or c.LastName like '" + txtFindAny.Text + "%'";
				strWhere = strWhere +  " or p.SSN like '" + txtFindAny.Text + "%'";
				strWhere = strWhere +  " or CONVERT(VARCHAR(10), p.DOB, 101) like '" + txtFindAny.Text + "%' )";
			}

//			if (strWhere.StartsWith(" or"))
//				strWhere = strWhere.Substring(3);
//
//			if(strWhere.Trim().Length > 1)
//				strWhere = " where " + strWhere;
			
			Search = strWhere;

			//GridBind(dgOrder, "OrderSearchBind", Search);
			Binddata();
			//EnableControls(true, false, false, false, false, toolbarUsrAcc); 
		}
		#endregion
	}
}
