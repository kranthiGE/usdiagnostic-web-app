using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace Zaxis.USD.Web
{
	/// <summary>
	/// Summary description for EditGrid.
	/// </summary>
	public class EditGrid : PageBase
	{
		protected System.Web.UI.WebControls.DataGrid dgProcedure;

	
		private void Page_Load(object sender, System.EventArgs e)
		{
//			dgProcedure.DataSource = GetProcedures();
//			dgProcedure.DataBind();
			string strEvent = "";
			try
			{
				strEvent = Request.Form["__EVENTARGUMENT"].ToString();
				if (strEvent.Equals("Procedure"))
				{
					string strIndex = Request.Form["__EVENTTARGET"].ToString();
					int iStart =strIndex.IndexOf("ctl")+3;
					int iEnd = strIndex.LastIndexOf("_") - iStart;
					strIndex = strIndex.Substring(iStart, iEnd);
					AssignProcedureType(Convert.ToInt32(strIndex));
				}
				

			}
			catch(Exception ex)
			{
				string str = ex.Message;
			}
			if(!IsPostBack)
				GridBind(GetProcedures());
			// Put user code to initialize the page here
		}

		#region Grid Events

		/// <summary>
		/// Assigning data to grid
		/// </summary>
		/// <param name="id"></param>
		private void AssignProcedureType(int id)
		{
			int iIndex = dgProcedure.Controls[0].Controls.Count;
			TextBox txt;
			if(iIndex == id)
			{
				txt = (TextBox)dgProcedure.Controls[0].Controls[id-1].FindControl("NewCode");
				DataSet dsProcedure = GetDataset("GetOrderProcedure", txt.Text);
				DataSet dsProcedureType ;
				if(dsProcedure.Tables[0].Rows.Count > 0)
				{
					//txt.Text = "desking";
					DropDownList ddlCategory = (DropDownList) dgProcedure.Controls[0].Controls[id-1].FindControl("NewCategory");
					ddlCategory.SelectedValue = dsProcedure.Tables[0].Rows[0]["ProcedurecodeID"].ToString();
					dsProcedureType = GetDataset("GetOrderProcedureType", ddlCategory.SelectedValue);
					DropDownList ddlTest = (DropDownList) dgProcedure.Controls[0].Controls[id-1].FindControl("NewTestType");
					ddlTest.DataSource =dsProcedureType;
					ddlTest.DataTextField = "Name";
					ddlTest.DataValueField = "ProcedureID";
					ddlTest.DataBind();
					ddlTest.SelectedValue = dsProcedure.Tables[0].Rows[0]["ProcedureID"].ToString();
				}
			}
			else
			{
				txt = (TextBox)dgProcedure.Controls[0].Controls[id-1].FindControl("txtGCode");
				DataSet dsProcedure = GetDataset("GetOrderProcedure", txt.Text);
				DataSet dsProcedureType ;
				if(dsProcedure.Tables[0].Rows.Count > 0)
				{
					//txt.Text = "desking";
					DropDownList ddlCategory = (DropDownList) dgProcedure.Controls[0].Controls[id-1].FindControl("ddlGCategory");
					ddlCategory.SelectedValue = dsProcedure.Tables[0].Rows[0]["ProcedurecodeID"].ToString();
					dsProcedureType = GetDataset("GetOrderProcedureType", ddlCategory.SelectedValue);
					DropDownList ddlTest = (DropDownList) dgProcedure.Controls[0].Controls[id-1].FindControl("ddlGTestType");
					ddlTest.DataSource =dsProcedureType;
					ddlTest.DataTextField = "Name";
					ddlTest.DataValueField = "ProcedureID";
					ddlTest.DataBind();
					ddlTest.SelectedValue = dsProcedure.Tables[0].Rows[0]["ProcedureID"].ToString();
				}
			}

		}

		/// <summary>
		/// Bind the data to Grid
		/// </summary>
		/// <param name="dsProcedures"></param>
		private void GridBind(DataSet dsProcedures)
		{
			dgProcedure.DataSource = dsProcedures;
			dgProcedure.DataBind();
		}

		/// <summary>
		/// Binds the Procedure Category to Category Dropdown List
		/// </summary>
		/// <returns></returns>
		protected DataSet GetCategory()
		{
			return GetDataset("GetProcedureCategory", "");
		}

		/// <summary>
		/// Bind the Technician data to drop downliast
		/// </summary>
		/// <returns></returns>
		protected DataSet GetTechnician()
		{
			return GetDataset("TechnicianBind", "");
		}
		
		/// <summary>
		/// Returns the Procedures Dataset
		/// </summary>
		/// <returns></returns>
		protected DataSet GetProcedures()
		{
			DataSet dsProcedure  = GetDataset("GetProcedureData", "<Query><PatientID>ea0c4dbf-8313-4a95-a387-29896da99dc2 </PatientID><OrderID>45975e84-8abf-4abe-863e-19adb4187622 </OrderID></Query>");
			ViewState["Procedure"] = dsProcedure;
			return dsProcedure;
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void dgProcedure_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			int str = dgProcedure.SelectedIndex;
			int st1 =str;
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		protected void ddlGTestType_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			DropDownList ddlList = (DropDownList)sender;
			TableCell cell = ddlList.Parent as TableCell;
			DataGridItem item = cell.Parent as DataGridItem;
			TextBox txtCode;
			DropDownList ddlTest;
			if(item.ItemType == ListItemType.Footer)
			{
				ddlTest = (DropDownList) item.FindControl("NewTestType");
				txtCode = (TextBox)item.FindControl("NewCode");
				txtCode.Text = GetDataset("GetOrderProcedureCode", ddlTest.SelectedValue).Tables[0].Rows[0]["Code"].ToString();
			}
			else if(item.ItemType == ListItemType.AlternatingItem ||item.ItemType == ListItemType.Item)
			{
				ddlTest = (DropDownList) item.FindControl("ddlGTestType");
				txtCode = (TextBox)item.FindControl("txtGCode");
				txtCode.Text = GetDataset("GetOrderProcedureCode", ddlTest.SelectedValue).Tables[0].Rows[0]["Code"].ToString();
			}
		}
		protected void ddlGCategory_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			DropDownList ddlList = (DropDownList)sender;
			TableCell cell = ddlList.Parent as TableCell;
			DataGridItem item = cell.Parent as DataGridItem;

			int index = item.ItemIndex;
			//item.FindControl()
			
			DataSet dsProcedureType = GetDataset("GetOrderProcedureType", ddlList.SelectedValue);
			DropDownList ddlTest = new DropDownList();
			TextBox txtCode;
			if(item.ItemType == ListItemType.Footer)
			{
				ddlTest = (DropDownList) item.FindControl("NewTestType");
				ddlTest.DataSource =dsProcedureType;
				ddlTest.DataTextField = "Name";
				ddlTest.DataValueField = "ProcedureID";
				ddlTest.DataBind();
				ddlTest.TabIndex = 0;
				txtCode = (TextBox)item.FindControl("NewCode");
				txtCode.Text = GetDataset("GetOrderProcedureCode", ddlTest.SelectedValue).Tables[0].Rows[0]["Code"].ToString();
			}
			else if(item.ItemType == ListItemType.AlternatingItem ||item.ItemType == ListItemType.Item)
			{
				ddlTest = (DropDownList) item.FindControl("ddlGTestType");
				ddlTest.DataSource =dsProcedureType;
				ddlTest.DataTextField = "Name";
				ddlTest.DataValueField = "ProcedureID";
				ddlTest.DataBind();
				ddlTest.TabIndex = 0;
				txtCode = (TextBox)item.FindControl("txtGCode");
				txtCode.Text = GetDataset("GetOrderProcedureCode", ddlTest.SelectedValue).Tables[0].Rows[0]["Code"].ToString();
			}


			//			Response.Write(sender.ToString());
			//			DropDownList list = (DropDownList)sender;
			//			DataSet dsProcedureType = GetDataset("GetOrderProcedureType", list.SelectedValue);
			//			DropDownList ddlTest = (DropDownList) dgProcedure.FindControl("NewTestType");
			//			ddlTest.DataSource = dsProcedureType;
			//			ddlTest.DataTextField = "Name";
			//			ddlTest.DataValueField = "ProcedureID";
			//			ddlTest.DataBind();
			//			ddlTest.SelectedValue = dsProcedure.Tables[0].Rows[0]["ProcedureID"].ToString();
		}

		/// <summary>
		/// Datagrid Procedure Item Data Bound Event
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		protected void dgProcedure_ItemDataBound(object sender, System.Web.UI.WebControls.DataGridItemEventArgs e)
		{
			if(e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
			{
				int rowIndex = e.Item.ItemIndex;
				TextBox txtCode= (TextBox)e.Item.FindControl("txtGCode");
				txtCode.Attributes.Add("onblur", "CheckCode(this," + rowIndex.ToString()+")");
				txtCode= (TextBox)e.Item.FindControl("txtDView");
				txtCode.Attributes.Add("onblur", "CheckNumber(this)");
			
				}
			else if( e.Item.ItemType == ListItemType.Footer)
			{
				int rowIndex = e.Item.ItemIndex;
				TextBox txtCode= (TextBox)e.Item.FindControl("NewCode");
				txtCode.Attributes.Add("onblur", "CheckCode(this," + rowIndex.ToString()+")");
				txtCode= (TextBox)e.Item.FindControl("NewView");
				txtCode.Attributes.Add("onblur", "CheckNumber(this)");
			}
		}
		
		/// <summary>
		/// Item Command
		/// </summary>
		/// <param name="source"></param>
		/// <param name="e"></param>
		protected void dgProcedure_ItemCommand(object source , System.Web.UI.WebControls.DataGridCommandEventArgs e)
		{
			// Add the new item to the dataset.  I use an array here for efficiency.
			if (e.CommandName == "Add")
			{
				DataSet dsProcedure = (DataSet)ViewState["Procedure"];
				DataRow dr = dsProcedure.Tables[0].NewRow();

				string[] sContact = {"", "", ""};
				dr["OrderID"] = ((Label)e.Item.FindControl("lblGOrderID")).Text;
				dr["ProcedureID"] = ((TextBox)e.Item.FindControl("lblGProcedureID")).Text;
//				dr[""] = "";
//				dr[""]="";
//				dr[""] = "";
//				dr[""]="";
//				dr[""] = "";
//				dr[""]="";
//				dr[""] = "";
//				dr[""]="";
				
				dsProcedure.Tables[0].Rows.Add(sContact);
				ViewState["Procedure"] = dsProcedure;
				GridBind(dsProcedure);
				//				_dsContacts.Tables["Contact"].Rows.Add(sContact);

				//				SaveContacts();
			}

			//			BindContacts();
		} 
		#endregion

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			this.dgProcedure.ItemDataBound += new System.Web.UI.WebControls.DataGridItemEventHandler(this.dgProcedure_ItemDataBound);
			//this.dgProcedure.ItemCreated += new System.Web.UI.WebControls.DataGridItemEventHandler(this.dgProcedure_ItemCreated);
			//this.dgProcedure.ItemCreated += new System.Web.UI.WebControls.DataGridItemEventHandler(this.dgProcedure_ItemCreated);
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.dgProcedure.SelectedIndexChanged += new System.EventHandler(this.dgProcedure_SelectedIndexChanged);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

	}
}
