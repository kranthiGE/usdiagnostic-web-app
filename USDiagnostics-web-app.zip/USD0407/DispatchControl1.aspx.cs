
#region NameSpaces

	using System;
	using System.Collections;
	using System.ComponentModel;
	using System.Data;
	using System.Drawing;
	using System.Web;
	using System.Web.SessionState;
	using System.Web.UI;
	using System.Web.UI.WebControls;
	using System.Web.UI.HtmlControls;
	using System.Data.SqlClient;
	using Zaxis.USD.Web;

#endregion 

namespace Zaxis.USD.Web
{
	/// <summary>
	/// Summary description for DispatchControl.
	/// </summary>
	public class DispatchControl : PageBase
	{
		#region Variable Declaration

		protected System.Web.UI.WebControls.DataGrid dgOrdersDispatched;
		protected System.Web.UI.WebControls.DataGrid dgTechnician;
		protected System.Web.UI.WebControls.DataGrid dgOrderPendings;
		protected Evolve.Web.UI.Toolbar.Toolbar toolbarUsrAcc;
		DataSet dsOrderPendings = new DataSet();

		#endregion

		#region page_Load
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			bCheckUserID = true;
			if(!IsPostBack)
			{
				// Setting the Permission ID to Screen
				PermissionID = "4";
				// for binding the orders pending
				FillGrid(2, dgOrderPendings);
				// for binding the orders dispatched
				FillGrid(3, dgOrdersDispatched);
				//for binding the Technician Status
				GridBind(dgTechnician, "DispatchGridBind2", "");
			}
		}

		#endregion

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		#region FillGrid Order
		private void FillGrid(int status, DataGrid dg)
		{
//			dsOrderPendings	= GetDataset("DispatchGrid1", status);
//			ViewState["RecordsCount"] = dsOrderPendings.Tables[0].Rows.Count;
//			PageBase.GetDataset(strQuery);
//			PageBase.AddDummyRows(ref dsOrderPendings, 0, 5);
			GridBind(dg, "DispatchGridBind1", status.ToString());
			
//			dg.DataSource = dsOrderPendings;
//			dg.DataBind();
		}
		#endregion	

		#region FillGrid
		private void FillGrid()
		{
//			string strQuery = "";
//			dsOrderPendings	= PageBase.GetDataset(strQuery);
//			ViewState["RecordsCount"] = dsOrderPendings.Tables[0].Rows.Count;
//			PageBase.GetDataset(strQuery);
//			PageBase.AddDummyRows(ref dsOrderPendings, 0, 5);
//			dgTechnician.DataSource = dsOrderPendings;
//			dgTechnician.DataBind();
			GridBind(dgTechnician, "", "");
		}
		#endregion	

		#region Data Grid Item Command
		/// <summary>
		/// 
		/// </summary>
		/// <param name="source"></param>
		/// <param name="e"></param>
		private void dgTechnician_ItemCommand(object source, System.Web.UI.WebControls.DataGridCommandEventArgs e)
		{
						
		}
		#endregion
		
	}
}
