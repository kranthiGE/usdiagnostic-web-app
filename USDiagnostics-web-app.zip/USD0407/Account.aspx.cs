
#region  Page Level Comments

/*******************************************************************************************
/*File Name	      :			Account.cs
 *Project Name    :			USD 1.0
 *Object          :			Code Behind
 *Purpose         :			
 *Author          :			Padma A
 *Date            :			27-5-2006 
 *ModuleName      :			USD
 *This file is provided as part of Zaxis-USD project.
 *Copyright � 2004-07, Zaxis-USD Technologies, All rights reserved
 * ************************************ Revision History************************************
 *
 *  Date            Done by             Method             Change Description

*******************************************************************************************/

#endregion

#region NameSpaces

using System.Data;
using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.Configuration;

//Zaxis Namespaces
using Zaxis.USD.BusinessLogic;
using Zaxis.Definitions;

#endregion

namespace Zaxis.USD.Web
{
	/// <summary>
	/// Summary description for Account.
	/// </summary>
	public class Account : PageBase
	{
	
		#region Variable Declaration

		protected System.Web.UI.WebControls.DataGrid dgAccount;
		protected System.Web.UI.WebControls.TextBox txtFirstName;
		protected System.Web.UI.WebControls.TextBox txtLastName;
		protected System.Web.UI.WebControls.Label lblMiddleName;
		protected System.Web.UI.WebControls.TextBox txtMiddleName;
		protected System.Web.UI.WebControls.Label lblLoginD;
		protected System.Web.UI.WebControls.TextBox txtLoginID;
		protected System.Web.UI.WebControls.Label lblPassword;
		protected System.Web.UI.WebControls.TextBox txtPassword;
		protected System.Web.UI.WebControls.Label lblRetypePWD;
		protected System.Web.UI.WebControls.Label lblSecretQuestion;
		protected System.Web.UI.WebControls.TextBox txtSecretQuestion;
		protected System.Web.UI.WebControls.Label lblAnswer;
		protected System.Web.UI.WebControls.TextBox txtAnswer;
		protected System.Web.UI.WebControls.Label lblAccess;
		protected System.Web.UI.WebControls.Label lblTechnicianType;
		protected System.Web.UI.WebControls.ListBox lstTechnicianType;
		protected System.Web.UI.WebControls.Label lblModifyRec;
		protected System.Web.UI.WebControls.DropDownList ddlModifyRec;
		protected System.Web.UI.WebControls.Label lblFindLastName;
		protected System.Web.UI.WebControls.Label txtFindName;
		protected System.Web.UI.WebControls.Label lblFindLogin;
		protected System.Web.UI.WebControls.TextBox txtFindLogin;
		protected System.Web.UI.WebControls.TextBox txtFindlName;
		protected System.Web.UI.WebControls.Label lblFindFirstName;
		protected System.Web.UI.WebControls.TextBox txtFindFirstName;
		protected System.Web.UI.WebControls.Label lblFindAccess;
		protected System.Web.UI.WebControls.TextBox txtFindAccess;
		protected System.Web.UI.WebControls.Button btnGetAccess;
		protected System.Web.UI.WebControls.Label lblFindAny;
		protected System.Web.UI.WebControls.TextBox txtFindAny;
		protected System.Web.UI.WebControls.Button btnFindAny;
		protected System.Web.UI.WebControls.Label lblFirstName;
		protected System.Web.UI.WebControls.Label lblLastName;
		protected System.Web.UI.WebControls.Button btnNew;
		protected System.Web.UI.WebControls.Button btnEdit;
		protected System.Web.UI.WebControls.Button btnSave;
		protected System.Web.UI.WebControls.Button btnCancel;
		protected System.Web.UI.WebControls.Button btDelete;
		protected System.Web.UI.WebControls.TextBox txtRetypePWD;
		protected System.Web.UI.WebControls.ListBox lstAccess;
		
		protected Evolve.Web.UI.Toolbar.Toolbar toolbarUsrAcc;
		protected System.Web.UI.WebControls.Label Label1;
		protected System.Web.UI.WebControls.TextBox txtSearchLogin;
		protected System.Web.UI.WebControls.Label Label2;
		protected System.Web.UI.WebControls.TextBox txtSearchLastName;
		protected System.Web.UI.WebControls.Label Label3;
		protected System.Web.UI.WebControls.TextBox txtSearchFirstName;
		protected System.Web.UI.WebControls.Label Label4;
		protected System.Web.UI.WebControls.Label Label5;
		protected System.Web.UI.WebControls.TextBox txtSearchAny;
		protected System.Web.UI.WebControls.Button btnSearch;
		protected System.Web.UI.WebControls.Button btnAllSearch;
		protected System.Web.UI.WebControls.Button btnPostback;
		protected System.Web.UI.HtmlControls.HtmlInputHidden hdnContactID;
		protected System.Web.UI.WebControls.Label lblSearchResults;
		protected System.Web.UI.WebControls.Button btnDeleteSelected;
		protected System.Web.UI.WebControls.Button btnSaveNew;
		protected System.Web.UI.WebControls.Button btnClear;
		protected System.Web.UI.WebControls.DropDownList ddlSearchAccess;
		protected System.Web.UI.WebControls.DropDownList ddlSearchModify;
				
		#endregion

		#region PageLoad

		/// <summary>
		/// Page Load Event
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void Page_Load(object sender, System.EventArgs e)
		{
		   bCheckUserID = true;
		   if(!IsPostBack)
		   {
			    // Setting the Permission ID to Screen
			    PermissionID = "1";
				// Binding data to Access listbox
				BindListboxs();
			    // Enable of controls on pageload
			    //EnableControls(true, false, false, false, false, toolbarUsrAcc);
			   EnableControls(false, true, true, true); 
			   //Binding data to grid

			   Search = " and 1=2 ";
			   GridBind(dgAccount, "AccountSearch", Search);	
			   //GridBind(dgAccount, "AccountGridBind", "");
		   }

			lstAccess.Attributes.Add("onclick", "CheckTechnician()");
//			toolbarUsrAcc.Items["tbtnSave"].Attributes.Add("onclick","return IsRequired()");
			btnDeleteSelected.Attributes.Add("onclick","return IsDelete()");
			btnSave.Attributes.Add("onclick","return IsRequired()");
			btnSaveNew.Attributes.Add("onclick","return IsRequired()");
		}

		protected void EnableControls(bool savebtn, bool deletbtn, bool savenewbtn, bool clearbtn)
		{
			btnSave.Enabled = savebtn;
			btnDeleteSelected.Enabled = true;
			btnClear.Enabled = clearbtn;
			btnSaveNew.Enabled = savenewbtn;
		}

		private void EnablePassword(bool password)
		{
			txtPassword.Enabled = password;
			txtRetypePWD.Enabled = password;
		}
		#endregion

		#region BindListboxs

		/// <summary>
		/// Binds the Access and Technician List boxes data
		/// </summary>
		private void BindListboxs()
		{
			DataSet dsAccess		=	GetDataset("Roles", "");
			lstAccess.DataSource	=	dsAccess;
			lstAccess.DataTextField	=	"Name";
			lstAccess.DataValueField=	"RoleID";
			lstAccess.DataBind();
			lstTechnicianType.DataSource		=	GetDataset("Codes", "4");
			lstTechnicianType.DataTextField	=	"Decode";
			lstTechnicianType.DataValueField =	"CodeID";
			lstTechnicianType.DataBind();
		
			ddlSearchAccess.DataSource = dsAccess;
			ddlSearchAccess.DataTextField	=	"Name";
			ddlSearchAccess.DataValueField=	"RoleID";
			ddlSearchAccess.DataBind();
			ddlSearchAccess.Items.Insert(0, "Select");
			ddlSearchAccess.SelectedIndex = 0;

		}
		
		#endregion
		
		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
			this.btnAllSearch.Click += new System.EventHandler(this.btnAllSearch_Click);
			this.btnPostback.Click += new System.EventHandler(this.btnPostback_Click);
			this.dgAccount.ItemDataBound += new System.Web.UI.WebControls.DataGridItemEventHandler(this.dgAccount_ItemDataBound);
			this.btnDeleteSelected.Click += new System.EventHandler(this.btnDeleteSelected_Click);
			this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
			this.btnSaveNew.Click += new System.EventHandler(this.btnSaveNew_Click);
			this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		#region IsEnabled method
		/// <summary>
		/// Enable or Disable the Ctntorls based on the requirement
		/// </summary>
		/// <param name="bEnable">True/False</param>
		private void IsEnabled(bool bEnable)
		{
			txtFirstName.Enabled		=	bEnable;
			txtLastName.Enabled			=	bEnable;
			txtMiddleName.Enabled		=	bEnable;
			txtLoginID.Enabled			=	bEnable;
			txtPassword.Enabled			=	bEnable;
			txtRetypePWD.Enabled		=	bEnable;
			txtSecretQuestion.Enabled	=	bEnable;
			txtAnswer.Enabled			=	bEnable;
			lstAccess.Enabled			=	bEnable;
			lstTechnicianType.Enabled	=	bEnable;
			ddlModifyRec.Enabled		=	bEnable;
		}


		#endregion

		#region ClearControls method

		/// <summary>
		/// Clear the Contrls Data
		/// </summary>
		private void ClearControls()
		{
			txtFirstName.Text		=	string.Empty;
			txtLastName.Text		=	string.Empty;
            txtMiddleName.Text		=	string.Empty;
			txtLoginID.Text			=	string.Empty;
			txtPassword.Text		=	string.Empty;
			txtRetypePWD.Text		=	string.Empty;
			txtSecretQuestion.Text	=	string.Empty;
			txtAnswer.Text			=	string.Empty;
			hdnContactID.Value = string.Empty;
			ddlModifyRec.SelectedIndex	=	-1;
			lstAccess.ClearSelection();
			lstTechnicianType.ClearSelection();
		}


		#endregion

		#region AlertMessage

		private void ALertMessage(string text, string focus)
		{
			string strScript = "<script language=javascript>";
			if(!text.Equals(""))
				strScript += "alert('"+ text +"');";
			if(focus == "")
				strScript += "document.getElementById('txtFirstName').focus();";
			strScript += "</script>";
			RegisterStartupScript("MM", strScript);
		}

		#endregion

		#region Save Button Click Event

		/// <summary>
		/// Saves the Datainto Database by calling Business Logic Layer
		/// </summary>
		private void Save()
		{
			Response response;
			BusinessData data = new BusinessData();
			AccountBLL acount = new AccountBLL();
			DataSet dsUser = GetDataset("UserInfoStructure", "");
			data.Action = PermissionID;
			data.UserID = Session["UserID"].ToString();
			switch(PageMode)
			{
				case "New":
					string strWhere = "<Query><TableName>UserInfo</TableName><ColumnName>LoginID</ColumnName><Name>"+ txtLoginID.Text +"</Name></Query>";
					// Code for Checking Unique Procedure
					if (Convert.ToInt16(GetValue("UniqueProcedure", strWhere)) > 0)
					{
						ALertMessage(" LoginID "  + txtLoginID.Text + " Already Exists", "");
						GridBind(dgAccount, "AccountSearch", Search);	
						//GridBind(dgAccount, "AccountGridBind", "");
						IsEnabled(true);
						EnableControls(false, false, false, true, true, toolbarUsrAcc); 	
						break;
					}	

					PrimaryKey = Guid.NewGuid().ToString();
					data.MethodName = "Create";
					GetValues(dsUser); // for assigning the Latest data to dataset
					data.NewEntity = dsUser;
					response = acount.Save(data);
					if(response.Status.ToString().Equals("Success"))
					{
						ALertMessage(txtLoginID.Text + " Record Saved Successfully","");
						ClearControls();
						IsEnabled(true);
						//EnableControls(true, false, true, false, false, toolbarUsrAcc);
						PageMode  = "New";
					}
					else
						ALertMessage(txtLoginID.Text + " Record Failed " + response.ErrorMessage, "");

					GridBind(dgAccount, "AccountSearch", Search);	
					//GridBind(dgAccount, "AccountGridBind", "");
					break;

				case "Edit":
					strWhere = "<Query><TableName>UserInfo</TableName><PKColumn>UserID</PKColumn><ColumnName>LoginID</ColumnName><Name>"+ txtLoginID.Text +"</Name><ProcedureID>"+ PrimaryKey +"</ProcedureID></Query>";
					if (Convert.ToInt16(GetValue("UniqueProcedureUpdate", strWhere)) > 0)
					{
						ALertMessage(" LoginID "  + txtLoginID.Text + " Already Exists", "");
						GridBind(dgAccount, "AccountSearch", Search);	
						//GridBind(dgAccount, "AccountGridBind", "");
						EnableControls(true, false, true, true, true, toolbarUsrAcc);
						IsEnabled(true);
						break;
					}	
					data.MethodName = "Update";
					GetValues(dsUser); // for assigning the Lastet data to dataset
					data.NewEntity = dsUser;
					response = acount.Save(data);
					if(response.Status.ToString().Equals("Success"))
					{
						ALertMessage(txtLoginID.Text + " Record Updated Successfully","");
						ClearControls();
						IsEnabled(true);
						//EnableControls(true, false, true, false, false, toolbarUsrAcc);
						PageMode  = "New";
					}
					else
						ALertMessage(txtLoginID.Text + " Record Failed " + response.ErrorMessage, "");

					GridBind(dgAccount, "AccountSearch", Search);	
					//GridBind(dgAccount, "AccountGridBind", "");
					
					break;
				
				case "Delete":
					int flag = 0;
					for(int iCount = 0; iCount < dgAccount.Items.Count; iCount++)
					{
						CheckBox chk = (CheckBox)dgAccount.Items[iCount].FindControl("chkDel");
						if(chk != null)
						{
							
							if(chk.Checked)
							{
								string strPrimaryKey    = dgAccount.Items[iCount].Cells[0].Text;
								DataSet dsReccSelect	=	GetDataset("AccountBind", strPrimaryKey);
								string strContactId		= dsReccSelect.Tables[0].Rows[0]["ContactID"].ToString();
								DataRow dr = dsUser.Tables[0].NewRow();
								dsUser.Tables[0].TableName = "UserInfo";
								dr["UserID"] = strPrimaryKey;
								dr["ContactID"] = strContactId;
								dsUser.Tables[1].TableName = "Contact";
								dsUser.Tables[0].Rows.Add(dr);
								dr = dsUser.Tables[1].NewRow();
								dr["ContactID"] = strContactId;
								dsUser.Tables[1].Rows.Add(dr);
								dr = dsUser.Tables[2].NewRow();
								dr["UserID"] = strPrimaryKey;
								dsUser.Tables[2].TableName = "UserRole";
								dsUser.Tables[2].Rows.Add(dr);

								flag = 1;
							}
						}
						
					}

					if(flag == 0)
					{
						ALertMessage("Select Any Account To Delete","");
						break;
					}
					else
					{
						data.MethodName = "Delete";
						data.NewEntity = dsUser;
						response = acount.Save(data);
						if(response.Status.ToString().Equals("Success"))
						{
							ALertMessage("Deleted Successfully","");
							ClearControls();
							IsEnabled(false);
							PageMode  = "";
						}
						else
							ALertMessage("Deletion Failed","");

						GridBind(dgAccount, "AccountSearch", Search);	
						break;
					}
					
					
			}
		}

		/// <summary>
		/// Clears the Datagrid Checkboxs
		/// </summary>
		private void ClearCheckboxs()
		{
			for(int iCount = 0; iCount < dgAccount.Items.Count; iCount++)
			{
				CheckBox chk = (CheckBox)dgAccount.Items[iCount].FindControl("chkDel");
				if(chk != null)
				{
					if(chk.Checked)
					{	
						chk.Checked = false;
					}
				}
			}
		}
		#endregion

		#region Tool bar Events

		/// <summary>
		/// Tool Bar Events
		/// </summary>
		/// <param name="item"></param>
		private void toolbarUsrAcc_ItemPostBack(Evolve.Web.UI.Toolbar.ToolbarItem item)
		{
			//BusinessData data = new BusinessData();
			//TechnicianBLL bll = new TechnicianBLL();
			switch(item.ItemId.ToString())
			{
				case "tbtnNew":
					ClearControls();
					IsEnabled(true);
					EnableControls(false, false, false, true, true, toolbarUsrAcc); 	
					PageMode =	"New";
					dgAccount.SelectedIndex = -1;
					GridBind(dgAccount, "AccountSearch", Search);	
					//GridBind(dgAccount, "AccountGridBind", "");
					break;

				case "tbtnEdit":
					if(!UpdatePermission())
						ALertMessage("You dont have Update Permission", "txtName");
					else
					{
						PageMode  = "Edit";
						EnableControls(true, false, true, true, true, toolbarUsrAcc);
						IsEnabled(true);
						bool bAdmingroup = (bool)Session["AdminGroup"];
						if(Session["UserID"].ToString().Equals("6") || bAdmingroup)
							EnablePassword(true);
						else
							EnablePassword(false);
					}
					GridBind(dgAccount, "AccountSearch", Search);	
					//GridBind(dgAccount, "AccountGridBind", "");
					break;

				case "tbtnDelete":
					PageMode  = "Delete";
					Save();
					ClearControls();
					IsEnabled(false);
					EnableControls(true, false, false, false, false, toolbarUsrAcc);
					break;

				case "tbtnCancel":
					ClearControls();
					IsEnabled(false);
					EnableControls(true, false, false, false, false, toolbarUsrAcc); 	
					GridBind(dgAccount, "AccountSearch", Search);	
					//GridBind(dgAccount, "AccountGridBind", "");
					break;

				case "tbtnSave":
					Save();
					break;
			}
		}
		

		#endregion

		#region Get Data
		
		/// <summary>
		/// Assign the scren values to dataset
		/// </summary>
		/// <param name="dsUser"></param>
		private void GetValues(DataSet dsUser)
		{
			// Assigning the User Info Data
			DataRow drUser = dsUser.Tables[0].NewRow();
			dsUser.Tables[0].TableName = "UserInfo";
			drUser["UserID"] = PrimaryKey;
			drUser["LoginID"] = txtLoginID.Text;
			drUser["Password"] = txtPassword.Text;
			drUser["Question"] = txtSecretQuestion.Text;
			drUser["Answer"] = txtAnswer.Text;
			drUser["ContactID"] = hdnContactID.Value;
			drUser["Technition"] = GetTechnicianSelectedValues();
			drUser["ModifyRecord"] = ddlModifyRec.SelectedValue;
			drUser["CompanyID"] = 1;
			drUser["BranchID"] = 1;
			drUser["IsActive"] = 1;
			dsUser.Tables[0].Rows.Add(drUser);

			// Assigning Contact Info Data
			drUser = dsUser.Tables[1].NewRow();
			dsUser.Tables[1].TableName = "Contact";
			drUser["ContactID"] = hdnContactID.Value;
			drUser["FirstName"] = txtFirstName.Text;
			drUser["LastName"] = txtLastName.Text;
			drUser["MiddleName"] = txtMiddleName.Text;
			drUser["IsActive"] = 1;
			dsUser.Tables[1].Rows.Add(drUser);
			
			// Assigning Selected Roles
			dsUser.Tables[2].TableName = "UserRole";
			BuildUserRoles(dsUser);

		}
		#endregion

		#region Technician Selected values insert
		private string GetTechnicianSelectedValues()
		{
			int iCount = lstTechnicianType.Items.Count;
			string strSelected = string.Empty;
			for(int iListCount = 0; iListCount < iCount; iListCount++)
			{
				if (lstTechnicianType.Items[iListCount].Selected)
					strSelected += lstTechnicianType.Items[iListCount].Value + ":";
			}
			if(strSelected!=string.Empty)
			strSelected = strSelected.Substring(0, strSelected.Length -1);
			return strSelected;
			
		}
		#endregion

		#region Technician Selected values update
		private void SetTechnicianSelectedValues(string values)
		{
			lstTechnicianType.ClearSelection();
			string[] strValues = values.Split(':');
			for(int i = 0; i < strValues.Length; i++)
			{
				ListItem item = lstTechnicianType.Items.FindByValue(strValues[i]);
				if(item != null)
					item.Selected = true;
			}
		}
		#endregion

		#region User Role Insert
		
		private void BuildUserRoles(DataSet dsUser)
		{
			int iCount = lstAccess.Items.Count;
			DataRow drUserRole = null;
			for(int iListCount = 0; iListCount < iCount; iListCount++)
			{
				drUserRole = dsUser.Tables[2].NewRow();
				if (lstAccess.Items[iListCount].Selected)
				{
					drUserRole["UserID"] = PrimaryKey;
					drUserRole["RoleID"] = lstAccess.Items[iListCount].Value;
					drUserRole["IsActive"] = 1;
					dsUser.Tables[2].Rows.Add(drUserRole);
				}
			}
		}

		#endregion

		#region User Role Update
		private string BuildUserRoleUpdate(string userid)
		{
			int iCount = lstAccess.Items.Count;
			string strQuery = string.Empty;
			for(int iListCount = 0; iListCount < iCount; iListCount++)
			{
				if (lstAccess.Items[iListCount].Selected)
					strQuery += "Update User_Role set UserId = '" + userid + "' where RoleId = '" + lstAccess.Items[iListCount].Value + "'";
			}
			return strQuery;
		}
		#endregion

		#region Data Grid Item Command
		/// <summary>
		/// 
		/// </summary>
		/// <param name="source"></param>
		/// <param name="e"></param>
		private void dgAccount_ItemCommand(object source, System.Web.UI.WebControls.DataGridCommandEventArgs e)
		{
			dgAccount.SelectedIndex =	e.Item.ItemIndex;
			if(e.CommandName == "Select")
			{
				DataSet dsReccSelect	=	GetDataset("AccountBind", e.Item.Cells[0].Text);
				if(dgAccount.SelectedItem.Cells[1].Text != "&nbsp;")
				{
					if(dsReccSelect.Tables[0].Rows.Count>0)
					{
						txtLoginID.Text					=	dsReccSelect.Tables[0].Rows[0]["LoginId"].ToString();
						txtPassword.Text				=	dsReccSelect.Tables[0].Rows[0]["Password"].ToString();
						txtRetypePWD.Text				=	dsReccSelect.Tables[0].Rows[0]["Password"].ToString();
						txtSecretQuestion.Text			=	dsReccSelect.Tables[0].Rows[0]["question"].ToString();
						txtAnswer.Text					=	dsReccSelect.Tables[0].Rows[0]["Answer"].ToString();
						SetTechnicianSelectedValues(dsReccSelect.Tables[0].Rows[0]["Technition"].ToString());
						ddlModifyRec.SelectedValue		=	dsReccSelect.Tables[0].Rows[0]["ModifyRecord"].ToString();
						
					}
					if(dsReccSelect.Tables[1].Rows.Count>0)
					{
						txtFirstName.Text				=	dsReccSelect.Tables[1].Rows[0]["FirstName"].ToString();
						txtLastName.Text				=	dsReccSelect.Tables[1].Rows[0]["LastName"].ToString();
						txtMiddleName.Text				=	dsReccSelect.Tables[1].Rows[0]["MiddleName"].ToString();
					}
					int iRowCount = dsReccSelect.Tables[2].Rows.Count;
					lstAccess.ClearSelection();
					lstTechnicianType.Enabled = false;
					if(iRowCount>0)
					{
						for(int i = 0 ;i<iRowCount;i++)
						{
							ListItem item = lstAccess.Items.FindByValue(dsReccSelect.Tables[2].Rows[i]["RoleID"].ToString());
							if(item != null)
								item.Selected = true;
							if(dsReccSelect.Tables[2].Rows[i]["RoleID"].ToString().Equals("5"))
								lstTechnicianType.Enabled = true;
						}
					}
					IsEnabled(true);
					EnableControls(true, true, true, false, false, toolbarUsrAcc);
				}
				else
				{
					ClearControls();
					EnableControls(true, false, false, false, false, toolbarUsrAcc);
				}
			}
			IsEnabled(false);

		}

		public void dgAccount_select(object sender, System.EventArgs e)
		{
			try
			{
				Label lUserID = (Label) dgAccount.SelectedItem.FindControl("glblUserID");
				PrimaryKey =  lUserID.Text;
				if(!UpdatePermission())
					ALertMessage("You dont have Update Permission", "txtName");
				else
				{
					PageMode  = "Edit";
					IsEnabled(true);
					bool bAdmingroup = (bool)Session["AdminGroup"];
					IsEnabled(true);
					if(Session["UserID"].ToString().Equals("6") || bAdmingroup)
						EnablePassword(true);
					else
						EnablePassword(false);
					PopulateData();
					ClearCheckboxs();
					CheckBox chkDel = (CheckBox)dgAccount.SelectedItem.FindControl("chkDel");
					if(chkDel != null)
						chkDel.Checked = true;
					EnableControls(true, true, true, true); 
				}
				//GridBind(dgAccount, "AccountSearch", Search);	
			}
			catch(Exception)
			{}
		}
		#endregion

		#region Search 
		/// <summary>
		/// Search Button Event
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void btnSearch_Click(object sender, System.EventArgs e)
		{
			string strWhere = string.Empty;
			if(txtSearchLogin.Text.Trim().Length > 0)
			{
				strWhere = " u.LoginID like '" + txtSearchLogin.Text + "%'";
			}
			if(txtSearchFirstName.Text.Trim().Length > 0)
			{
				strWhere = strWhere +  " or c.FirstName like '" + txtSearchFirstName.Text + "%'";
			}
			
			if(txtSearchLastName.Text.Trim().Length > 0)
			{
				strWhere = strWhere +  " or c.LastName like '" + txtSearchLastName.Text + "%'";
			}

			if(!ddlSearchModify.SelectedValue.Equals("-1"))
			{
				strWhere = strWhere + " or u.ModifyRecord = " + ddlSearchModify.SelectedValue;
			}

			if(ddlSearchAccess.SelectedIndex != 0)
			{
				strWhere = strWhere + " or UserID in (select UserID from User_role where roleid = '"+ddlSearchAccess.SelectedValue+"')";
			}

			if (strWhere.StartsWith(" or"))
				strWhere = strWhere.Substring(3);

			if(strWhere.Trim().Length > 1)
				strWhere = " where " + strWhere;
			
			Search = strWhere;

			//GridBind(dgAccount, "AccountSearch", Search);
			Binddata();
			EnableControls(true, false, true, false, false, toolbarUsrAcc); 	
		}

		/// <summary>
		/// Binds the data to search grid based on the search criteria
		/// </summary>
		private void Binddata()
		{
			ClearControls();
			DataSet ds = GetDataset("AccountSearch", Search);
			lblSearchResults.Text = ds.Tables[0].Rows.Count + " Users Found";
			if(ds.Tables[0].Rows.Count == 1)
			{
				PrimaryKey = ds.Tables[0].Rows[0]["UserID"].ToString();
				PopulateData();
			}
			AddDummyRows(ds, 0, Convert.ToInt32(ConfigurationSettings.AppSettings["GridRows"]));
			dgAccount.DataSource = ds;
			dgAccount.DataBind();
		}


		/// <summary>
		/// this function checks entered data in to all colums and returns
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void btnAllSearch_Click(object sender, System.EventArgs e)
		{
			string strWhere = string.Empty;
			if(txtSearchAny.Text.Trim().Length > 0)
			{
				strWhere = " u.LoginID like '" + txtSearchAny.Text + "%'";
				strWhere = strWhere +  " or c.FirstName like '" + txtSearchAny.Text + "%'";
				strWhere = strWhere +  " or c.LastName like '" + txtSearchAny.Text + "%'";
				strWhere = strWhere +  " or c.MiddleName like '" + txtSearchAny.Text + "%'";
				strWhere = strWhere +  " or u.Question like '" + txtSearchAny.Text + "%'";
				strWhere = strWhere +  " or u.Answer like '" + txtSearchAny.Text + "%'";
			}

			if (strWhere.StartsWith(" or"))
				strWhere = strWhere.Substring(3);

			if(strWhere.Trim().Length > 1)
				strWhere = " where " + strWhere;

			Search = strWhere;

			//GridBind(dgAccount, "AccountSearch", strWhere);
			Binddata();
			EnableControls(true, false, false, false, false, toolbarUsrAcc); 	
		}
		#endregion

		#region Attaching DobuleClick
		/// <summary>
		/// Attaches Double click event and sends RoleId and RoleName as arguments to GetPostBackClientEvent
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void dgAccount_ItemDataBound(object sender, System.Web.UI.WebControls.DataGridItemEventArgs e)
		{
			if(e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem || e.Item.ItemType == ListItemType.SelectedItem )
			{
				if(e.Item.Cells[0].Text.ToString() != "&nbsp;")
				{
					string strArgs = e.Item.Cells[0].Text + ";" + e.Item.ItemIndex;
					e.Item.Cells[0].Attributes.Add("onclick", Page.GetPostBackClientEvent(btnPostback, strArgs));
					e.Item.Cells[1].Attributes.Add("onclick", Page.GetPostBackClientEvent(btnPostback, strArgs));
					e.Item.Cells[2].Attributes.Add("onclick", Page.GetPostBackClientEvent(btnPostback, strArgs));
					e.Item.Cells[3].Attributes.Add("onclick", Page.GetPostBackClientEvent(btnPostback, strArgs));
					e.Item.Cells[4].Attributes.Add("onclick", Page.GetPostBackClientEvent(btnPostback, strArgs));
					//e.Item.Cells[5].Attributes.Add("onclick", Page.GetPostBackClientEvent(btnPostback, strArgs));
					
					//adding checkbox in the last row
					//CheckBox chkDel = new CheckBox();
					//chkDel.ID = "chkDel";
					//e.Item.Cells[5].Controls.Add(chkDel);
				}
				else
				{
					//e.Item.Cells[4].FindControl()
					CheckBox chk = (CheckBox)e.Item.FindControl("chkDel");
					chk.Enabled = false;
				}
					
				
			}
			
		}

		#endregion

		#region doubleclick postback event
		/// <summary>
		/// fires when cell is doubleclicked and gets RoleName and RoleId values in respective textboxes
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void btnPostback_Click(object sender, System.EventArgs e)
		{
			string strArguments = this.Page.Request["__EVENTARGUMENT"];
			string[] _strArgs = strArguments.Split(new char[]{';'});

			PrimaryKey = _strArgs[0]; // setting the Procedure ID
			
			if(!UpdatePermission())
				ALertMessage("You dont have Update Permission", "txtName");
			else
			{
				PageMode  = "Edit";
				IsEnabled(true);
				bool bAdmingroup = (bool)Session["AdminGroup"];
				IsEnabled(true);
				if(Session["UserID"].ToString().Equals("6") || bAdmingroup)
					EnablePassword(true);
				else
					EnablePassword(false);
				PopulateData();
				GridBind(dgAccount, "AccountSearch", Search);	
				CheckBox chkDel = (CheckBox)dgAccount.Items[Convert.ToInt32(_strArgs[1])].FindControl("chkDel");
				if(chkDel != null)
					chkDel.Checked = true;
				EnableControls(true, true, true, true); 
				dgAccount.Items[Convert.ToInt32(_strArgs[1])].CssClass = "GridSelectedItemStyle";
			}
		}

		private void PopulateData()
		{
			DataSet dsReccSelect	=	GetDataset("AccountBind", PrimaryKey);
			if(dsReccSelect.Tables[0].Rows.Count>0)
			{
				txtLoginID.Text					=	dsReccSelect.Tables[0].Rows[0]["LoginId"].ToString();
				txtPassword.Text				=	dsReccSelect.Tables[0].Rows[0]["Password"].ToString();
				txtRetypePWD.Text				=	dsReccSelect.Tables[0].Rows[0]["Password"].ToString();
				txtSecretQuestion.Text			=	dsReccSelect.Tables[0].Rows[0]["question"].ToString();
				txtAnswer.Text					=	dsReccSelect.Tables[0].Rows[0]["Answer"].ToString();
				SetTechnicianSelectedValues(dsReccSelect.Tables[0].Rows[0]["Technition"].ToString());
				ddlModifyRec.SelectedValue		=	dsReccSelect.Tables[0].Rows[0]["ModifyRecord"].ToString();
				hdnContactID.Value				=	dsReccSelect.Tables[0].Rows[0]["ContactID"].ToString();
			}
			if(dsReccSelect.Tables[1].Rows.Count>0)
			{
				txtFirstName.Text				=	dsReccSelect.Tables[1].Rows[0]["FirstName"].ToString();
				txtLastName.Text				=	dsReccSelect.Tables[1].Rows[0]["LastName"].ToString();
				txtMiddleName.Text				=	dsReccSelect.Tables[1].Rows[0]["MiddleName"].ToString();
			}
			int iRowCount = dsReccSelect.Tables[2].Rows.Count;
			lstAccess.ClearSelection();
			lstTechnicianType.Enabled = false;
			if(iRowCount>0)
			{
				for(int i = 0 ;i<iRowCount;i++)
				{
					ListItem item = lstAccess.Items.FindByValue(dsReccSelect.Tables[2].Rows[i]["RoleID"].ToString().Trim());
					if(item != null)
					{
						if (item.Value.Equals("5"))
							lstTechnicianType.Enabled = true;
						item.Selected = true;
					}
				}
			}
			//GridBind(dgAccount, "AccountGridBind", "");
			//EnableControls(true, true, true, false, false, toolbarUsrAcc);
		
		}

		#endregion

		#region Button Click Events


		private void btnSave_Click(object sender, System.EventArgs e)
		{
			Save();
			EnableControls(false, false, true, true); 
		}

		private void btnSaveNew_Click(object sender, System.EventArgs e)
		{
			PageMode = "New";
			Save();
			EnableControls(false, false, true, true); 
		}

		private void btnClear_Click(object sender, System.EventArgs e)
		{
			ClearControls();
			IsEnabled(true);
			GridBind(dgAccount, "AccountSearch", Search);
			PageMode = "New";
			EnableControls(false, false, true, true); 
		}

		private void btnDeleteSelected_Click(object sender, System.EventArgs e)
		{
			PageMode  = "Delete";
			Save();
			ClearControls();
			IsEnabled(true);
			EnableControls(false, false, true, true); 
		}

		#endregion

	}
}
