using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using Zaxis.Definitions;
using Zaxis.USD.BusinessLogic;

namespace Zaxis.USD.Web
{
	/// <summary>
	/// Summary description for UserAccount.
	/// </summary>
	public class Message : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.Label lblMessage;
		protected System.Web.UI.WebControls.Label lblHeader;

		private void Page_Load(object sender, System.EventArgs e)
		{
			// Setting the Permission ID to Screen

			string strMessageType = Request.QueryString["MsgType"].ToString();
			if(strMessageType.Equals("L"))
			{
				lblHeader.Text = "Information";
				lblMessage.Text = "You have been successfully Logged out";
			}
			else if(strMessageType.Equals("E"))
			{
				lblHeader.CssClass = "Style2";
				lblHeader.Text = "Information";
				lblMessage.CssClass = "style5";
				lblMessage.Text = "<center><br><br>Your Session has been expired....</center><br><center><a href=logon.aspx target=topMostFrame>Click here to Login</a></center>";
			
			}
			else if(strMessageType.Equals("A"))
			{
				lblHeader.CssClass = "Style2";
				lblHeader.Text = "Information";
				lblMessage.CssClass = "style5";
				lblMessage.Text = "<center><br><br>Sorry You Don't Have Access Permission....</center><br><center>Contact Administrator</center>";
			
			}

		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

	}
}
