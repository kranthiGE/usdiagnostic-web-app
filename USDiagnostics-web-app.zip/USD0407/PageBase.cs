
#region  Page Level Comments

/*******************************************************************************************
/*File Name	      :			PageBase
 *Project Name    :			USD 1.0
 *Object          :			Web
 *Purpose         :			
 *Author          :			Desayya
 *Date            :			10-5-2006 
 *ModuleName      :			USD
 *This file is provided as part of Zaxis-USD project.
 *Copyright � 2004-07, Zaxis-USD Technologies, All rights reserved
 * ************************************ Revision History************************************
 *
 *  Date            Done by             Method             Change Description

*******************************************************************************************/

#endregion

#region NameSpaces

using System;
using System.Web.UI;
using System.Data;
using System.Web.Mail;
using System.Web.UI.WebControls;
using Microsoft.Practices.EnterpriseLibrary.Data;
using System.Data.SqlClient;
using System.Configuration;

/// Zaxis Namespaces
using Zaxis.BaseClasses;
using Zaxis.Definitions;
using Zaxis.USD.BusinessLogic;

#endregion

namespace Zaxis.USD.Web
{
	/// <summary>
	/// Summary description for PageBase.
	/// </summary>
	public class PageBase : Page
	{

		#region Constructor

		/// <summary>
		/// Empty Constructor
		/// </summary>
		public PageBase()
		{
		}

		#endregion
		
		#region Property : SearchCondition
		/// <summary>
		/// provides CheckUserID Infor
		/// </summary>
		public string Search
		{
			get 
			{
				object obj = ViewState["Search"]; 
				return (obj == null) ? "" : (string)obj;
			}
			set 
			{
				ViewState["Search"] = value;
			}		
		}

		#endregion

		#region Property : Permission
		/// <summary>
		/// provides CheckUserID Infor
		/// </summary>
		public string PermissionID
		{
			get 
			{
				object obj = ViewState["PermissionID"]; 
				return (obj == null) ? "" : (string)obj;
			}
			set 
			{
				ViewState["PermissionID"] = value;
			}		
		}

		#endregion

		#region Property : CheckUser
		/// <summary>
		/// provides CheckUserID Infor
		/// </summary>
		public bool bCheckUserID
		{
			get 
			{
				object obj = ViewState["CheckUserID"]; 
				return (obj == null) ? false : (bool)obj;
			}
			set 
			{
				ViewState["CheckUserID"] = value;
			}		
		}

		#endregion

		#region Property : PrimaryKey

		/// <summary>
		/// Maintains the Page State
		/// </summary>
		public string PrimaryKey
		{
			get 
			{
				return (ViewState["PrimaryKey"] == null) ? "" : ViewState["PrimaryKey"].ToString();
			}
			set 
			{
				ViewState["PrimaryKey"] = value;
			}		
		}

		#endregion

		#region Onload Event

		/// <summary>
		/// 
		/// </summary>
		/// <param name="e"></param>
		protected override void OnLoad(EventArgs e)
		{
			base.OnLoad (e);
		
			if (bCheckUserID)
			{
				if ((Session["UserID"] == null) || (Session["UserID"].Equals("")))
				{
					Response.Clear();
					Session.Clear();
					Session.RemoveAll() ;
					Server.Transfer("Message.aspx?MsgType=E");
				}
				CheckPermission();
			}
		}
		#endregion

		#region Check Permission
		
		protected void CheckPermission()
		{
			string strWhere = "<Query><UserID>"+ Session["UserID"].ToString() +"</UserID><PermissionID>"+ PermissionID +"</PermissionID></Query>";
			Database  dbInstance = DatabaseFactory.CreateDatabase();  
			int iResult = (int)dbInstance.ExecuteScalar(CommandType.Text, Zaxis.USD.DAL.Queries.GetQuery("PermissionCheck", strWhere));
			dbInstance = null;
			if(iResult == 0)
			{
				Server.Transfer("Message.aspx?MsgType=A");
			}
		}

		protected bool UpdatePermission()
		{
			Database  dbInstance = DatabaseFactory.CreateDatabase();  
			int iResult = Convert.ToInt16(dbInstance.ExecuteScalar(CommandType.Text, Zaxis.USD.DAL.Queries.GetQuery("ModifyPermission", Session["UserID"].ToString())));
			dbInstance = null;
			if(iResult == 1)
				return false;
			else
				return true;
		}

		#endregion

		#region AlertMessage

		private void ShowMessage(string text, string focus)
		{
			string strScript = "<script language=javascript>";
			if(!text.Equals(""))
				strScript += "alert('"+ text +"');";
			strScript += "</script>";
			RegisterStartupScript("MM", strScript);
		}

		#endregion

		#region Adds the Dummyrow 
		/// <summary>
		/// Adds the Dummy row to Dataset
		/// </summary>
		/// <param name="dsOriginal">Dataset</param>
		/// <param name="iTableNo">Table Number</param>
		/// <param name="iRows">Count of Dummy Rows</param>
		protected void AddDummyRows(DataSet dataset, int iTableNo, int iRows)
		{
			int iRowCount = dataset.Tables[iTableNo].Rows.Count;
			for (int i = iRowCount; i < iRows; i++)
			{
				DataRow dr = dataset.Tables[iTableNo].NewRow();
				dataset.Tables[iTableNo].Rows.Add(dr);
			}
		}
		#endregion

		#region Grid Bind

		/// <summary>
		/// Binds the datato datagrid
		/// </summary>
		/// <param name="dg">Datagrid Object</param>
		/// <param name="query">Query Name</param>
		/// <param name="where">Where Condition</param>
		protected void GridBind(DataGrid dg, string query, string where)
		{
			DataSet ds = GetDataset(query, where);
			AddDummyRows(ds, 0, Convert.ToInt32(ConfigurationSettings.AppSettings["GridRows"]));
			dg.DataSource = ds;
			dg.DataBind();
		}
		#endregion

		#region Get Dataset

		/// <summary>
		/// Returns the Dataset
		/// </summary>
		/// <param name="queryname"></param>
		/// <param name="wherestring"></param>
		/// <returns></returns>

		protected DataSet GetDataset(string queryname, string wherestring)
		{
			Database  dbInstance = DatabaseFactory.CreateDatabase();  
			DataSet ds = dbInstance.ExecuteDataSet(CommandType.Text, Zaxis.USD.DAL.Queries.GetQuery(queryname, wherestring));
			dbInstance = null;
			return ds;
		}

		/// <summary>
		/// Returns the Dataset From procedure
		/// </summary>
		/// <param name="procedurename"></param>
		/// <returns></returns>
		protected DataSet GetDataset(string procedurename)
		{
			Database  dbInstance = DatabaseFactory.CreateDatabase();  
			DataSet ds = dbInstance.ExecuteDataSet(CommandType.StoredProcedure, procedurename );
			AddDummyRows(ds, 0, 10);
			dbInstance = null;
			return ds;
		}

		/// <summary>
		/// Returns Value
		/// </summary>
		/// <param name="queryname"></param>
		/// <param name="wherestring"></param>
		/// <returns></returns>
		protected object GetValue(string queryname, string wherestring)
		{
			Database  dbInstance = DatabaseFactory.CreateDatabase();  
			object objData = dbInstance.ExecuteScalar(CommandType.Text, Zaxis.USD.DAL.Queries.GetQuery(queryname, wherestring));
			dbInstance = null;
			return objData;
		}
		#endregion

		#region Mail Send
	
		/// <summary>
		/// Sends the SMTP mail
		/// </summary>
		/// <param name="toUser">TO User Address</param>
		/// <param name="fromUser">From User Address</param>
		/// <param name="Message">Message Body</param>
		public void MailSend(string toUser, string fromUser, string Message)
		{
			MailMessage MMessage = new MailMessage();
			MMessage.To = toUser;
			MMessage.From = fromUser;
			MMessage.BodyFormat = MailFormat.Html;
			MMessage.Priority = MailPriority.Normal;
			MMessage.Subject = "Password changed";
			MMessage.Body = Message;
			SmtpMail.SmtpServer = "";
			SmtpMail.Send(MMessage);
			string server = SmtpMail.SmtpServer;
		}
		#endregion
		
		#region Page Mode

		/// <summary>
		/// Maintains the Page State
		/// </summary>
		public string PageMode
		{
			get 
			{
				return (ViewState["PageMode"] == null) ? "" : ViewState["PageMode"].ToString();
			}
			set 
			{
				ViewState["PageMode"] = value;
			}		
		}

		#endregion

		#region Enable Toolbar Controls
		/// <summary>
		/// Enables or Disables the controls
		/// </summary>
		/// <param name="newbtn"></param>
		/// <param name="editbtn"></param>
		/// <param name="deletbtn"></param>
		/// <param name="savebtn"></param>
		/// <param name="cancelbtn"></param>
		protected void EnableControls(bool newbtn, bool editbtn, bool deletbtn, bool savebtn, bool cancelbtn, Evolve.Web.UI.Toolbar.Toolbar toolbarUsrAcc)
		{
//			toolbarUsrAcc.Items["tbtnNew"] .Enabled = newbtn;
//			toolbarUsrAcc.Items["tbtnEdit"].Enabled = editbtn;
//			toolbarUsrAcc.Items["tbtnDelete"].Enabled = deletbtn;
//			toolbarUsrAcc.Items["tbtnSave"].Enabled = savebtn;
//			toolbarUsrAcc.Items["tbtnCancel"].Enabled = cancelbtn;
		}
	
			
		#endregion

		#region ExecuteNonQuery

		public static int ExecuteNonQuery(string query)
		{

			Database  dbInstance = DatabaseFactory.CreateDatabase();  
			return dbInstance.ExecuteNonQuery(CommandType.Text, query);
//			SqlCommand cmd = new SqlCommand(query, GetConnection());
//			return cmd.ExecuteNonQuery();
			
		}
		
		public static int ExecuteNonQuery(string query, SqlTransaction transaction)
		{
			SqlConnection con = GetConnection();
			
			SqlCommand cmd = new SqlCommand(query, GetConnection(), transaction);
			return cmd.ExecuteNonQuery();
			
		}

		#endregion

		#region ExecuteScalar

		public static string ExecuteScalar(string query)
		{
			SqlCommand cmd = new SqlCommand(query, GetConnection());
			return cmd.ExecuteScalar().ToString();
			
		}
		
		#endregion

		#region GetConnection

		public static SqlConnection GetConnection()
		{
			string strCon = ConfigurationSettings.AppSettings["ConnectionString"];
			SqlConnection con = new SqlConnection(strCon);
			con.Open();
			return con;
		}

		#endregion

	}
}
