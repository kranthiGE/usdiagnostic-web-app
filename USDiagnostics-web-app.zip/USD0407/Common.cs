
#region Page Level Comments

/*File Name		: Common.cs
* Project		: USD 1.0
* Object		: Common
* Purpose		: 
* Author		: N.Desayya
* Date			: 27-5-2006
* Module Name	: Common
* This file is provided as part of the Zaxis-USD project
* Copyright � 2004-06, Zaxus Technologies , All rights reserved
* *********************** Revision History ****************************************************************
*	Date            Done by             Change Description
* ***********************************************************************************************************
*/

#endregion

#region Namespace Declaration

// System Namesapaces
using System;
using System.Data;
using System.Web.UI.HtmlControls;

// Zaxis namespace
#endregion


namespace Zaxis.USD.Web
{

	public class Common
	{
		#region Empty Constructor

		public Common()
		{
		}
		
		#endregion

		#region GetRow

		/// <summary>
		/// Rturns the Table row
		/// </summary>
		/// <returns></returns>
		public static HtmlTableRow GetRow()
		{
			HtmlTableRow tr = new HtmlTableRow();
			return tr;
		}
		#endregion

		#region GetTable

		/// <summary>
		/// Returns the Html table
		/// </summary>
		/// <returns></returns>
		public static  HtmlTable GetTable(string width)
		{
			HtmlTable tbl = new HtmlTable();
			tbl.Width = width;
			return tbl;
		
		}

		#endregion
		
		#region GetColumn

		/// <summary>
		/// returns Table Column
		/// </summary>
		/// <returns></returns>
		public static HtmlTableCell GetColumn(string width)
		{
			HtmlTableCell tc = new HtmlTableCell();
			tc.Width = width;
			return tc;
		
		}

		/// <summary>
		/// returns Table Column
		/// </summary>
		/// <returns></returns>
		public static HtmlTableCell GetColumn(string width, string height)
		{
			HtmlTableCell tc = GetColumn(width);
			tc.Height = height;
			return tc;
		}

		#endregion

	}
}
