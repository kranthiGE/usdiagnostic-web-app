
#region  Page Level Comments

/*******************************************************************************************
/*File Name	      :			DispatchControl.cs
 *Project Name    :			USD 1.0
 *Object          :			Code Behind
 *Purpose         :			
 *Author          :			Kiran
 *Date            :			27-5-2006 
 *ModuleName      :			USD
 *This file is provided as part of Zaxis-USD project.
 *Copyright � 2004-07, Zaxis-USD Technologies, All rights reserved
 * ************************************ Revision History************************************
 *
 *  Date            Done by             Method             Change Description

*******************************************************************************************/

#endregion

#region NameSpaces

using System.Data;
using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.Configuration;
//Zaxis Namespaces
using Zaxis.Common;
using Zaxis.USD.BusinessLogic;
using Zaxis.Definitions;

#endregion

namespace Zaxis.USD.Web
{
	/// <summary>
	/// Summary description for DashBoard.
	/// </summary>
	public class DispatchControl : PageBase
	{
		#region Local Variables

		protected System.Web.UI.WebControls.DataGrid dgOrdersDispacthed;
		protected System.Web.UI.WebControls.DataGrid dgTechnician;
		protected System.Web.UI.WebControls.DataGrid dgOrdersPending;
		protected System.Web.UI.WebControls.Button btnGet;
		TechnicianBLL oTechBuss =  new TechnicianBLL();
		protected string strTodaysDate = string.Empty;
		protected System.Web.UI.WebControls.TextBox txtFromDate;
		protected System.Web.UI.WebControls.TextBox txtToDate;

		#endregion

		#region Page Load

		/// <summary>
		/// Page Load Event
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void Page_Load(object sender, System.EventArgs e)
		{
			Hashtable htParamValues = new Hashtable(); 
			btnGet.Attributes.Add("onclick","return RequiredValidation();");
			// Put user code to initialize the page here
			bCheckUserID = true;
			strTodaysDate = DateTime.Now.Date.ToString();
			if(!IsPostBack)
			{
//				txtFromDate.Text = DateTime.Now.Date.ToString();
//				txtToDate.Text =  DateTime.Now.Date.ToString();
//				htParamValues.Add("@To_Date", txtToDate.Text);
//				htParamValues.Add("@From_Date", txtFromDate.Text);
//				TechnicianBLL oBll = new TechnicianBLL();
//				dgOrdersDispacthed.DataSource =  oBll.GetData("sp_USD_Dispatch_OrdersDisp", htParamValues);
//				dgOrdersDispacthed.DataBind();
			}

			//if(!IsPostBack)
			//{
			// Setting the Permission ID to Screen
			PermissionID = "4";

			//GetGridData(dgOrdersPending,"OrdersPending");
			//GetGridData(dgOrdersCompleted,"OrdersCompleted");
			//GetGridData(dgOrdersDispacthed,"OrdersDispatched");
			//				dgOrdersDispacthed.DataSource =  GetDataset("sp_USD_CeoDashBoard_OrdersDisp").Tables[0];
			//				dgOrdersDispacthed.DataBind();

				

//			dgOrdersPending.DataSource =  GetDataset("sp_USD_CeoDashBoard_OrdersPend").Tables[0];
//			dgOrdersPending.DataBind();

			//				dgOrdersCompleted.DataSource =  GetDataset("sp_USD_CeoDashBoard_OrdersComp").Tables[0];
			//				dgOrdersCompleted.DataBind();

//			dgTechnician.DataSource =  GetDataset("sp_USD_CeoDashBoard_Tech").Tables[0];
//			dgTechnician.DataBind();
			//}
			//OrdersPending:OrdersDispatched:OrdersCompleted
		}

		#endregion

		#region Get Grid DAta

		/// <summary>
		/// Assigns the Data to Grid
		/// </summary>
		/// <param name="dgTech"></param>
		/// <param name="strQueryName"></param>
		private void GetGridData(DataGrid dgTech,string strQueryName)
		{
			
			string strQuery = string.Empty;
			try
			{		
				//oTechBuss.
				dgTech.DataSource = GetDataset(strQueryName, "").Tables[0];//oTechBuss.GetDataset("USD",Zaxis.USD.BusinessLogic.Oueries.GetQuery("TECHSTATUS",""),"").Tables[0];//
				dgTech.DataBind();
			}
			catch(Exception ex)
			{
				string strEx =ex.Message;
			}	
		
		}

		#endregion

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.dgOrdersPending.ItemDataBound += new System.Web.UI.WebControls.DataGridItemEventHandler(this.dgOrdersPending_ItemDataBound_1);
			//this.dgOrdersDispacthed.ItemDataBound += new System.Web.UI.WebControls.DataGridItemEventHandler(this.dgOrdersDispacthed_ItemDataBound_1);
			this.btnGet.Click += new System.EventHandler(this.btnGet_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void dgOrdersPending_ItemDataBound_1(object sender, System.Web.UI.WebControls.DataGridItemEventArgs e)
		{
			if(e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem || e.Item.ItemType == ListItemType.SelectedItem )
			{
				//if first cell is empty,attributes should not be added
				if(e.Item.Cells[0].Text.ToString() != "&nbsp;")
				{
					HyperLink hlink = (HyperLink)e.Item.Cells[0].Controls[0];
					e.Item.Cells[0].Attributes.Add("onclick","return showDispatch('"+ hlink.Text +"')");
				}
			}
		}

		//		private void dgOrdersCompleted_ItemDataBound_1(object sender, System.Web.UI.WebControls.DataGridItemEventArgs e)
		//		{
		//			if(e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem || e.Item.ItemType == ListItemType.SelectedItem )
		//			{
		//				//if first cell is empty,attributes should not be added
		//				if(e.Item.Cells[0].Text.ToString() != "&nbsp;")
		//				{
		//					HyperLink hlink = (HyperLink)e.Item.Cells[0].Controls[0];
		//					e.Item.Cells[0].Attributes.Add("onclick","return showDialog('"+ hlink.Text +"')");
		//				}
		//			}
		//		}

		private string GetDate(string date)
		{
			//"07/04/2006"
			return  date.Substring(6,4) + "-" + date.Substring(0,2) + "-" + date.Substring(3,2);
		}

		private void btnGet_Click(object sender, System.EventArgs e)
		{
			Hashtable htParamValues = new Hashtable(); 
			htParamValues.Add("@To_Date", GetDate(txtToDate.Text));
			htParamValues.Add("@From_Date", GetDate(txtFromDate.Text));
			TechnicianBLL oBll = new TechnicianBLL();
			DataSet dsData = oBll.GetData("sp_USD_Dispatch_OrdersDisp", htParamValues);

			//AddDummyRows(dsData, 0, Convert.ToInt32(ConfigurationSettings.AppSettings["GridRows"]));


			dgOrdersDispacthed.DataSource = dsData;
			dgOrdersDispacthed.DataBind();

			dsData = oBll.GetData("sp_USD_DispatchOrdersPend", htParamValues);
			//AddDummyRows(dsData, 0, Convert.ToInt32(ConfigurationSettings.AppSettings["GridRows"]));
			dgOrdersPending.DataSource =  dsData;
			dgOrdersPending.DataBind();

			dsData = oBll.GetData("sp_USD_Dispatch_Tech");
			//AddDummyRows(dsData, 0, Convert.ToInt32(ConfigurationSettings.AppSettings["GridRows"]));
			dgTechnician.DataSource =  dsData;
			dgTechnician.DataBind();
		
		}


//		private void dgOrdersDispacthed_ItemDataBound_1(object sender, System.Web.UI.WebControls.DataGridItemEventArgs e)
//		{
//			if(e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem || e.Item.ItemType == ListItemType.SelectedItem )
//			{
//				//if first cell is empty,attributes should not be added
//				if(e.Item.Cells[0].Text.ToString() != "&nbsp;")
//				{
//					HyperLink hlink = (HyperLink)e.Item.Cells[0].Controls[0];
//					e.Item.Cells[0].Attributes.Add("onclick","return showTechnician('"+ hlink.Text +"')");
//				}
//			}
//		}
	}
}
