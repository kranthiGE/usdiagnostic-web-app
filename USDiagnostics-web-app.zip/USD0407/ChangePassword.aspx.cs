using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace Zaxis.USD.Web
{
	/// <summary>
	/// Summary description for ChangePassword.
	/// </summary>
	public class ChangePassword : PageBase
	{
		protected System.Web.UI.WebControls.Label lblPassword;
		protected System.Web.UI.WebControls.TextBox txtPassword;
		protected System.Web.UI.WebControls.Label lblRetypePassword;
		protected System.Web.UI.WebControls.TextBox txtRetypePassword;
		protected System.Web.UI.WebControls.Button btnSave;
		protected System.Web.UI.WebControls.Label lblOldPassword;
		protected System.Web.UI.WebControls.TextBox txtOldPassword;
		protected System.Web.UI.HtmlControls.HtmlInputHidden hdnContactID;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			btnSave.Attributes.Add("onclick", "return IsRequired()");
			// Put user code to initialize the page here
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void btnSave_Click(object sender, System.EventArgs e)
		{
			string strQuery = "update userinfo set password = '"+txtPassword.Text+"' where userid='"+Session["UserID"].ToString()+"' and password = '"+txtOldPassword.Text+"'";
			int iCount =  ExecuteNonQuery(strQuery);
			if(iCount > 0)
			{
				ALertMessage("Password has been Changed successfully", "");
				Clear();
			}
			else
				ALertMessage("Invalid Data", "txtPassword");
			
		}

		#region Clear Controls

		private void Clear()
		{
			txtOldPassword.Text = "";
			txtPassword.Text = "";
			txtRetypePassword.Text = "";
		}
		#endregion
		#region AlertMessage
		/// <summary>
		/// Dispaly the alert message box
		/// </summary>
		/// <param name="text"></param>
		/// <param name="focus"></param>
		private void ALertMessage(string text, string focus)
		{
			string strScript = "<script language=javascript>";
			if(!text.Equals(""))
				strScript += "alert('"+ text +"');";
			if(focus == "")
				strScript += "document.getElementById('txtFirstName').focus();";
			strScript += "</script>";
			RegisterStartupScript("MM", strScript);
		}

		#endregion
	}
}
