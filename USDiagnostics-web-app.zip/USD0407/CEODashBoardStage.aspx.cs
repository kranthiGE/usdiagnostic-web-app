
#region  Page Level Comments

/*******************************************************************************************
/*File Name	      :			CEODashBoardStage.cs
 *Project Name    :			USD 1.0
 *Object          :			Code Behind
 *Purpose         :			
 *Author          :			Kiran J
 *Date            :			1-6-2006 
 *ModuleName      :			USD
 *This file is provided as part of Zaxis-USD project.
 *Copyright � 2004-07, Zaxis-USD Technologies, All rights reserved
 * ************************************ Revision History************************************
 *
 *  Date            Done by             Method             Change Description

*******************************************************************************************/

#endregion

#region NameSpaces

using System.Data;
using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

//Zaxis Namespaces
using Zaxis.USD.BusinessLogic;
using Zaxis.Definitions;

using WebChart;
using WebChart.Design;

#endregion

namespace Zaxis.USD.Web
{
	/// <summary>
	/// Summary description for CEODashBoardStage.
	/// </summary>
	public class CEODashBoardStage : PageBase
	{

		#region Local Variables

		TechnicianBLL oBll = new TechnicianBLL();
		protected WebChart.ChartControl ChartLastWeek;
		protected WebChart.ChartControl ChartLastMonth;
		protected WebChart.ChartControl ChartYear;
		protected WebChart.ChartControl ChartToday;
		
		#endregion

		#region Page Load

		/// <summary>
		/// Pageload Event
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			bCheckUserID = true;
			// Put user code to initialize the page here
			PermissionID = "16";

			CreateColumnChart(ChartToday,"Status","Total","sp_USD_CEODashBoard_OrdStatTodayVSYestarday"); 
			CreateColumnChart(ChartLastWeek,"Status","Total","sp_USD_CEODashBoard_OrderStatusLastWeek"); 
			CreateColumnChart(ChartLastMonth,"Status","Total","sp_USD_CEODashBoard_OrderStatusLastMonth"); 
			CreateColumnChart(ChartYear,"Status","Total","sp_USD_CEODashBoard_OrderStatusCurYearVSLastYear"); 
		}

		#endregion

		#region CreateColumnChart

		/// <summary>
		/// Creates the Chart
		/// </summary>
		/// <param name="objChartControl"></param>
		/// <param name="strXvalue"></param>
		/// <param name="strYvalue"></param>
		/// <param name="strSpName"></param>
		private void CreateColumnChart(WebChart.ChartControl objChartControl,string strXvalue,string strYvalue,string strSpName) 
		{
			ColumnChart chart = new ColumnChart();// PieChart();
			chart.DataSource = oBll.GetData(strSpName).Tables[0].DefaultView;
			chart.DataXValueField = strXvalue;
			chart.DataYValueField = strYvalue;
			chart.DataLabels.Visible = true;
			chart.MaxColumnWidth = 15;
			chart.Fill.Color = Color.FromArgb(50, Color.Red);
			chart.Shadow.Visible = true;
			
			//chart.Legend = "Pri 0";

			//WebChart.Design.AutoFormatSchemes ofar = new AutoFormatSchemes();
			
			chart.DataLabels.ForeColor = System.Drawing.Color.Blue;
			chart.Shadow.Visible = true;
			chart.DataBind();
			
			objChartControl.Charts.Add(chart);
			objChartControl.RedrawChart();
			objChartControl.XAxisFont.StringFormat.FormatFlags = System.Drawing.StringFormatFlags.DirectionVertical;

			objChartControl.ShowYValues = true;
			objChartControl.ShowXValues = true;//YTitle = "Total";
		}

		#endregion

		#region Web Form Designer generated code
		
		/// <summary>
		/// 
		/// </summary>
		/// <param name="e"></param>
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Load += new System.EventHandler(this.Page_Load);

		}
	
		#endregion

	}
}
