using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace Zaxis.USD.Web
{
	/// <summary>
	/// Summary description for forgotpassword.
	/// </summary>
	public class forgotpassword : PageBase
	{
		protected System.Web.UI.HtmlControls.HtmlForm Form1;
		protected System.Web.UI.WebControls.AdRotator Adrotator3;
		protected System.Web.UI.WebControls.Label lblQuestion;
		protected System.Web.UI.WebControls.TextBox txtQuestion;
		protected System.Web.UI.WebControls.Label lblAnswer;
		protected System.Web.UI.WebControls.TextBox txtAnswer;
		protected System.Web.UI.WebControls.Label lblPassword;
		protected System.Web.UI.WebControls.Button btnGet;
		protected System.Web.UI.WebControls.Label lblLoginID;
		protected System.Web.UI.WebControls.TextBox txtLoginID;
		protected System.Web.UI.WebControls.AdRotator Adrotator4;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			btnGet.Attributes.Add("onclick", "return IsRequired()");
			// Put user code to initialize the page here
			
			//Banner checking
		
			}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.btnGet.Click += new System.EventHandler(this.btnGet_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void reset_Click(object sender, System.EventArgs e)
		{
			//UserID.Text = "";
		}


		private void btnGet_Click(object sender, System.EventArgs e)
		{
			string strWhere = "<Query><LoginID>"+txtLoginID.Text+"</LoginID><Question>"+txtQuestion.Text+"</Question><Answer>"+txtAnswer.Text+"</Answer></Query>";
			object strPassword = GetValue("ForgotPassword", strWhere);
			if(strPassword != null)
				if(strPassword.ToString().Trim().Length > 0)
					lblPassword.Text = "Your Password is " +  strPassword;
				else
					lblPassword.Text = "Wrong LoginID or Question and password";
			else
				lblPassword.Text = "Wrong LoginID or Question and password";


		}
	}
}
