
#region  Page Level Comments

/*******************************************************************************************
/*File Name	      :			CEODashBoardConOrdersStatus.cs
 *Project Name    :			USD 1.0
 *Object          :			Code Behind
 *Purpose         :			
 *Author          :			Kiran
 *Date            :			27-5-2006 
 *ModuleName      :			USD
 *This file is provided as part of Zaxis-USD project.
 *Copyright � 2004-07, Zaxis-USD Technologies, All rights reserved
 * ************************************ Revision History************************************
 *
 *  Date            Done by             Method             Change Description

*******************************************************************************************/

#endregion

#region NameSpaces

using System.Data;
using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

//Zaxis Namespaces
using Zaxis.Common;
using Zaxis.USD.BusinessLogic;
using Zaxis.Definitions;
using WebChart;
using WebChart.Design;


#endregion

namespace Zaxis.USD.Web
{
	/// <summary>
	/// Summary description for CEODashBoardConOrdersStatus.
	/// </summary>
	public class CEODashBoardConOrdersStatus : PageBase
	{

		#region Local Variables

		protected WebChart.ChartControl ChartDispatcher;
		protected WebChart.ChartControl ChartCurrentPie;
		protected WebChart.ChartControl ChartCurrentCol;
		protected WebChart.ChartControl ChartTechnician;
	
		TechnicianBLL oBll = new TechnicianBLL();
		Hashtable htParamValues = null;

		#endregion

		#region Page Load Event

		/// <summary>
		/// Page Load Event
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void Page_Load(object sender, System.EventArgs e)
		{

			bCheckUserID = true;
			// Put user code to initialize the page here
			PermissionID = "15";


			CreatePieChart(ChartCurrentPie,"Status","Total","sp_USD_CEODashBoard_Consolidated");
			CreateColumnChart(ChartCurrentCol,"Status","Total","sp_USD_CEODashBoard_Consolidated");
			htParamValues = new Hashtable();
			htParamValues.Add("@Xvalue",25);
			htParamValues.Add("@Yvalye",26); 
			CreatePieChart(ChartDispatcher,"Status","Total","sp_USD_CEODashBoard_ConsolidatedDisp",htParamValues);
			htParamValues = new Hashtable();
			htParamValues.Add("@Xvalue",26);
			htParamValues.Add("@Yvalye",27); 
			CreatePieChart(ChartTechnician,"Status","Total","sp_USD_CEODashBoard_ConsolidatedDisp",htParamValues);
			
		}
		#endregion

		#region Create Pie Chart

		/// <summary>
		/// 
		/// </summary>
		/// <param name="objChartControl"></param>
		/// <param name="strXvalue"></param>
		/// <param name="strYvalue"></param>
		/// <param name="strSpName"></param>

		private void CreatePieChart(WebChart.ChartControl objChartControl,string strXvalue,string strYvalue,string strSpName) 
		{
			
			PieChart chart = new PieChart();
			chart.DataSource = oBll.GetData(strSpName).Tables[0].DefaultView;
			chart.DataXValueField = strXvalue;
			chart.DataYValueField = strYvalue;
			chart.DataLabels.Visible = true;
			chart.DataLabels.ForeColor = System.Drawing.Color.Blue;
			chart.Shadow.Visible = true;
			chart.DataBind();
			chart.Explosion = 5;
			objChartControl.Charts.Add(chart);
			objChartControl.RedrawChart();
		}

		/// <summary>
		/// Pie Chart
		/// </summary>
		/// <param name="objChartControl"></param>
		/// <param name="strXvalue"></param>
		/// <param name="strYvalue"></param>
		/// <param name="strSpName"></param>
		/// <param name="htValues"></param>
		private void CreatePieChart(WebChart.ChartControl objChartControl,string strXvalue,string strYvalue,string strSpName,Hashtable htValues) 
		{
			
			PieChart chart = new PieChart();
			chart.DataSource = oBll.GetData(strSpName,htValues).Tables[0].DefaultView;
			chart.DataXValueField = strXvalue;
			chart.DataYValueField = strYvalue;
			chart.DataLabels.Visible = true;
			chart.DataLabels.ForeColor = System.Drawing.Color.Blue;
			chart.Shadow.Visible = true;
			chart.DataBind();
			chart.Explosion = 5;
			objChartControl.Charts.Add(chart);
			objChartControl.RedrawChart();
		}

		/// <summary>
		/// Creates the Column Chart
		/// </summary>
		/// <param name="objChartControl"></param>
		/// <param name="strXvalue"></param>
		/// <param name="strYvalue"></param>
		/// <param name="strSpName"></param>
		private void CreateColumnChart(WebChart.ChartControl objChartControl,string strXvalue,string strYvalue,string strSpName) 
		{
			ColumnChart chart = new ColumnChart();// PieChart();
			chart.DataSource = oBll.GetData(strSpName).Tables[0].DefaultView;
			chart.DataXValueField = strXvalue;
			chart.DataYValueField = strYvalue;
			chart.DataLabels.Visible = true;
			chart.DataLabels.ForeColor = System.Drawing.Color.Blue;
			chart.Shadow.Visible = true;
			chart.MaxColumnWidth = 15;
			chart.Fill.Color = Color.FromArgb(50, Color.Red);
			chart.DataBind();
			objChartControl.Charts.Add(chart);
			objChartControl.RedrawChart();
		}

		#endregion

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion
	}
}
