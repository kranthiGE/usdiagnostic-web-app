
#region  Page Level Comments

/*******************************************************************************************
/*File Name	      :			Account.cs
 *Project Name    :			USD 1.0
 *Object          :			Code Behind
 *Purpose         :			
 *Author          :			Padma A
 *Date            :			1-6-2006 
 *ModuleName      :			USD
 *This file is provided as part of Zaxis-USD project.
 *Copyright � 2004-07, Zaxis-USD Technologies, All rights reserved
 * ************************************ Revision History************************************
 *
 *  Date            Done by             Method             Change Description

*******************************************************************************************/

#endregion

#region NameSpaces

using System.Data;
using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.Text;

//Zaxis Namespaces
using Zaxis.USD.BusinessLogic;
using Zaxis.Definitions;

#endregion

namespace Zaxis.USD.Web
{
	/// <summary>
	/// Summary description for Order.
	/// </summary>
	public class Order : PageBase
	{

		#region Local Variables

		protected System.Web.UI.WebControls.Label lblFindFirstName;
		protected System.Web.UI.WebControls.TextBox txtFindFirstName;
		protected System.Web.UI.WebControls.Label lblFindAny;
		protected System.Web.UI.WebControls.TextBox txtFindAny;
		protected System.Web.UI.WebControls.Label lblFirstName;
		protected System.Web.UI.WebControls.TextBox txtFirstName;
		protected System.Web.UI.WebControls.Label lblLastName;
		protected System.Web.UI.WebControls.Button btnNew;
		protected System.Web.UI.WebControls.Button btnEdit;
		protected System.Web.UI.WebControls.Button btnSave;
		protected System.Web.UI.WebControls.Button btnCancel;
		protected System.Web.UI.WebControls.Label lblFindOrderNo;
		protected System.Web.UI.WebControls.TextBox txtFindOrderNo;
		protected System.Web.UI.WebControls.Label lblFindSex;
		protected System.Web.UI.WebControls.TextBox txtFindSex;
		protected System.Web.UI.WebControls.Label lblFindDOB;
		protected System.Web.UI.WebControls.TextBox txtFindDOB;
		protected System.Web.UI.WebControls.TextBox txtFindLastName;
		protected System.Web.UI.WebControls.Label lblFindLastname;
		protected System.Web.UI.WebControls.Label lblFindSSN;
		protected System.Web.UI.WebControls.TextBox txtFindSSN;
		protected System.Web.UI.WebControls.TextBox txtLastName;
		protected System.Web.UI.WebControls.Button btnGetSSN;
		protected System.Web.UI.WebControls.DataGrid dgOrder;
		protected System.Web.UI.WebControls.Button btnGetAny;
		protected System.Web.UI.WebControls.Label lblDOB;
		protected System.Web.UI.WebControls.TextBox txtDOB;
		protected System.Web.UI.WebControls.Label lblMedicareNo;
		protected System.Web.UI.WebControls.TextBox txtMedicareNo;
		protected System.Web.UI.WebControls.Label lblSSN;
		protected System.Web.UI.WebControls.TextBox txtSSN;
		protected System.Web.UI.WebControls.Label lblMedicaidNo;
		protected System.Web.UI.WebControls.TextBox txtMedicaidNo;
		protected System.Web.UI.WebControls.Label lblMiddleInitial;
		protected System.Web.UI.WebControls.TextBox txtMiddleInitial;
		protected System.Web.UI.WebControls.Label lblSex;
		protected System.Web.UI.WebControls.DropDownList ddlSex;
		protected System.Web.UI.WebControls.DropDownList ddlPatientSex;
		protected System.Web.UI.WebControls.TextBox Textbox1;
		protected System.Web.UI.WebControls.TextBox txtCityState;
		protected System.Web.UI.WebControls.Label lblRoom;
		protected System.Web.UI.WebControls.TextBox txtRoom;
		protected System.Web.UI.WebControls.Label lblContactPhone;
		protected System.Web.UI.WebControls.TextBox txtContactPhone;
		protected System.Web.UI.WebControls.Label lblCustomer;
		protected System.Web.UI.WebControls.TextBox txtCustomer;
		protected System.Web.UI.WebControls.Label lblReqPhysician;
		protected System.Web.UI.WebControls.TextBox txtReqPhysician;
		protected System.Web.UI.WebControls.Label lblUPIN;
		protected System.Web.UI.WebControls.TextBox txtUPIN;
		protected System.Web.UI.WebControls.Label lblOrderingNurse;
		protected System.Web.UI.WebControls.TextBox txtOrderingNurse;
		protected System.Web.UI.WebControls.Label lblPhoneNo;
		protected System.Web.UI.WebControls.TextBox txtPhoneNo;
		protected System.Web.UI.WebControls.Label lblFax;
		protected System.Web.UI.WebControls.TextBox txtFax;
		protected System.Web.UI.WebControls.Label lblDate;
		protected System.Web.UI.WebControls.TextBox txtDate;
		protected System.Web.UI.WebControls.Label lblSignature;
		protected System.Web.UI.WebControls.TextBox txtSignature;
		protected System.Web.UI.WebControls.Label lblCityState;
		protected System.Web.UI.WebControls.Label lblHeader;
		protected System.Web.UI.WebControls.Label lblInsuranceName;
		protected System.Web.UI.WebControls.TextBox txtInsuranceName;
		protected System.Web.UI.WebControls.Label lblInsurancePhone;
		protected System.Web.UI.WebControls.TextBox txtInsurancePhone;
		protected System.Web.UI.WebControls.Label lblInsuranceFax;
		protected System.Web.UI.WebControls.TextBox txtInsuranceFax;
		protected System.Web.UI.WebControls.Label lblInsuranceAuth;
		protected System.Web.UI.WebControls.TextBox txtInsuranceAuth;
		protected System.Web.UI.WebControls.Label lblStreetAddress;
		protected System.Web.UI.WebControls.TextBox txtStreetAddress;
		protected System.Web.UI.WebControls.Label lblinsuranceCityState;
		protected System.Web.UI.WebControls.TextBox txtInsuranceCity;
		protected System.Web.UI.WebControls.TextBox txtDiagnosis;
		protected System.Web.UI.WebControls.Label Label1;
		protected System.Web.UI.WebControls.Label lblProcFN;
		protected System.Web.UI.WebControls.Button btDelete;
		protected System.Web.UI.WebControls.TextBox txtOrderNo;
		protected Microsoft.Web.UI.WebControls.TabStrip tsOrder;
		protected Microsoft.Web.UI.WebControls.MultiPage mpOrder;
		protected Evolve.Web.UI.Toolbar.Toolbar toolbarUsrAcc;

		protected System.Web.UI.WebControls.PlaceHolder phProcedure;
		protected System.Web.UI.HtmlControls.HtmlInputHidden hdnPatientID;
		protected System.Web.UI.HtmlControls.HtmlInputHidden hdnPatientContactID;
		protected System.Web.UI.HtmlControls.HtmlInputHidden hdnOrderContactID;
		protected System.Web.UI.HtmlControls.HtmlInputHidden hdnPatientInsuranceID;
		protected System.Web.UI.HtmlControls.HtmlInputHidden hdnOrderID;

		StringBuilder sbOrder = new StringBuilder();
		#endregion

		#region Page Load

		/// <summary>
		/// Page Load Event
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			//ViewState["RecordsCount"] = dsAccountInfo.Tables[0].Rows.Count;
			bCheckUserID = true;
			OrderRender();
			IsEnabled(false);
			if(!IsPostBack)
			{
				GridBind(dgOrder, "OrderGridBind", "");
			}
			ViewState["Order"] = GetDataset("OrderStructure", "");
			toolbarUsrAcc.Items["tbtnSave"].Attributes.Add("onclick","return IsRequired()");
		}

		
		#endregion

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.toolbarUsrAcc.ItemPostBack += new Evolve.Web.UI.Toolbar.ItemEventHandler(this.toolbarUsrAcc_ItemPostBack);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		#region Grid Events

		/// <summary>
		/// Grid Row Change Event
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		public void dgOrder_select(object sender,System.EventArgs e)
		{
			PrimaryKey = dgOrder.SelectedItem.Cells[0].Text;
			DataSet dsOrder = GetDataset("GetOrder", PrimaryKey);
			dsOrder.Tables[0].TableName = "Order";
			dsOrder.Tables[1].TableName = "Patient";
			dsOrder.Tables[2].TableName = "Insurance";
			dsOrder.Tables[3].TableName = "Procedures";
			AssignData(dsOrder);
			EnableControls(true, true, true, false, false, toolbarUsrAcc);

		}

		#endregion

		#region Assign Data

		/// <summary>
		/// Binds the Data to Screen Controls
		/// </summary>
		/// <param name="dsOrder"></param>
		private void AssignData(DataSet dsOrder)
		{
			hdnPatientID.Value = dsOrder.Tables["Patient"].Rows[0]["PatientID"].ToString();
			txtFirstName.Text = dsOrder.Tables["Patient"].Rows[0]["FirstName"].ToString();
			txtLastName.Text = dsOrder.Tables["Patient"].Rows[0]["LastName"].ToString();
			txtDOB.Text = dsOrder.Tables["Patient"].Rows[0]["DOB"].ToString();
			txtMedicareNo.Text = dsOrder.Tables["Patient"].Rows[0]["MedicareNo"].ToString();
			txtSSN.Text = dsOrder.Tables["Patient"].Rows[0]["SSN"].ToString();
			txtMedicaidNo.Text = dsOrder.Tables["Patient"].Rows[0]["MedicaidNO"].ToString();
			txtMiddleInitial.Text = dsOrder.Tables["Patient"].Rows[0]["MiddleName"].ToString();
			ddlPatientSex.SelectedValue = dsOrder.Tables["Patient"].Rows[0]["Sex"].ToString().Equals(null) ? "0" : "1";
			txtCityState.Text = dsOrder.Tables["Patient"].Rows[0]["Address1"].ToString();;
			txtRoom.Text = dsOrder.Tables["Patient"].Rows[0]["RoomNo"].ToString();
			txtContactPhone.Text = dsOrder.Tables["Patient"].Rows[0]["HomePhone"].ToString();
			hdnPatientContactID.Value = dsOrder.Tables["Patient"].Rows[0]["ContactID"].ToString();
			hdnPatientInsuranceID.Value = dsOrder.Tables["Patient"].Rows[0]["InsuranceContactID"].ToString();
 
			// Assigning Order Data
			hdnOrderID.Value = dsOrder.Tables["Order"].Rows[0]["SourceContactID"].ToString();
			hdnOrderContactID.Value = dsOrder.Tables["Order"].Rows[0]["OrderID"].ToString();
			txtOrderNo.Text = dsOrder.Tables["Order"].Rows[0]["OrderNo"].ToString();;
			txtCustomer.Text = dsOrder.Tables["Order"].Rows[0]["FirstName"].ToString() + " " + dsOrder.Tables["Order"].Rows[0]["LastName"].ToString() + " " + dsOrder.Tables["Order"].Rows[0]["MiddleName"].ToString();
			txtReqPhysician.Text = dsOrder.Tables["Order"].Rows[0]["Physician"].ToString();
			txtUPIN.Text = dsOrder.Tables["Order"].Rows[0]["Zip"].ToString();
			txtOrderingNurse.Text =  dsOrder.Tables["Order"].Rows[0]["OrderingNurse"].ToString();
			txtPhoneNo.Text =  dsOrder.Tables["Order"].Rows[0]["HomePhone"].ToString();
			txtFax.Text =  dsOrder.Tables["Order"].Rows[0]["Fax"].ToString();
			txtDate.Text =  dsOrder.Tables["Order"].Rows[0]["OrderDate"].ToString();
			txtSignature.Text = dsOrder.Tables["Order"].Rows[0]["Signature"].ToString();
			txtDiagnosis.Text = dsOrder.Tables["Order"].Rows[0]["Diagnosis"].ToString();
			
			txtInsuranceName.Text =  dsOrder.Tables["Insurance"].Rows[0]["FirstName"].ToString() + " " + dsOrder.Tables["Insurance"].Rows[0]["LastName"].ToString() + " " + dsOrder.Tables["Insurance"].Rows[0]["MiddleName"].ToString();
			txtInsurancePhone.Text =  dsOrder.Tables["Insurance"].Rows[0]["HomePhone"].ToString();
			txtInsuranceFax.Text =  dsOrder.Tables["Insurance"].Rows[0]["Fax"].ToString();
			txtInsuranceAuth.Text =  dsOrder.Tables["Insurance"].Rows[0]["Zip"].ToString();
			txtStreetAddress.Text =  dsOrder.Tables["Insurance"].Rows[0]["Address1"].ToString();
			txtInsuranceCity.Text =  dsOrder.Tables["Insurance"].Rows[0]["City"].ToString();

			int iRowCount = dsOrder.Tables["Procedures"].Rows.Count;
			ClearCehckboxs(phProcedure);
			for(int iCount =0; iCount < iRowCount; iCount++)
			{
				AssignCheckBoxes(phProcedure, dsOrder.Tables["Procedures"].Rows[iCount]["ProcedureID"].ToString().Trim());
			}
		}

		#endregion

		#region Dynamic Rendering

		/// <summary>
		/// creates Dynamic Order Rendering
		/// </summary>
		private void OrderRender()
		{
			HtmlTableCell cell;
			HtmlTable table = Table.GetTable("100%");
			HtmlTableRow row = Table.GetRow();
			// 2% Empty cell
			cell = Table.GetColumn("2%");
			cell.InnerHtml = "&nbsp;";
			row.Cells.Add(cell);

			// 96% Content Area
			cell = Table.GetColumn("96%");
			cell.VAlign = "Top";
	
			HtmlTable contenttable = Table.GetTable("100%");
			
			HtmlTableRow contentrow = Table.GetRow();
			HtmlTableCell emptycell1 = Table.GetColumn("100%");
			emptycell1.ColSpan = 4;
			emptycell1.InnerHtml = "&nbsp;";
			contentrow.Cells.Add(emptycell1);
			contenttable.Rows.Add(contentrow);
			
			contentrow = Table.GetRow();
			emptycell1 = Table.GetColumn("10%");
			emptycell1.InnerHtml = "&nbsp;";
			HtmlTableCell firstcell = Table.GetColumn("35%");
			firstcell.VAlign = "Top";
			HtmlTableCell secondcell = Table.GetColumn("10%");
			secondcell.InnerHtml = "&nbsp;";
			HtmlTableCell lastcell = Table.GetColumn("35%");
			lastcell.VAlign = "Top";

			HtmlTableCell emptycell2 = Table.GetColumn("10%");
			emptycell2.InnerHtml = "&nbsp;";
			// calling GetProcedures method
			GetProcedures(firstcell, lastcell);
			// Adding cells to row
			contentrow.Cells.Add(emptycell1);
			contentrow.Cells.Add(firstcell);
			contentrow.Cells.Add(secondcell);
			contentrow.Cells.Add(lastcell);
			contentrow.Cells.Add(emptycell2);
			// Adding Row to Table
			contenttable.Rows.Add(contentrow);
			cell.Controls.Add(contenttable);
			row.Cells.Add(cell);

			// 2% Empty cell
			cell = Table.GetColumn("2%");
			cell.InnerHtml = "&nbsp;";
			row.Cells.Add(cell);

			table.Rows.Add(row);
			//phProcedure.Controls.Add(table);
			phProcedure.Controls.Add(contenttable);

			//Distroying the objects
			cell.Dispose();
			row.Dispose();
			table.Dispose();

		}

		/// <summary>
		/// Dynamically Creates the Procedures and Procedures types from the database
		/// </summary>
		/// <param name="firstrow"></param>
		/// <param name="lastrow"></param>
		private void GetProcedures(HtmlTableCell firstrow, HtmlTableCell lastrow)
		{

			DataSet ds = GetDataset("ProcedureGridBind", "");
			int iRowCount = ds.Tables[0].Rows.Count;
			string strProcedureType = ds.Tables[0].Rows[0]["Decode"].ToString();
			CheckBox chkProcedure = null;

			firstrow.Controls.Add(Table.GetEmptyTable(strProcedureType));

			HtmlTable tblProc = Table.GetTable("100%");
			HtmlTableRow tblRow = Table.GetRow();
			HtmlTableCell tblCell = Table.GetColumn("100%");

			// for adding first columna values
			chkProcedure = new CheckBox();
			chkProcedure.ID = ds.Tables[0].Rows[0]["ProcedureID"].ToString();
			chkProcedure.Text = ds.Tables[0].Rows[0]["Name"].ToString();
			chkProcedure.CssClass = "style5";
			tblCell.Controls.Add(chkProcedure);
			tblRow.Controls.Add(tblCell);
			tblProc.Rows.Add(tblRow);
			for(int iCount = 1; iCount < iRowCount; iCount++)
			{
				tblRow = Table.GetRow();
				tblCell = Table.GetColumn("100%");
				
				chkProcedure = new CheckBox();
				chkProcedure.ID = ds.Tables[0].Rows[iCount]["ProcedureID"].ToString();
				chkProcedure.Text = ds.Tables[0].Rows[iCount]["Name"].ToString();
				chkProcedure.CssClass = "style5";
				if(strProcedureType.Equals(ds.Tables[0].Rows[iCount]["Decode"].ToString()))
				{
					tblCell.Controls.Add(chkProcedure);
					tblRow.Controls.Add(tblCell);
					tblProc.Rows.Add(tblRow);
				}
				else
				{
					strProcedureType = ds.Tables[0].Rows[iCount]["Decode"].ToString();
					if(iCount >= (iRowCount/2))
					{
						lastrow.Controls.Add(tblProc);
						lastrow.Controls.Add(Table.GetEmptyTable());
						lastrow.Controls.Add(Table.GetEmptyTable(strProcedureType));
					}
					else
					{
						firstrow.Controls.Add(tblProc);
						if(strProcedureType == "X-RAY - Skeletal System")
							lastrow.Controls.Add(Table.GetEmptyTable(strProcedureType));

						else
						{
							firstrow.Controls.Add(Table.GetEmptyTable());
							firstrow.Controls.Add(Table.GetEmptyTable(strProcedureType));
						}
					}
					// Taking the instance of New Table
					tblProc = Table.GetTable("100%");

					tblCell.Controls.Add(chkProcedure);
					tblRow.Controls.Add(tblCell);
					tblProc.Rows.Add(tblRow);
					
				}
				lastrow.Controls.Add(tblProc);
			}
		}

		#endregion

		#region Tool bar Events

		/// <summary>
		/// Tool Bar Events
		/// </summary>
		/// <param name="item"></param>
		private void toolbarUsrAcc_ItemPostBack(Evolve.Web.UI.Toolbar.ToolbarItem item)
		{
			//BusinessData data = new BusinessData();
			//TechnicianBLL bll = new TechnicianBLL();
			switch(item.ItemId.ToString())
			{
				case "tbtnNew":
					ClearControls();
					IsEnabled(true);
					EnableControls(false, false, true, true, true, toolbarUsrAcc); 	
					PageMode =	"New";

					//data.MethodName = "Create";
					//bll.Save(data);
					break;
				case "tbtnEdit":
					//data.MethodName = "Update";
					//bll.Save(data);
					PageMode  = "Edit";
					EnableControls(true, false, true, true, true, toolbarUsrAcc);
					IsEnabled(true);
					break;
				case "tbtnDelete":

					IsEnabled(false);
					try
					{
//						//Updating Active Status of User Contact information
//						string strUpdUserInfo = "update Contact set isActive='0' where contactid = '"+ dgAccount.SelectedItem.Cells[0].Text +"'";
//						//PageBase.ExecuteNonQuery(strUpdUserInfo);
//						// Updating Active Status of User Inforamtion
//						strUpdUserInfo = "update UserInfo set isActive='0' where UserID = '"+ dgAccount.SelectedItem.Cells[0].Text +"'";
//						//PageBase.ExecuteNonQuery(strUpdUserInfo);
//						// Updating Active Status of User - Role information
//						strUpdUserInfo = "Update User_Role set isActive='0' where UserId = '"+ dgAccount.SelectedItem.Cells[0].Text +"'";
//						//PageBase.ExecuteNonQuery(strUpdUserInfo);
//						GridBind(dgAccount, "AccountGridBind", "");
//						ALertMessage(txtLoginID.Text + " Record Deleted Successfully","focus");
//						ClearControls();
//						EnableControls(true, false, false, false, false, toolbarUsrAcc);
//						dgAccount.SelectedIndex = -1;
					}
					catch(Exception ex)
					{
						ALertMessage("Error :" + ex.Message,"focus");
						EnableControls(true, true, true, false, false, toolbarUsrAcc);
				
					}
					//data.MethodName = "Delete";
					//bll.Save(data);
					break;
				case "tbtnCancel":
					ClearControls();
					IsEnabled(false);
					EnableControls(true, false, false, false, false, toolbarUsrAcc); 	
					break;

				case "tbtnSave":

					sbOrder = new StringBuilder();
					GetCheckBox(phProcedure);

					string strProcedures = sbOrder.ToString();
					if(strProcedures.Length < 1)
					{
						ALertMessage("Please Select Atleast One Procedure", "txtFirstName");
						IsEnabled(true);
						EnableControls(false, false, true, true, true, toolbarUsrAcc); 	
					}
					else
					{
						Save();
						ClearControls();
						IsEnabled(false);
						EnableControls(true, false, false, false, false, toolbarUsrAcc); 	
					}
					break;

			}
		}
		

		#endregion

		#region ClearControls method

		/// <summary>
		/// Clear the Contrls Data
		/// </summary>
		private void ClearControls()
		{
//			txtFindFirstName.Text = string.Empty;
//			txtFindAny.Text = string.Empty;
//			txtFirstName.Text = string.Empty;
//			txtFindOrderNo.Text = string.Empty;
//			txtFindSex.Text = string.Empty;
//			txtFindDOB.Text = string.Empty;
//			txtFindLastName.Text = string.Empty;
//			txtFindSSN.Text = string.Empty;
			txtFirstName.Text = string.Empty;
			txtLastName.Text = string.Empty;
			txtDOB.Text = string.Empty;
			txtMedicareNo.Text = string.Empty;
			txtSSN.Text = string.Empty;
			txtMedicaidNo.Text = string.Empty;
			txtMiddleInitial.Text = string.Empty;
			ddlPatientSex.SelectedValue = "1";
			txtCityState.Text = string.Empty;
			txtRoom.Text = string.Empty;
			txtContactPhone.Text = string.Empty;
			txtOrderNo.Text = string.Empty;
			txtCustomer.Text = string.Empty;
			txtReqPhysician.Text = string.Empty;
			txtUPIN.Text = string.Empty;
			txtOrderingNurse.Text = string.Empty;
			txtPhoneNo.Text = string.Empty;
			txtFax.Text = string.Empty;
			txtDate.Text = string.Empty;
			txtSignature.Text = string.Empty;
			txtInsuranceName.Text = string.Empty;
			txtInsurancePhone.Text = string.Empty;
			txtInsuranceFax.Text = string.Empty;
			txtInsuranceAuth.Text = string.Empty;
			txtStreetAddress.Text = string.Empty;
			txtInsuranceCity.Text = string.Empty;
			txtDiagnosis.Text = string.Empty;
			hdnOrderContactID.Value = string.Empty;
			hdnOrderID.Value = string.Empty;
			hdnPatientContactID.Value = string.Empty;
			hdnPatientID.Value = string.Empty;
			hdnPatientInsuranceID.Value = string.Empty;
		}


		#endregion

		#region AlertMessage

		private void ALertMessage(string text, string focus)
		{
			string strScript = "<script language=javascript>";
			if(!text.Equals(""))
				strScript += "alert('"+ text +"');";
			if(focus == "")
				strScript += "document.getElementById('txtFirstName').focus();";
			strScript += "</script>";
			RegisterStartupScript("MM", strScript);
		}

		#endregion

		#region Save Button Click Event

		/// <summary>
		/// Saves the Datainto Database by calling Business Logic Layer
		/// </summary>
		private void Save()
		{
			Response response;
			BusinessData data = new BusinessData();
			OrderBLL order = new OrderBLL();
			switch(PageMode)
			{
				case "New":


					DataSet dsStructure = (DataSet) ViewState["Order"];

					AssignOrderData(dsStructure);		

					data.MethodName = "Create";
					data.NewEntity = dsStructure;
					response = order.Save(data);
//					string strGUID = Guid.NewGuid().ToString();
//					//inserting User Contact information
//					string strInsUserInfo = "insert into Contact(contactid, FirstName, MiddleName, LastName, isActive) values ('" + strGUID + "','"+ txtFirstName.Text +"', '"+ txtMiddleName.Text +"', '"+ txtLastName.Text +"',1)";
//					PageBase.ExecuteNonQuery(strInsUserInfo);
//					// Inserting User Inforamtion
//					strInsUserInfo = "insert into UserInfo(UserId, LoginID, Password, Question, Answer, Technition, ModifyRecord, ContactID,isActive) values('" + strGUID + "', '"+ txtLoginID.Text +"', '"+ txtPassword.Text +"', '"+ txtSecretQuestion.Text +"', '"+ txtAnswer.Text +"', '" + GetTechnicianSelectedValues() + "', " + ddlModifyRec.SelectedValue + ", '" + strGUID + "','1')";
//					PageBase.ExecuteNonQuery(strInsUserInfo);
//					// Inserting User - Role information
//					strInsUserInfo = BuildUserRoleInserts(strGUID);
//					PageBase.ExecuteNonQuery(strInsUserInfo);
//					GridBind(dgAccount, "AccountGridBind", "");
					ClearControls();
					IsEnabled(true);
					//ALertMessage(txtLoginID.Text + " Record Saved Successfully","");
					break;
				case "Edit":
//					data.MethodName = "Update";
//					response = acount.Save(data);
//					//Updating User Contact information
//					string strUpdUserInfo = "update Contact set FirstName = '"+ txtFirstName.Text +"', MiddleName = '"+ txtMiddleName.Text +"', LastName = '"+ txtLastName.Text +"'  where contactid = '"+ dgAccount.SelectedItem.Cells[0].Text +"'";
//					PageBase.ExecuteNonQuery(strUpdUserInfo);
//					// Updating User Inforamtion
//					strUpdUserInfo = "update UserInfo set LoginID = '"+ txtLoginID.Text +"', Password = '"+ txtPassword.Text +"', Question = '"+ txtSecretQuestion.Text +"', Answer = '"+ txtAnswer.Text +"' , Technition = '" + GetTechnicianSelectedValues() + "', ModifyRecord = " + ddlModifyRec.SelectedValue + "  where UserID = '"+ dgAccount.SelectedItem.Cells[0].Text +"'";
//					PageBase.ExecuteNonQuery(strUpdUserInfo);
//					// Updating User - Role information
//					strInsUserInfo = BuildUserRoleUpdate(strUpdUserInfo);
//					PageBase.ExecuteNonQuery(strUpdUserInfo);
//					GridBind(dgAccount, "AccountGridBind", "");
					ClearControls();
					IsEnabled(true);
					//ALertMessage(txtLoginID.Text + " Record Saved Successfully","");
					break;
				case "Delete":
					data.MethodName = "Delete";
					response = order.Save(data);
					break;
			}
		}
		#endregion
		
		#region Assign Data

		/// <summary>
		/// Assigns screen date to Order and Order Cantact table
		/// </summary>
		/// <param name="dsOrder"></param>
		private void AssignOrderData(DataSet dsOrder)
		{
			// For Storing Order Contact
			DataRow dr;
			DataTable dtOrderContact = dsOrder.Tables[1].Clone();
			dtOrderContact.TableName = "OrderContact";
			dr = dtOrderContact.NewRow();
			dr["ContactID"] = hdnOrderContactID.Value;
			dr["FirstName"] = txtCustomer.Text;
			dr["LastName"] = "";
			dr["MiddleName"] = "";
			dr["Zip"] = txtUPIN.Text;
			dr["HomePhone"] = txtPhoneNo.Text;
			dr["Fax"] = txtFax.Text;
			dtOrderContact.Rows.Add(dr);
			dsOrder.Tables.Add(dtOrderContact);

			dr = dsOrder.Tables[0].NewRow();
			dsOrder.Tables[0].TableName = "Order";
			dr["OrderID"] = hdnOrderID.Value;
			dr["OrderNo"] = txtOrderNo.Text;
			dr["OrderDate"] = DateTime.Now;
			dr["Physician"] = txtReqPhysician.Text;
			dr["OrderingNurse"] = txtOrderingNurse.Text;
			dr["SourceContactID"] = 0;
			dr["ContactTypeID"] = 0;
			dr["Signature"] = txtSignature.Text;
			dr["Diagnosis"] = txtDiagnosis.Text;
			dr["CompanyID"] = 1;
			dr["BranchID"] = 1;
			dr["IsActive"] = 1;

			dsOrder.Tables[0].TableName = "Orders";
			dsOrder.Tables[0].Rows.Clear();
			dsOrder.Tables[0].Rows.Add(dr);
			AssignPatientData(dsOrder);
			AssignProcedures(dsOrder);
		}

		/// <summary>
		/// Assigns the Patient and Patinet Contact Information to data set
		/// from screen which were entered by user
		/// </summary>
		/// <param name="dsOrder"></param>
		private void AssignPatientData(DataSet dsOrder)
		{
			// For Storing Patient Contact
			DataRow dr;
			DataTable dtPatientContact = dsOrder.Tables[1].Clone();
			dtPatientContact.TableName = "PatientContact";
			dr = dtPatientContact.NewRow();
			dr["ContactID"] = hdnPatientContactID.Value;
			dr["FirstName"] = txtFirstName.Text;
			dr["LastName"] = txtLastName.Text;
			dr["MiddleName"] = txtMiddleInitial.Text;
			dr["Sex"] = ddlPatientSex.SelectedValue;
			dr["Address1"] = txtCityState.Text;
			dr["HomePhone"] = txtContactPhone.Text;
			dr["Fax"] = txtFax.Text;
			dtPatientContact.Rows.Add(dr);
			dsOrder.Tables.Add(dtPatientContact);

			// For Storing Patient Insurance Contact
			DataTable dtPatientInsurance = dsOrder.Tables[1].Clone();
			dtPatientInsurance.TableName = "PatientInsuranceContact";
			DataRow drPI = dtPatientInsurance.NewRow();
			drPI["ContactID"] = hdnPatientInsuranceID.Value;
			drPI["FirstName"] = txtInsuranceName.Text;
			drPI["HomePhone"] = txtInsurancePhone.Text;
			drPI["Address1"] = txtStreetAddress.Text;
			drPI["City"] = txtInsuranceCity.Text;
			drPI["Fax"] = txtInsuranceFax.Text;
			drPI["Zip"] = txtInsuranceAuth.Text; 
			dtPatientInsurance.Rows.Add(drPI);
			dsOrder.Tables.Add(dtPatientInsurance);


			// Assigning Patient Information
			DataRow drP = dsOrder.Tables[2].NewRow();
			dsOrder.Tables[2].TableName = "Patient";
			drP["PatientID"] = hdnPatientID.Value;
			drP["SSN"] = txtFirstName.Text;
			drP["DOB"] = txtDate.Text;
			drP["MedicareNo"] = txtMiddleInitial.Text;
			drP["MedicaidNO"] = txtCityState.Text;
			drP["RoomNo"] = txtContactPhone.Text;
			drP["PatientInsuranceCode"] = txtContactPhone.Text;
			drP["CompanyID"] = 1;
			drP["BranchID"] = 1;
			drP["IsActive"] = 1;

			dsOrder.Tables[2].Rows.Clear();
			dsOrder.Tables[2].Rows.Add(drP);

		}


		/// <summary>
		/// Assigns the Patient Procedure Information to data set
		/// from the screen 
		/// </summary>
		/// <param name="dsOrder"></param>
		private void AssignProcedures(DataSet dsOrder)
		{
			string[] strProcedureIds = sbOrder.ToString().Substring(1).Split(':');
			int iProcCount = strProcedureIds.Length;
			DataRow drProcedure;
			dsOrder.Tables[3].Rows.Clear();
			dsOrder.Tables[3].TableName = "Procedure";
			for(int iCount = 0; iCount < iProcCount; iCount ++)
			{
				drProcedure = dsOrder.Tables[3].NewRow();
				drProcedure["ProcedureID"] = strProcedureIds[iCount];
				//Uncomment the below line
				//drProcedure["TechnicianID"] = Session["UserID"].ToString();
				drProcedure["TechnicianID"] = 1;
				drProcedure["DueDate"] = DateTime.Today;
				drProcedure["PriorityID"] = 26;
				drProcedure["Comments"] = "";
				drProcedure["StatusID"] = Status.Open;
				drProcedure["OrderTyp"] = OrderType.Order;
				drProcedure["IsActive"] = 1;
				dsOrder.Tables[3].Rows.Add(drProcedure);
			}
		}
		#endregion

		#region IsEnabled method
		/// <summary>
		/// Enable or Disable the Ctntorls based on the requirement
		/// </summary>
		/// <param name="bEnable">True/False</param>
		private void IsEnabled(bool bEnable)
		{
			txtFirstName.Enabled = bEnable;
			txtLastName.Enabled = bEnable;
			txtDOB.Enabled = bEnable;
			txtMedicareNo.Enabled = bEnable;
			txtSSN.Enabled = bEnable;
			txtMedicaidNo.Enabled = bEnable;
			txtMiddleInitial.Enabled = bEnable;
			ddlPatientSex.Enabled = bEnable;
			txtCityState.Enabled = bEnable;
			txtRoom.Enabled = bEnable;
			txtContactPhone.Enabled = bEnable;
			txtOrderNo.Enabled =  bEnable;
			txtCustomer.Enabled = bEnable;
			txtReqPhysician.Enabled = bEnable;
			txtUPIN.Enabled = bEnable;
			txtOrderingNurse.Enabled = bEnable;
			txtPhoneNo.Enabled = bEnable;
			txtFax.Enabled = bEnable;
			txtDate.Enabled = bEnable;
			txtSignature.Enabled = bEnable;
			txtInsuranceName.Enabled = bEnable;
			txtInsurancePhone.Enabled = bEnable;
			txtInsuranceFax.Enabled = bEnable;
			txtInsuranceAuth.Enabled = bEnable;
			txtStreetAddress.Enabled = bEnable;
			txtInsuranceCity.Enabled = bEnable;
			tsOrder.Items[1].Enabled = bEnable;
			txtDiagnosis.Enabled =bEnable;
			EnableCheckBox(phProcedure, bEnable);
		}


		#endregion

		#region Enable/Disable Checkbox

		/// <summary>
		/// Rescursive function for finding the Selected Check boxes.
		/// </summary>
		/// <param name="p_Control">Control</param>
		private void EnableCheckBox(Control p_Control, bool bEnable)
		{
			string strControls = string.Empty;
			CheckBox chkProcedure;
			if(p_Control.GetType().FullName.Equals("System.Web.UI.WebControls.CheckBox"))
			{
				chkProcedure = (CheckBox)p_Control;
				chkProcedure.Enabled = bEnable;
			}

			foreach (Control control in p_Control.Controls)
			{
				EnableCheckBox(control, bEnable);
			}
		}
		#endregion

		#region GetCheckbox

		/// <summary>
		/// Rescursive function for finding the Selected Check boxes.
		/// </summary>
		/// <param name="p_Control">Control</param>
		private void GetCheckBox(Control p_Control )
		{
			CheckBox chkProcedure;
			if(p_Control.GetType().FullName.Equals("System.Web.UI.WebControls.CheckBox"))
			{
				chkProcedure = (CheckBox)p_Control;
				if(chkProcedure.Checked)
				{
//					DataRow drOrder = dsOrder.Tables["Procedure"].NewRow();
//					drOrder["ProcedureID"] = chkProcedure.ID;
//					drOrder["PatientID"] = "";
//					drOrder["OrderID"] = "";
//					drOrder["SatusID"] = 1;

					sbOrder.Append(":" + chkProcedure.ID);
					//strControls += "INSERT INTO Patient_Procedure (PatientID, ProcedureID, OrderID, DueDate, StatusID, OrderType, IsActive) values ('" + strPatientID + "', '" + chkProcedure.ID + "', '" + strOrderID + "', '" + DateTime.Now.ToString() + "', " + Status.Open + ", 0, 1);";
				}
			}

			foreach (Control control in p_Control.Controls)
			{
				GetCheckBox(control);
			}
		}
		#endregion

		#region Assign Checkboxs Data


		private void ClearCehckboxs(Control p_Control)
		{
			CheckBox chkProcedure;
			if(p_Control.GetType().FullName.Equals("System.Web.UI.WebControls.CheckBox"))
			{
				chkProcedure = (CheckBox)p_Control;
				chkProcedure.Checked = false;
			}

			foreach (Control control in p_Control.Controls)
			{
				ClearCehckboxs(control);
			}
		}

		/// <summary>
		/// Rescursive function for finding the Selected Check boxes.
		/// </summary>
		/// <param name="p_Control">Control</param>
		private void AssignCheckBoxes(Control p_Control, string procedureid)
		{
			CheckBox chkProcedure;
			if(p_Control.GetType().FullName.Equals("System.Web.UI.WebControls.CheckBox"))
			{
				chkProcedure = (CheckBox)p_Control;
				if(chkProcedure.ID.Equals(procedureid))
				{
					chkProcedure.Checked = true;
					return;
				}
			}

			foreach (Control control in p_Control.Controls)
			{
				AssignCheckBoxes(control, procedureid);
			}
		}
		#endregion

	}
}
