using System;
using System.Data;
using System.Web.UI;
using System.Web;
using System.Web.UI.WebControls;

namespace Zaxis.USD.Web
{
	/// <summary>
	/// Summary description for GroupGrid.
	/// </summary>
	public class GroupGrid
	{
		public GroupGrid()
		{
			//
			// TODO: Add constructor logic here
			//
		}
/// <summary>
/// Gets the Grid in Master Detail Format
/// </summary>
/// <param name="dgMonitor">Target DataGrid</param>
/// <param name="ColumnIndex">Index of the Master Column</param>
		public void GroupColumn(DataGrid dgMonitor,int ColumnIndex)
		{
			int ItemIndex= 0;
			foreach(DataGridItem dgItem in dgMonitor.Items)
			{
				if(dgItem.ItemIndex > 0)
				{          
					//if current cells text is the same as the cell above it
					//make it invisible and increase the row span by 1 of the last
					//visible cell in that column.
					dgMonitor.Items[ItemIndex].Cells[0].Font.Bold = true;	//for setting the Master details in bold
					dgMonitor.Items[ItemIndex].Cells[0].Style.Add("cursor","hand");
					if(dgItem.Cells[ColumnIndex].Text == dgMonitor.Items[dgItem.ItemIndex-1].Cells[ColumnIndex].Text)
					{
						dgItem.Cells[ColumnIndex].Visible = false;
						dgMonitor.Items[ItemIndex].Cells[ColumnIndex].RowSpan = dgMonitor.Items[ItemIndex].Cells[ColumnIndex].RowSpan + 1;
						dgMonitor.Items[ItemIndex].Cells[ColumnIndex].VerticalAlign = VerticalAlign.Top;
					}
					else if(dgMonitor.Items[dgItem.ItemIndex-1].Cells[ColumnIndex].Visible == true)
					{
						ItemIndex = dgItem.ItemIndex;
					}
					else
					{
						dgMonitor.Items[ItemIndex].Cells[ColumnIndex].RowSpan = dgMonitor.Items[ItemIndex].Cells[ColumnIndex].RowSpan + 1;
						dgMonitor.Items[ItemIndex].Cells[ColumnIndex].VerticalAlign = VerticalAlign.Top;
						ItemIndex = dgItem.ItemIndex;
					}
				}
			}
			
			//setting the last row
			int RowSpan = 1;
			int itemCount = dgMonitor.Items.Count-1;
			for(int iCount = dgMonitor.Items.Count-1; iCount > 0; iCount-- )
			{
				if(dgMonitor.Items[iCount].Cells[0].Text != dgMonitor.Items[iCount-1].Cells[0].Text )
				{
					dgMonitor.Items[iCount].Cells[0].Visible  = true;
					dgMonitor.Items[iCount].Cells[0].Font.Bold = true;
					dgMonitor.Items[ItemIndex].Cells[0].Style.Add("cursor","hand");
					break;
				}
				else
				{
					RowSpan++;
					itemCount--;
				}
			}
			dgMonitor.Items[itemCount].Cells[0].RowSpan  = RowSpan;
		}

	}
}
