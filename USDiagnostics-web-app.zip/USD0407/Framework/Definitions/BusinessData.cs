#region Page Level Comments

/*File Name		: BusinessData
* Project		: Zaxis-USD
* Object		: BusinessData
* Purpose		: 
* Author		: N.Desayya
* Date			: 12-5-2006
* Module Name	: Common
* This file is provided as part of the Zaxis-USD project
* Copyright � 2004-06, Zaxis Techonologies Private Limited, All rights reserved
* *********************** Revision History ****************************************************************
*	Date            Done by             Change Description
* ***********************************************************************************************************
*/

#endregion

#region Namespace Declaration

// System Namesapaces
using System;
using System.Collections;
using System.Data;

#endregion

namespace Zaxis.Definitions
{

	/// <summary>
	/// This object carries the Entity New and Old Data, Transaction Object and Global Values 
	/// </summary>
	[Serializable()]
	public class BusinessData
	{

		#region Constructor

		/// <summary>
		/// Empty Constructor
		/// </summary>
		
		public BusinessData()
		{
		}

		#endregion
		
		#region Private variables

		private DataSet newDataSet;
		private DataSet oldDataSet;

		private Hashtable hashTable;
		/*TODO: Instead of Hashtable properties have been defined in the region below. Please add the private		variables to the properties below */
		private IDbTransaction dbTransaction;

		private string strDynamicFieldsData = string.Empty;

		public Response Response = new Response();

		private string _AccessCode = string.Empty;
		private string _Action = string.Empty;
		private bool _ComplexLogic = false;
		
		private string _UniqueID;
		private string _MethodName = string.Empty;
		private string _UserID = string.Empty;

		#endregion

		#region Property : NewEntity
		
		/// <summary>
		/// DataSet containing the schema and data of the required functionality
		/// </summary>
		
		public DataSet NewEntity
		{
			get
			{
				return newDataSet;
			}
			set
			{
				newDataSet = value;
				if (newDataSet != null)
				{
					int iTableCount = newDataSet.Tables.Count;
					for (int iCount = 0; iCount < iTableCount; iCount++) 
					{
						if (!newDataSet.Tables[iCount].Columns.Contains("RowStatus")) 
						{
							DataColumn colString = new DataColumn("RowStatus");
							colString.DataType = System.Type.GetType("System.String");
							newDataSet.Tables[iCount].Columns.Add(colString);
						}
					}
				}
			}
		}

		#endregion

		#region Property : OldEntity
		
		/// <summary>
		/// DataSet containing the schema and data of the required functionality
		/// </summary>
		
		public DataSet OldEntity
		{
			get{return oldDataSet;}
			set{oldDataSet = value;}
		}

		#endregion
		
		#region Property : DbTransaction

		/// <summary>
		/// Provides the Transaction Object
		/// </summary>
		
		public IDbTransaction Transaction
		{
			get{return dbTransaction;}
			set{dbTransaction = value;}		
		}

		#endregion

		#region Property : HashValues

		/// <summary>
		/// Provides the Transaction Object
		/// </summary>
		
		public Hashtable HashValues
		{
			get{return hashTable;}
			set{hashTable = value;}		
		}

		#endregion

		#region Property : Dynamic Data
		
		public string DynamicData
		{
			get{return strDynamicFieldsData;}
			set{strDynamicFieldsData = value;}
		}
		
		#endregion

		#region Get Global Values

		/// <summary>
		/// This method returns the Hashtable value based on the key
		/// </summary>
		/// <param name="key" type="String">Global Value Key </param>
		/// <returns>Key Value as string</returns>
		/// 

		public string GetHashValue(string key)
		{
			try
			{
				return hashTable[key].ToString();
			}
			catch(Exception)
			{
				return "";
			}
		}

		#endregion

		#region Constructor : AccessCode

		/// <summary>
		/// Provides AccessCode information
		/// </summary>
		
		public string AccessCode
		{
			set
			{
				_AccessCode = value;
			}

			get
			{
				return _AccessCode; 
			}
		}

		#endregion

		#region Constructor : Action

		/// <summary>
		/// Provides Action information
		/// </summary>
		
		public string Action
		{
			set
			{
				_Action = value;
			}

			get
			{
				return _Action; 
			}
		}

		#endregion

		#region Constructor : BLLRequired

		/// <summary>
		/// Provides BLLRequired information
		/// </summary>
		
		public bool ComplexLogic
		{
			set
			{
				_ComplexLogic = value;
			}

			get
			{
				return _ComplexLogic; 
			}
		}

		#endregion

		#region Constructor : UniqueID

		/// <summary>
		/// Provides UniqueID
		/// </summary>
		
		public string UniqueID
		{
			set
			{
				_UniqueID = value;
			}

			get
			{
				return _UniqueID; 
			}
		}

		#endregion

		#region Constructor : MethodName

		/// <summary>
		/// Provides MethodName
		/// </summary>
		
		public string MethodName
		{
			set
			{
				_MethodName = value;
			}

			get
			{
				return _MethodName; 
			}
		}

		#endregion

		#region Constructor : UserID

		/// <summary>
		/// Provides MethodName
		/// </summary>
		
		public string UserID
		{
			set
			{
				_UserID = value;
			}

			get
			{
				return _UserID; 
			}
		}

		#endregion


	}
}

