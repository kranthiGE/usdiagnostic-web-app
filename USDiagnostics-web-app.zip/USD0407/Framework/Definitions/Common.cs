#region  Page Level Comments

//File Name		: Common
//Project		: Zaxis-USD
//Object		: Common
//Purpose		: 
//Author		: N. Desayya
//Date			: 12-05-2006
//Module Name	: Architecture
//This file is provided as part of the Zaxis-USD project
//Copyright (C) 2004-06, Zaxis Techonologies Private Limited, All rights reserved
//*********************** Revision History ****************************************************************
//'***********************************************************************************************************

#endregion

#region  NameSpace Declaration

//System NameSpaces
using System;
using System.Reflection;
using System.Text;
using System.Configuration;

//Zaxis-USD NameSpaces

#endregion

namespace Zaxis.Definitions
{

	/// <summary>
	/// This class provides the Common Module information.
	/// </summary>
	
	public class Common
	{

		#region Enum : Module

		/// <summary>
		/// Provides the Module Information
		/// </summary>

		public enum Module
		{ 
			MM,						// Material Management
			DynamicForms,			// Dynamic Forms
			HRP,					// Human Resource
			WORKFLOW,				// Workflow
			Sales,					// Sales and Distribution
            Security,				// Security
			POS,					// Point of Sale
			GP,						// Global Parameters
			REPORTS,				// Reports
			MFG,					// Manufacturing
			Taxation,				// Taxation
			Purchase,				// Purchase
			Finance,				// Accounts and Finance
			Services,
			QAC						// Quality Assurance and Control
		}

		#endregion

		#region Enum : ScreenModes

		/// <summary>
		/// Provides the Enum values for Screen Modes
		/// </summary>
		
		public enum ScreenModes
		{
			Create,					// for Inserting New Record
			Update,					// for Updating the Existing Record
			Delete					// Deleting the Existing Record
		}

		#endregion

		#region Enum : Status

		/// <summary>
		/// Provides the Enum values for Status
		/// </summary>
		public enum Status
		{
			Success,				// 
			Failed
		}
		#endregion

		#region Calling Reflection Methods

		/// <summary>
		/// returns the BusinessData Object
		/// </summary>
		/// <param name="criteria"></param>
		/// <returns>Business Data Object</returns>
		public static object CreateBusinessObject(object criteria)
		{
				// get the type of the actual business object
				Type businessType = criteria.GetType();
				// create an instance of the business object
				return Activator.CreateInstance(businessType, true);
		}

		/// <summary>
		/// This metod returns the method information based on the method type attribute
		/// </summary>
		/// <param name="obj"></param>
		/// <param name="method"></param>
		/// <param name="p"></param>
		/// <returns>MetodInfo object</returns>
		public static object CallMethod(object obj, string method, params object[] param)
		{
			// call a private method on the object
			MethodInfo info = GetMethod(obj.GetType(), method);
			object result;

			try
			{
				result = info.Invoke(obj, param);
			}
			catch(System.Exception e)
			{
				throw e.InnerException;
			}
			return result;
		}

		
		/// <summary>
		/// This method returns the method information based on the mehtod string you have passed
		/// </summary>
		/// <param name="objectType">Type</param>
		/// <param name="method">Name of the Method</param>
		/// <returns>MethodInfo object</returns>
		public static MethodInfo GetMethod(Type objectType, string method)
		{
			return objectType.GetMethod(method, BindingFlags.FlattenHierarchy |
				BindingFlags.Instance |
				BindingFlags.Public |
				BindingFlags.NonPublic);
		}

		#endregion

	}

}
