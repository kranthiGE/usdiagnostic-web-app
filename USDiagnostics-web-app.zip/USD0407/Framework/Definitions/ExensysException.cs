#region  Page Level Comments

//File Name		: ExensysException
//Project		: eXensys 3.0
//Object		: Exception
//Purpose		: 
//Author		: Suresh Kumar
//Date			: 16-02-2004
//Module Name	: Exception Management
//This file is provided as part of the Exensys project
//Copyright (C) 2004-05, HOLOOL E-Business Private Limited, All rights reserved
//*********************** Revision History ****************************************************************
//	Date            Done by             Change Description
//  24-1-2005		N. Desayya			adds the ErrorCode and Row Number propeties
//
//	Date            Done by             Change Description
//  18-3-2005		N. Desayya			modifying the derived class from Exception to ApplicationException
//										and Modified the Constructor from MessageString = message to _Message = message
//'***********************************************************************************************************

#endregion

#region  NameSpace Declaration

//System NameSpaces
using System;
using System.Data;

//eXensys NameSpaces


#endregion

namespace eXensys.Definitions
{
	/// <summary>
	/// This Class Provides properties for raising custom exception
	/// </summary>
	/// <remarks>
	/// <p>
	///  This is used as custom exception and we can set error code property and message string</p>	  	  	
	/// </remarks>
	
	public class ExensysException : ApplicationException
	{
	
		#region Local Variable Declaration

		private string _Errorcode;	// Local variable for Maintaining Error Code
		private string _Message;	// Local variable for maintaining Messages
		private int _RowNumber;		// Maintains Row Number

		#endregion

		#region Default Constructor

		//Constructor;
		public ExensysException() 
		{

		}

		#endregion

		#region ExensysException

		/// <summary>
		/// Constructor
		/// </summary>
		/// <param name="message">stirng message</param>
		
		public ExensysException(string message)
		{
			_Message = message;
		}

		#endregion
		
		#region  Property : MessageString

		/// <summary>
		///  Property to set custom message
		/// </summary>         
		
		public  string  MessageString
		{
			get 
			{
				return _Message;
			}

			set
			{
				_Message = value;
			}
		}

		#endregion

		#region  Property : Errorcode
		
		/// <summary>
		///  Property to set Errorcode  
		/// </summary>         
		
		public string Errorcode
		{
			get 
			{
				return _Errorcode;
			}

			set
			{
				_Errorcode = value;
			}
		}

		#endregion		

		#region  Property : RowNumber
		
		/// <summary>
		///  Property to set RowNumber  
		/// </summary>         
		
		public int RowNumber
		{
			get 
			{
				return _RowNumber;
			}

			set
			{
				_RowNumber = value;
			}
		}

		#endregion
	}
}
