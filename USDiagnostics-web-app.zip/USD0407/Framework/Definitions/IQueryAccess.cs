#region  Page Level Comments

//File Name		: IQueryAccess
//Project		: Zaxis-USD
//Object		: Query Interface
//Purpose		: 
//Author		: N. Desayya
//Date			: 12-5-2006
//Module Name	: Common
//This file is provided as part of the Zaxis-USD project
//Copyright (C) 2004-05, Zaxis Techonologies Private Limited, All rights reserved
//*********************** Revision History ****************************************************************
//'***********************************************************************************************************

#endregion

#region  NameSpace Declaration

//System NameSpaces
using System;

//Zaxis-USD NameSpaces


#endregion

namespace Zaxis.Definitions
{
	public interface IQueryAccess
	{
		/// <summary>
		/// Get QueryString (that returns the Query) against the query name and where condition
		/// </summary>
		/// <remarks>
		/// Ex.:  
		/// string strQuery = GetQueryString("Employee");
		/// </remarks>
		/// <param name="queryName">Name of the Query Ex. <Query><Coloumn Name>fil</Coloumn Name></Query></param>
		/// <param name="whereString">Where condition supplied in XML format</param>
		/// <returns>Returns a Complete SQL Query as string</returns>
		
		string GetQueryString(string queryName, string whereString);

		/// <summary>
		/// Get QueryString (that returns the Query) against the query name and where condition
		/// </summary>
		/// <remarks>
		/// Ex.:  
		/// string strQuery = GetQueryString("Employee");
		/// </remarks>
		/// <param name="queryNames" type="ArryList">Name of the Queries as ArrayList <Query><Coloumn Name>fil</Coloumn Name></Query></param>
		/// <param name="whereString">Where condition supplied in XML format</param>
		/// <returns>Returns a Complete SQL Query as string</returns>
		
		string GetQueryString(System.Collections.ArrayList queryNames, string whereString);

	}
}
