#region  Page Level Comments

/*******************************************************************************************
/*File Name	      :			IEncryption.cs
 *Project Name    :			eXensys 3.0
 *Object          :			IEncryption
 *Purpose         :			Interface Used in Encryption
 *Author          :			naveen.gummudu
 *Date            :			10-26-2005 
 *ModuleName      :			Common
 *This file is provided as part of eXensys project.
 *Copyright � 2004-07, Exensys Software Systems Ltd, All rights reserved
 * ************************************ Revision History************************************
 *
 *  Date            Done by             Method             Change Description


*******************************************************************************************/

#endregion


#region  NameSpace Declaration

//System NameSpaces
using System;
#endregion


namespace eXensys.Definitions
{
	/// <summary>
	/// Summary description for IEncryption.
	/// </summary>
	public interface  IEncryption
	{

		#region Encrypt Methods
		/// <summary>
		/// 
		/// </summary>
		/// <param name="InputText"></param>
		/// <param name="Password"></param>
		/// <returns></returns>
		string EncryptData(string InputText, string Password);

		/// <summary>
		/// 
		/// </summary>
		/// <param name="plainText"></param>
		/// <returns></returns>
		string EncryptData(string plainText);

		/// <summary>
		/// 
		/// </summary>
		/// <param name="varData"></param>
		/// <param name="varPublicKeyIn"></param>
		/// <returns></returns>
		bool EncryptData(byte[] varData,string varPublicKeyIn);
		#endregion

		#region Decrypt Methods
		/// <summary>
		/// 
		/// </summary>
		/// <param name="InputText"></param>
		/// <param name="Password"></param>
		/// <returns></returns>
		string DecryptData(string InputText, string Password);

		/// <summary>
		/// 
		/// </summary>
		/// <param name="sValue"></param>
		/// <returns></returns>
		string DecryptData(string sValue);

		/// <summary>
		/// 
		/// </summary>
		/// <param name="varData"></param>
		/// <param name="varPrivateKeyIn"></param>
		/// <returns></returns>
		bool DecryptData(byte[] varData, string varPrivateKeyIn);
		#endregion

	}
}




	
		

