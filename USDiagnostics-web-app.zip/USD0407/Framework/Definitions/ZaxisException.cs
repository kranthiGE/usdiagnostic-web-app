#region  Page Level Comments

//File Name		: ZxisException
//Project		: Zaxis-USD
//Object		: Exception
//Purpose		: 
//Author		: N. Desayya
//Date			: 12-05-2006
//Module Name	: Exception Management
//This file is provided as part of the Zaxis-USD project
//Copyright (C) 2004-05, Zaxis Techonologies Private Limited, All rights reserved
//*********************** Revision History ****************************************************************
//'***********************************************************************************************************

#endregion

#region  NameSpace Declaration

//System NameSpaces
using System;
using System.Data;

//Zaxis-USD NameSpaces


#endregion

namespace Zaxis.Definitions
{
	/// <summary>
	/// This Class Provides properties for raising custom exception
	/// </summary>
	/// <remarks>
	/// <p>
	///  This is used as custom exception and we can set error code property and message string</p>	  	  	
	/// </remarks>
	
	public class ZaxisException : ApplicationException
	{
	
		#region Local Variable Declaration

		private string _Errorcode;	// Local variable for Maintaining Error Code
		private string _Message;	// Local variable for maintaining Messages
		private int _RowNumber;		// Maintains Row Number

		#endregion

		#region Default Constructor

		//Constructor;
		public ZaxisException() 
		{

		}

		#endregion

		#region HoloolException

		/// <summary>
		/// Constructor
		/// </summary>
		/// <param name="message">stirng message</param>
		
		public ZaxisException(string message)
		{
			_Message = message;
		}

		#endregion
		
		#region  Property : MessageString

		/// <summary>
		///  Property to set custom message
		/// </summary>         
		
		public  string  MessageString
		{
			get 
			{
				return _Message;
			}

			set
			{
				_Message = value;
			}
		}

		#endregion

		#region  Property : Errorcode
		
		/// <summary>
		///  Property to set Errorcode  
		/// </summary>         
		
		public string Errorcode
		{
			get 
			{
				return _Errorcode;
			}

			set
			{
				_Errorcode = value;
			}
		}

		#endregion		

		#region  Property : RowNumber
		
		/// <summary>
		///  Property to set RowNumber  
		/// </summary>         
		
		public int RowNumber
		{
			get 
			{
				return _RowNumber;
			}

			set
			{
				_RowNumber = value;
			}
		}

		#endregion
	}
}
