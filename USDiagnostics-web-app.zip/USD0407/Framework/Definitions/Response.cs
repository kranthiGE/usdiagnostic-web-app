#region Page Level Comments

/*File Name		: Response
* Project		: Zaxis-USD
* Object		: Response
* Purpose		: 
* Author		: N.Desayya
* Date			: 12-5-2006
* Module Name	: Definitions
* This file is provided as part of the Zaxis-USD project
* Copyright � 2004-06, Zaxis Techonologies Private Limited, All rights reserved
* *********************** Revision History ****************************************************************
*	Date            Done by             Change Description
* ***********************************************************************************************************
*/

#endregion

#region Namespace Declaration

// System Namesapaces
using System;
using System.Collections;
using System.Data;

#endregion

namespace Zaxis.Definitions
{
	/// <summary>
	/// Summary description for Response.
	/// </summary>
	/// 

	[Serializable()]
	public class Response
	{

		#region Local Varibles
		
		Common.Status eStatus;
		string strErrorMessage = string.Empty;
		string strErrorCode = string.Empty;
		string strTransactionCode = string.Empty;	// for returning the Transaction Code
		string strTransactionID = string.Empty;		// for returning the Transaction ID(GUID)
		string strMessage = string.Empty;			// for sending the response Message
		string strMessageCode = string.Empty;		// for sending the response Message Code

		ZaxisException exception;

		#endregion

		#region Constructor

		/// <summary>
		/// Empty Constructor
		/// </summary>

		public Response()
		{
		}

		#endregion

		#region Constructor : Status

		/// <summary>
		/// Returns the New GUID
		/// </summary>
		
		public Common.Status Status
		{
			set
			{
				eStatus = value;	
			}
			get
			{
				return eStatus; 
			}
		}

		#endregion

		#region Constructor : ErrorMessage

		/// <summary>
		/// Provides the Error message information
		/// </summary>
		
		public string ErrorMessage
		{
			set
			{
				strErrorMessage = value;	
			}
			get
			{
				return strErrorMessage; 
			}
		}

		#endregion

		#region Constructor : ErrorCode

		/// <summary>
		/// Provides the Error Code information
		/// </summary>
		
		public string ErrorCode
		{
			set
			{
				strErrorCode = value;	
			}
			get
			{
				return strErrorCode; 
			}
		}

		#endregion

		#region Constructor : TransactionCode

		/// <summary>
		/// Provides the Transaction  Code information
		/// </summary>
		
		public string TransactionCode
		{
			set
			{
				strTransactionCode = value;	
			}
			get
			{
				return strTransactionCode; 
			}
		}

		#endregion
		
		#region Constructor : TransactionID

		/// <summary>
		/// Provides the Transaction ID information
		/// </summary>
		
		public string TransactionID
		{
			set
			{
				strTransactionID = value;	
			}
			get
			{
				return strTransactionID; 
			}
		}

		#endregion
		
		#region Constructor : Message

		/// <summary>
		/// Provides the Message information
		/// </summary>
		
		public string Message
		{
			set
			{
				strMessage = value;	
			}
			get
			{
				return strMessage; 
			}
		}

		#endregion

		#region Constructor : MessageCode

		/// <summary>
		/// Provides the Message Code information
		/// </summary>
		
		public string MessageCode
		{
			set
			{
				strMessageCode = value;	
			}
			get
			{
				return strMessageCode; 
			}
		}

		#endregion

		#region Constructor : Exception

		/// <summary>
		/// Provides the Transaction code Code information
		/// </summary>
		
		public ZaxisException ExceptionObject
		{
			set
			{
				exception = value;	
			}
			get
			{
				return exception; 
			}
		}

		#endregion

	}
}
