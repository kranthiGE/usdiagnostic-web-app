#region Page Level Comments

/*File Name		: IFGCommon.cs
* Project		: eXensys 3.0
* Object		: 
* Purpose		: 
* Author		: Arch. Team
* Date			: 17-08-2005
* Module Name	: Common
* This file is provided as part of the Exensys project
* Copyright � 2004-06, HOLOOL E-Business Private Limited,  All rights reserved
* *********************** Revision History ****************************************************************
*
* ***********************************************************************************************************
*/

#endregion

#region Namespace Declaration
	// System Namespace
using System;
using System.Data;
#endregion


namespace eXensys.Definitions
{
	/// <summary>
	/// Interface  providing common functions
	/// </summary>
	public interface IGUICommon
	{
		/// <summary>
		/// Setting the Label Names
		/// </summary>
		void SetLables();

		/// <summary>
		/// Filling Summary Grid
		/// </summary>
		void GetSummaryGridData();

		/// <summary>
		/// Getting DataSet
		/// </summary>
		/// <param name="strMode"></param>
		/// <returns></returns>
		DataSet GetNewData(string strMode);

		/// <summary>
		/// Setting the Screen mode
		/// </summary>
		/// <param name="strMode"></param>
		void SetScreenModes(string strMode);

		/// <summary>
		/// Fiiling the Data in Controls
		/// </summary>
		void FillFormControls();

		/// <summary>
		/// displaying alert messages
		/// </summary>
		/// <param name="strMsgKey"></param>
		void DisplayMessage(string strMsgKey);

		/// <summary>
		/// Getting controls from tab
		/// </summary>
		void GetFormFields();

		/// <summary>
		/// Method For Adding Controls to Search
		/// </summary>
        
		void AddControlsToSearch();
  
		/// <summary>
		/// Method For Filling the Summary Grid Header
		/// </summary>
		 
		void FillSummaryGridHeader();

	}


}
