#region  Page Level Comments

//File Name		: IBusinessEntity
//Project		: Zaxis-USD
//Object		: IBusinessEntity
//Purpose		: 
//Author		: N. Desayya
//Date			: 12-5-2006
//Module Name	: Architecture
//This file is provided as part of the Zaxis-USD project
//Copyright (C) 2004-06, Zaxis Techonologies Private Limited, All rights reserved
//*********************** Revision History ****************************************************************
//'***********************************************************************************************************

#endregion

#region  NameSpace Declaration

//System NameSpaces
using System;

//Zaxis-USD NameSpaces


#endregion

namespace Zaxis.Definitions
{
	/// <summary>
	/// IBusinessEntity.
	/// </summary>
	
	public interface IBusinessEntity
	{

		#region CRUD Methods
		
		/// <summary>
		///  This Create Method is used for creating new record.
		/// </summary>
		/// <returns>'True' if successful; otherwise, Throws Holool Exception</returns>
		/// <remarks>   
		///		If there are fields that contain errors 
		///     it will throw Holool Exception.  
		/// </remarks>   
		/// <param name="data">BusinessData Object</param>
		string Create(BusinessData data);

		/// <summary>
		///  This Update Method is used for Editing the Data
		/// </summary>
		/// <returns>'True' if successful; otherwise, Throws Holool Exception</returns>
		/// <remarks>   
		///		If there are fields that contain errors 
		///     it will writes the Error Log and return Error Number.  
		/// </remarks>   
		/// <remarks>   
		///		If there are fields that contain errors 
		///     it will throw Holool Exception.  
		/// </remarks>   
		/// <param name="dsData"  type="Dataset" >BusinessData Object</param>
		string Update(BusinessData data);

		/// <summary>
		///  This Delete Method is used for deleting the Data
		/// </summary>
		/// <returns>'True' if successful; otherwise, Throws Holool Exception</returns>
		/// <remarks>   
		///		If there are fields that contain errors 
		///     it will writes the Error Log and return Error Number.  
		/// </remarks>   
		/// <remarks>   
		///		If there are fields that contain errors 
		///     it will throw Holool Exception.  
		/// </remarks>   
		/// <param name="dsData"  type="Dataset" >BusinessData Object</param>
		string Delete(BusinessData data);
		
		#endregion

		#region Search


		#endregion
	}
}
