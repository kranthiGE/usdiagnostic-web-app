
#region PageLevel Comments


/*File Name		: CommonAB
* Project		: eXensys 3.0
* Object		: Common Class for all Application Blocks
* Purpose		: 
* Author		: N. Desayya, Kalyan, Suresh
* Date			: 13-12-2004
* Module Name	: Common
* This file is provided as part of the Exensys project
* Copyright � 2004-06, HOLOOL E-Business Private Limited, All rights reserved
* *********************** Revision History ****************************************************************
*	Date            Done by             Change Description
*  10-1-2005		Suresh				This component has been modified according to the Data Access 
*										Application Block				
*  27-2-2005		Desayya				Removed the Asynchronus Bolck Interface and conveted the all async.
										related public methods to privated methods
*  27-2-2005		Desayya				Addedd the PostEventSuccess, PostEventFailure Methods to Async. block
* ***********************************************************************************************************
*/


#endregion

#region Namespace Declaration

//System Namespaces
using System;
using System.Web; 
using System.Data;
using System.Data.SqlClient;
using System.Data.OleDb;
using System.Configuration;
using System.Xml;
using System.Xml.Xsl;
using System.Xml.XPath;
using System.Runtime.Serialization;
using System.Diagnostics;     
using System.Collections.Specialized; 
using System.Collections;  
using System.Text; 
using System.Threading; 



//Microsoft Namespaces
//using Microsoft.ApplicationBlocks.AsynchronousInvocation.Request;     
//using Microsoft.ApplicationBlocks.AsynchronousInvocation.Common;   
//using Microsoft.EnterpriseInstrumentation;
//using Microsoft.ApplicationBlocks.Logging.Schema;
//using Microsoft.ApplicationBlocks.Logging.EventSinks; 
//using Microsoft.ApplicationBlocks.ExceptionManagement;    
//using Microsoft.ApplicationBlocks.ConfigurationManagement;  
//using Microsoft.ApplicationBlocks.Cache;
//using Microsoft.Practices.EnterpriseLibrary.Caching;
using Microsoft.Practices.EnterpriseLibrary.ExceptionHandling;   
#endregion

namespace  Zaxis.CommonAB
{
	/// <summary>
	///  This Class is For Providing the  Application Block Methods
	///  for Developers 
	/// </summary>
	 
    
	#region LogEventType 
 
    /// <summary>
    /// enum for Different Message Events
    /// </summary>
	public enum LogEventType
	{
		AuditMessageEvent,
		AuditOperationEvent,  
		AdminMessageEvent,
		ErrorMessageEvent,
		ExternalErrorMessageEvent,
		InternalErrorMessageEvent
	}
	#endregion

	#region SliddingTimeType Expiration
	
	/// <summary>
	/// This enum for Mentioning the time in milliseconds when to clear 
	/// the cache
	/// </summary>
	public enum SlidingTimeTypeExpiration
	{
		SlidingTimeTypeExpiration	 
	}
	#endregion 

	#region AbsoluteTimeTypeExpiration
    
	/// <summary>
	///  enum for mentioning the AbsoluteTime for Clearing the Cache 
	/// </summary>
	public enum AbsoluteTimeTypeExpiration
	{
		AbsoluteTimeTypeExpiration
	}
	#endregion	 

	#region FileDependencyTypeExpiration
    
	/// <summary>
	///  enum for mentioning the AbsoluteTime for Clearing the Cache 
	/// </summary>
	public enum FileDependencyTypeExpiration
	{
		FileDependencyTypeExpiration
	}
	#endregion	 

	#region CachePriority
   
	/// <summary>
	/// enum for setting the CachePriorities 
	/// </summary>
	public enum CachePriority
	{
		High,
		Low,
		Normal,
		NotRemovable 
      
	}
	#endregion

	#region Logging Interface
	
      /// <summary>
      /// Interface for Logging
      /// </summary>
	public interface ILogging
	{
		//void GetType();     
		void Logging(string Message,LogEventType logeventtype);		               
	}
	#endregion
     
	# region Cache Interface
 
    /// <summary>
    ///  This Interface is for Providing the Methods for CacheBlock
    /// </summary>
	public interface ICache
	{
		
		/// <summary>
		///	Adds an element with the specified key and value into the storage.
		/// </summary>
		void AddDataToCache(string key, object keyData);

		void FlushFromCache();
		
		/// <summary>
		///	Gets the element with the specified key.
		/// </summary>
		object GetDataFromCache(string key);
		
		/// <summary>
		///	Removes the element with the specified key.
		/// </summary>
		void RemoveDataFromCache(string key);
  	
		/// <summary>
		///	Adds the element with the specified key and Specified Expiration.
		/// </summary>
		void AddDataToCache(string key,object keyData,SlidingTimeTypeExpiration expirationtype, System.TimeSpan timespan, CachePriority priority);

		/// <summary>
		///	Adds the element with the specified key and Specified Expiration.
		/// </summary>
		void AddDataToCache(string key,object keyData,AbsoluteTimeTypeExpiration expirationtype, System.DateTime absolutetime,  CachePriority priority);

		void AddDataToCache(string key,object keyData,AbsoluteTimeTypeExpiration expirationtype, System.TimeSpan timespan,  CachePriority priority);

		void AddDataToCache(string key,object keyData,FileDependencyTypeExpiration expirationtype, string FileName,  CachePriority priority);
	}
	# endregion

	#region Exception Interface
	
	interface IException
	{
		void Publish(Exception exception);   
		void Publish(Exception exception, NameValueCollection additionalInfo);
	}
	#endregion

	#region CommonAB

	public class CommonAB : ICache,ILogging,IException 
	{
      
	#region VariableDeclaration

		//Cache
		static bool itemRemoved = false;  
//		static  Microsoft.ApplicationBlocks.Cache.CacheItemRemoveCause reason;		
//		Microsoft.ApplicationBlocks.Cache.CacheItemRemovedCallback onRemove = null; 
//		public Microsoft.ApplicationBlocks.AsynchronousInvocation.Common.InvocationResult invoResults;
        public string requestID; 

		#endregion
	           
	# region AsynchronousBlock Methods Implementation

		#region AddRequest  

		private void AddRequest(string friendlyName, string referenceKey)
		{
//			AsyncRequestBatch  objReqbatch=new AsyncRequestBatch(10,true);         
//			objReqbatch.AddRequest( friendlyName,referenceKey);  
		}

		private void AddRequest(string friendlyName, string referenceKey,object[] serviceAgentInputParam)
		{   
//			AsyncRequestBatch  objReqbatch=new AsyncRequestBatch(10,true);    
//			objReqbatch.AddRequest(friendlyName,referenceKey,serviceAgentInputParam);  
		}
		
		private void AddRequest(string friendlyName,string referenceKey, object[] serviceAgentInputParam,int serviceAgentTimeToLive,int retryCount)
		{  
//			AsyncRequestBatch  objReqbatch=new AsyncRequestBatch(10,true);    
//			objReqbatch.AddRequest(friendlyName,referenceKey,serviceAgentInputParam,serviceAgentTimeToLive,retryCount);
		}

		private void AddRequest(string friendlyName, string referenceKey,int serviceAgentTimeToLive, int retryCount)
		{ 
//			AsyncRequestBatch  objReqbatch=new AsyncRequestBatch(10,true);    
//			objReqbatch.AddRequest(friendlyName,referenceKey,serviceAgentTimeToLive,retryCount);
		}
	
		
		#endregion 

		#region RemoveAllServiceAgentInputData
		
		private void RemoveAllServiceAgentInputData()
		{ 
//			AsyncRequestBatch  objReqbatch=new AsyncRequestBatch(10,true);    
//			objReqbatch.RemoveAllServiceAgentInputData();
		}
		

		private void RemoveServiceAgentInputData(string referenceKey)
		{ 
//			AsyncRequestBatch  objReqbatch=new AsyncRequestBatch(10,true);    
//			objReqbatch.RemoveServiceAgentInputData(referenceKey);    
		}  
		
		#endregion

		#region SubmitRequest
		
//		private  string SubmitRequest(AsyncRequestBatch requestBatch)
//		{  
//			return AsyncRequestProcessor.SubmitRequest(requestBatch);
//		}
		
		# endregion

		#region CancelRequest

		private void CancelRequest(string requestID)
		{
//			ResultsManager.CancelRequest(requestID);
		}


		#endregion

		#region "Clear Results"
		private	void ClearResults(string requestID){ 
//			ResultsManager.ClearResults(requestID);
		}
		#endregion

		# region "GetIncrementalResults"
//		private InvocationResult GetIncrementalResults(string requestID)
//		{
//			return ResultsManager.GetIncrementalResults(requestID);
//		}

//		public InvocationResult GetIncrementalResults(string requestID,string referenceKey )
//		{
//			return ResultsManager.GetIncrementalResults(requestID,referenceKey);
//		} 

		#endregion

		#region "GetRequestStatus"
//		private  RequestStatus GetRequestStatus(string requestID)
//		{ 
//			return ResultsManager.GetRequestStatus(requestID);
//		}
		#endregion
		
		#region "GetResultsCompletionStatus"
//		private ResultCompletionStatus GetResultCompletionStatus(string requestID)
//		{ 
//			  return ResultsManager.GetResultCompletionStatus(requestID);
//		}
 		#endregion

		#region "GetResults"		 
		private  DataSet GetResults(string requestID)

		{
//			Microsoft.ApplicationBlocks.AsynchronousInvocation.Common.InvocationResult invoResults; 
//			invoResults=ResultsManager.GetResults(requestID);
//			return invoResults.ResultData; 
			return null;// to be remove
		}

		private  DataSet GetResults(string requestID,string referenceKey)
		{
//			Microsoft.ApplicationBlocks.AsynchronousInvocation.Common.InvocationResult invoResults; 
//			invoResults=ResultsManager.GetResults(requestID,referenceKey);  
//			return invoResults.ResultData;
			return null;// to be remove
		}

		#endregion
              
		# region "PostEventSuccess(ds,ht)"  
		
		public string PostEventSuccess(DataSet ds, Hashtable hashValues)
		   { 
//			   AsyncRequestBatch  objReqbatch=new AsyncRequestBatch(10,true);  
//			   if (objReqbatch.Count > 0)
//			   {
//				   objReqbatch.RemoveAllServiceAgentInputData();
//			   }
//			   string strHashXml = GetIFHashXml(hashValues);
//			   objReqbatch.AddRequest("DataSetAgent","PostEventSuccess",new object[]{CreateInputParam("IFDataSet", ds.GetXml().ToString()),
//																					 CreateInputParam("HashXml", strHashXml)}); 
//			   requestID = AsyncRequestProcessor.SubmitRequest(objReqbatch);
			  
			  return "";
		   }
		  
		
		#endregion    

		# region PostEventSuccess(ods,nds,ht)
    
			public string PostEventSuccess(DataSet oldDs, DataSet newDs, Hashtable hashValues)
			{ 

				try
				{	 
//					AsyncRequestBatch  objReqbatch=new AsyncRequestBatch(10,true);  
//					if (objReqbatch.Count > 0)
//					{
//						objReqbatch.RemoveAllServiceAgentInputData();
//					}
					if(hashValues == null)
					{
						hashValues = new Hashtable();
						hashValues.Add("Action","Add");   
					}
					if(oldDs == null)
					{
						oldDs = new DataSet();
						hashValues["Action"] = "Add";  }
					if(newDs == null)
					{
						newDs = new DataSet();
						hashValues["Action"] = "Delete";
					}
				
					string strHashXml = GetIFHashXml(hashValues);
//					objReqbatch.AddRequest("DataSetAgent","PostEventSuccess",new object[]{CreateInputParam("OldDataSet", oldDs.GetXml().ToString()),
//																							 CreateInputParam("NewDataSet", newDs.GetXml().ToString()),
//																							 CreateInputParam("HashXml", strHashXml)}); 
//				   requestID = AsyncRequestProcessor.SubmitRequest(objReqbatch);
	               //HttpContext.Current.Session["requestID"] = requestID;    
				}
				catch(Exception)
				{}
              return "";
			}

		
		#endregion

		# region PostEventFailure(Exobj,ht)
		public string PostEventFailure(Zaxis.Definitions.ZaxisException objException, Hashtable hashValues)
		{
//			AsyncRequestBatch  objReqbatch=new AsyncRequestBatch(10,true);         
//			string strHashXml = GetIFHashXml(hashValues);
//			objReqbatch.AddRequest("DataSetAgent","PostEventFailure",new object[]{CreateInputParam("ErrorCode", objException.Errorcode.ToString()),
//																					 CreateInputParam("ErrorMessage",objException.MessageString.ToString()),
//																					 CreateInputParam("HashXml", strHashXml)}); 
//			requestID = AsyncRequestProcessor.SubmitRequest(objReqbatch);
           
          
			ExceptionPolicy.HandleException(objException, "Log Only Policy");   
			
			return "";
		}  
		#endregion

		# region "PostEventFailure(errorcode,ht)"
			public string PostEventFailure(int errorcode, Hashtable hashValues)
		{
			return "";
		}  
		#endregion
   
		#region PostEventWorkFlow
		public string PostEventWorkFlow(string WFLRequest,Hashtable WFLht)
		{
//			AsyncRequestBatch  objReqbatch=new AsyncRequestBatch(10,true);         
//			string strHashXml = GetHashXml(WFLht);
//			objReqbatch.AddRequest("WorkFlowAgent","WE3",new object[]{CreateInputParam("WFLString",WFLRequest ),
//																	  CreateInputParam("HashXml", strHashXml)}); 
//			requestID = AsyncRequestProcessor.SubmitRequest(objReqbatch);
//			Thread.Sleep(10000);   
//			invoResults = ResultsManager.GetResults(requestID); 
//			DataSet resultDataSet	= invoResults.ResultData;
//			int iCheck = resultDataSet.Tables[0].Rows.Count;
//			return resultDataSet.Tables[0].Rows[0][2].ToString();
		
		return "";
		}
    

		#endregion

		private string GetIFHashXml(Hashtable htValues)
		{
			StringBuilder strbldHashTable = new StringBuilder();
			strbldHashTable.Append("<HashTable>");
			IDictionaryEnumerator myEnumerator = htValues.GetEnumerator();

			while(myEnumerator.MoveNext())
				strbldHashTable.Append("<Data key = '" + myEnumerator.Key.ToString() + "' value = '" +  myEnumerator.Value.ToString() + "' />"); 

			return strbldHashTable.Append("</HashTable>").ToString(); 
		}
  

		private string GetHashXml(Hashtable ht)
		{
			StringBuilder strbldHashTable = new StringBuilder();
			strbldHashTable.Append("<HashTable>");
			IDictionaryEnumerator myEnumerator = ht.GetEnumerator();

			while(myEnumerator.MoveNext())
			{

				strbldHashTable.Append("<Data key='"+ myEnumerator.Key.ToString()+"'>"); 
				strbldHashTable.Append("<Value>"+ myEnumerator.Value.ToString() +"</Value>");  
				strbldHashTable.Append("</Data>"); 
              
			}
			strbldHashTable.Append("</HashTable>"); 
			string strxml = strbldHashTable.ToString();
			return strxml; 
		
		}


		private DictionaryEntry  CreateInputParam(string ds, string ht)
		{
			return new DictionaryEntry(ds, ht);
		}


		# endregion 

	# region CacheBlock Methods Implementation
		
		#region AddDataToCache

             /// <summary>
             /// Method for Adding the Data to the Cache
             /// </summary>
             /// <param name="key">User Defined Varible </param>
             /// <param name="keyData">object</param>

		public void AddDataToCache( string key, object keyData)
		{
//			CacheManager objCm =  CacheFactory.GetCacheManager();
//			objCm.Add(key,keyData); 
//			objCm = null;
		}

		
		#endregion

		#region FlushFromCache

		/// <summary>
		/// Removes All the Data From the Cache
		/// </summary>
		/// 

		public void FlushFromCache()
		{
//			CacheManager objCm =  CacheFactory.GetCacheManager();
//			objCm.Flush();
//			objCm = null;
		}


		#endregion

		#region GetDataFromCache
  
         /// <summary>
         ///  For retrieving the Data from the Cache with specified Key value 
         /// </summary>
         /// <param name="key">Userdefined Variable</param>
         /// <returns>object</returns>
        
		public object GetDataFromCache(string key)
		{
//		  
//			CacheManager objCm =  CacheFactory.GetCacheManager();
//			try
//			{
//				return objCm.GetData(key);
//			}
//			catch(Exception)
//			{
//				return null;
//			}
//        
			return null;
		}

		
		#endregion  

		#region RemoveDataFromCache
		 
        /// <summary>
        /// Method for Removing the Data From the Cache
        /// by specifying the Key Value  
        /// </summary>
        /// <param name="key">UserDefined Variable</param>

		public void RemoveDataFromCache(string key)
		{
//			CacheManager objCm =  CacheFactory.GetCacheManager();
//			objCm.Remove(key);
//			objCm = null;
		}
		

		#endregion

		#region AddDataToCache overload for SlidingTimeTypeExpiration
         
		 /// <summary>
		 /// Method for adding the Data into the Cache
		 /// </summary>
		 /// <param name="key">UserDefined Variable </param>
		 /// <param name="keyData">Object </param>
		 /// <param name="expirationtype">it is SlidingTimeExpiration </param>
		 /// <param name="timespan">System.timespan </param>
		 /// <param name="priority">Priority of the Cache item</param>

		public void AddDataToCache(string key,object keyData,SlidingTimeTypeExpiration expirationtype, System.TimeSpan timespan, CachePriority priority)
		{

//			#region checkforpriority
//			string CachePriority = priority.ToString();
//			//for default
//			CacheItemPriority cachepriority = CacheItemPriority.High;
//			switch(CachePriority)
//			{
//				case "High" :                                   
//					cachepriority =   CacheItemPriority.High;
//					break;
//				case "Low" : 
//					cachepriority =   CacheItemPriority.Low;
//					break;
//				case "Normal" : 
//					cachepriority =   CacheItemPriority.Normal;
//					break;
//				case "NotRemovable": 
//					cachepriority =   CacheItemPriority.NotRemovable;
//					break;		
//			
//			}
//			#endregion
//          
//			CacheManager objCm =  CacheFactory.GetCacheManager();
//			Microsoft.Practices.EnterpriseLibrary.Caching.Expirations.SlidingTime slidingTime = new Microsoft.Practices.EnterpriseLibrary.Caching.Expirations.SlidingTime(timespan);  
//			objCm.Add(key,keyData,cachepriority,null,slidingTime);

		}
	
		
		#endregion

		#region AddDataToCache overload for AbsoluteTimeTypeExpiration

        /// <summary>
        /// Method for adding the Data into the Cache
        /// </summary>
        /// <param name="key">UserDefined Variable</param>
        /// <param name="keyData">Object </param>
        /// <param name="expirationtype">it is AbsoluteTimeTypeExpiration</param>
        /// <param name="absolutetime">time in Milliseconds </param>
        /// <param name="priority">Priority of the Cache item</param>

		public void AddDataToCache(string key,object keyData,AbsoluteTimeTypeExpiration expirationtype, System.DateTime absolutetime,  CachePriority priority)
		{
//
//			#region checkforpriority
//				string CachePriority = priority.ToString();
//			//for default
//			CacheItemPriority cachepriority = CacheItemPriority.High;
//			switch(CachePriority)
//			{
//				case "High" :                                   
//					cachepriority =   CacheItemPriority.High;
//					break;
//				case "Low" : 
//					cachepriority =   CacheItemPriority.Low;
//					break;
//				case "Normal" : 
//					cachepriority =   CacheItemPriority.Normal;
//					break;
//				case "NotRemovable": 
//					cachepriority =   CacheItemPriority.NotRemovable;
//					break;		
//			
//			}
//			#endregion
//			CacheManager objCm =  CacheFactory.GetCacheManager();
//			Microsoft.Practices.EnterpriseLibrary.Caching.Expirations.AbsoluteTime absTime = new Microsoft.Practices.EnterpriseLibrary.Caching.Expirations.AbsoluteTime(absolutetime);
//			objCm.Add(key,keyData,cachepriority,null,absTime);
		} 	
		#endregion 

		public void AddDataToCache(string key,object keyData,AbsoluteTimeTypeExpiration expirationtype, System.TimeSpan TimeSpan,  CachePriority priority)
		{
//			#region checkforpriority
//			string CachePriority = priority.ToString();
//			//for default
//			CacheItemPriority cachepriority = CacheItemPriority.High;
//			switch(CachePriority)
//			{
//				case "High" :                                   
//					cachepriority =   CacheItemPriority.High;
//					break;
//				case "Low" : 
//					cachepriority =   CacheItemPriority.Low;
//					break;
//				case "Normal" : 
//					cachepriority =   CacheItemPriority.Normal;
//					break;
//				case "NotRemovable": 
//					cachepriority =   CacheItemPriority.NotRemovable;
//					break;		
//			
//			}
//			#endregion
//			CacheManager objCm =  CacheFactory.GetCacheManager();
//			Microsoft.Practices.EnterpriseLibrary.Caching.Expirations.AbsoluteTime absTime = new Microsoft.Practices.EnterpriseLibrary.Caching.Expirations.AbsoluteTime(TimeSpan);
//			objCm.Add(key,keyData,cachepriority,null,absTime);
		}


		public void AddDataToCache(string key,object keyData,FileDependencyTypeExpiration expirationtype, string FileName,  CachePriority priority)
		{
//			#region checkforpriority
//			string CachePriority = priority.ToString();
//			//for default
//			CacheItemPriority cachepriority = CacheItemPriority.High;
//			switch(CachePriority)
//			{
//				case "High" :                                   
//					cachepriority =   CacheItemPriority.High;
//					break;
//				case "Low" : 
//					cachepriority =   CacheItemPriority.Low;
//					break;
//				case "Normal" : 
//					cachepriority =   CacheItemPriority.Normal;
//					break;
//				case "NotRemovable": 
//					cachepriority =   CacheItemPriority.NotRemovable;
//					break;		
//			
//			}
//			#endregion
//           
//			CacheManager objCm =  CacheFactory.GetCacheManager();
//			Microsoft.Practices.EnterpriseLibrary.Caching.Expirations.FileDependency FDExpiration = new Microsoft.Practices.EnterpriseLibrary.Caching.Expirations.FileDependency(FileName);
//			objCm.Add(key,keyData,cachepriority,null,FDExpiration);         

		}

   




		#region RemovedCallback

         /// <summary>
         /// This method will called when adding the items to the 
         /// Cache.
         /// </summary>
         /// <param name="k"></param>
         /// <param name="r"></param>
  
//		public void  RemovedCallback(String k, Microsoft.ApplicationBlocks.Cache.CacheItemRemoveCause  r)
//		{
//			itemRemoved = true;
//			reason = r;
//		}
		
	
		#endregion
       

		# endregion

	# region ExceptionBlock Methods Implementation
		
		# region "Publish"
		   
		public  void Publish(Exception exception)
		{
//			ExceptionManager.Publish(exception);  
		}
		public void Publish(Exception exception, NameValueCollection additionalInfo)
		{
//			ExceptionManager.Publish(exception,additionalInfo);  
		}


		# endregion    

		#endregion

    #region Logging Block

    /// <summary>
    /// This Method will Log the Message in to the EventLog or SQL Server 
    /// Based on the information in the Config file
    /// </summary>
    /// <param name="Message">User Message</param>
	/// <param name="logeventtype">it is enum and it can be AuditMessageEvent
	///	                               AuditOperationEvent  
	///								   AdminMessageEvent
	///								   ErrorMessageEvent
	///								   ExternalErrorMessageEvent
	///								   InternalErrorMessageEvent
    ///		</param>

     public void Logging(string Message,LogEventType logeventtype)
		{
          
			string strPublishEventType=logeventtype.ToString();			

			switch(strPublishEventType)
			{
				case "AuditMessageEvent" : 
                  
//					AuditMessageEvent objAuditMessageEvent = new AuditMessageEvent();						
//					objAuditMessageEvent.Message =Message;							 
//					objAuditMessageEvent.EventPublishLogLevel = (int) LogLevel.Always; 	
//					EventSource.Application.Raise(objAuditMessageEvent);  
					break;

				case "AuditOperationEvent" : 

//					AuditOperationEvent objAuditOperationEvent = new AuditOperationEvent();
//					objAuditOperationEvent.FormatterName = "eventSpecifiedXslt";
//					objAuditOperationEvent.EventPublishLogLevel = (int) LogLevel.Always; 	
//					EventSource.Application.Raise(objAuditOperationEvent);  
					break; 

//				case "AdminMessageEvent" : 
//					AdminMessageEvent objAdminMessageEvent = new AdminMessageEvent();
//					objAdminMessageEvent.Message =Message;		
//					objAdminMessageEvent.EventLogEntryTypeID=(Int32)EventLogEntryType.Warning; 
//					objAdminMessageEvent.FormatterName = "eventSpecifiedXslt";
//					objAdminMessageEvent.EventPublishLogLevel = (int) LogLevel.Always; 	
//					EventSource.Application.Raise(objAdminMessageEvent);  
//					break;                  


				case "ErrorMessageEvent" :                      
//					ErrorMessageEvent objErrorMessageEvent = new ErrorMessageEvent();
//					objErrorMessageEvent.Message =Message;		
//					objErrorMessageEvent.FormatterName = "eventSpecifiedXslt";
//					objErrorMessageEvent.EventPublishLogLevel = (int) LogLevel.Always; 	
//					EventSource.Application.Raise(objErrorMessageEvent);  
					break;

				case "ExternalErrorMessageEvent" : 
//					ExternalErrorMessageEvent objExternalErrorMessageEvent = new ExternalErrorMessageEvent();
//					objExternalErrorMessageEvent.Message =Message;		        
//					objExternalErrorMessageEvent.FormatterName = "eventSpecifiedXslt";
//					objExternalErrorMessageEvent.EventPublishLogLevel = (int) LogLevel.Always; 	
//					EventSource.Application.Raise(objExternalErrorMessageEvent);  
					break;

				case "InternalErrorMessageEvent" : 
//					InternalErrorMessageEvent objInternalErrorMessageEvent = new InternalErrorMessageEvent();
//					objInternalErrorMessageEvent.Message =Message;		
//					objInternalErrorMessageEvent.FormatterName = "eventSpecifiedXslt";
//					objInternalErrorMessageEvent.EventPublishLogLevel = (int) LogLevel.Always; 	
//					EventSource.Application.Raise(objInternalErrorMessageEvent);  
					break; 
			}

		}


   #endregion

    #region Configuration Application Block Methods

		#region GetStorageSection

		/// <summary>
		/// Method Which Returns the Section Value by taking the Key Value
		/// </summary>
		/// <param name="key">Key Value in the ConfigurationFile</param>
		/// <returns>SectionName</returns>
		
		public string GetStorageSection(string key)
		{
			string strStorageSection;
			try
			{
				strStorageSection = ConfigurationSettings.AppSettings[key]; 
				return strStorageSection;
			}
			catch(Exception)
			{
				return "null";              
			}

		}  
		
		
		#endregion

		#region WriteToConfig
		
		/// <summary>
		/// Mthod for writing the Specified Section in to the ConfigFile
		/// </summary>
		/// <param name="StorageSectionName">Section Name </param>
		/// <param name="htConfigDetails">HashTable With ConfigDetails </param>
		
		public void WriteToConfig(string StorageSectionName,Hashtable htConfigDetails)
		{
//          ConfigurationManager.Write(StorageSectionName,htConfigDetails);   
		}
		
		#endregion

		#region ReadFromConfig

		/// <summary>
		/// Which Reads the Specified SectionValues
		/// </summary>
		/// <param name="StorageSectionName">SectionName</param>
		/// <param name="htConfigDetails">Hashtable with ConfigDetails</param>
		/// <returns></returns>

		public Hashtable ReadFromConfig(string StorageSectionName,Hashtable htConfigDetails)
		{
			try
			{
//				htConfigDetails = (Hashtable)ConfigurationManager.Read(StorageSectionName);
				return htConfigDetails;
			}
			catch(Exception)
			{
				return null;
			}

		}

		#endregion

        #endregion

	}

	#endregion

}
