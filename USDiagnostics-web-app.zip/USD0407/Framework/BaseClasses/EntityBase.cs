#region Page Level Comments

/*File Name		: Entity Base
* Project		: USD 1.0
* Object		: Entity Base
* Purpose		: 
* Author		: N.Desayya
* Date			: 13-5-2006
* Module Name	: Base Classes
* This file is provided as part of the Zaxis-USD project
* Copyright � 2004-06, Zaxus Technologies , All rights reserved
* *********************** Revision History ****************************************************************
*	Date            Done by             Change Description
* ***********************************************************************************************************
*/

#endregion

#region Namespace Declaration

// System Namesapaces
using System;
using System.Data;
using System.Xml;
using System.Xml.XPath;
using System.Collections;

// Zaxis-USD Namespaces
using Zaxis.Definitions;

#endregion

namespace Zaxis.BaseClasses
{
	/// <summary>
	/// Summary description for EntityBase.
	/// </summary>
	public abstract class EntityBase
	{

		#region Local Variable Declaration

		#endregion

		#region Constructor : GetUniqueID

		/// <summary>
		/// Returns the New GUID
		/// </summary>
		
		public string GetUniqueID
		{
			get
			{
				return Guid.NewGuid().ToString(); 
			}
		}

		#endregion

		#region Execute Dynamic Form

		/// <summary>
		/// This method inserts the Dyanamic Column data into respective table
		/// </summary>
		/// <param name="dsDynamicForm">Dataset Dynamic FOmr</param>
		/// <param name="transaction">Transaction Object</param>
		
		public void ExecuteDynamicForm(DataSet dsDynamicForm, IDbTransaction transaction)
		{
//			int iTableCount = dsDynamicForm.Tables.Count;
//			string strQuery = "";
//			int iRowCount = 0;
//			int iResult = 0;
//			for(int i = 0; i < iTableCount; i++)
//			{
//				if (dsDynamicForm.Tables[i].TableName.ToString().EndsWith("EXTENDED"))
//				{
//					iRowCount = dsDynamicForm.Tables[i].Rows.Count;
//					for(int j = 0; j < iRowCount; j++)
//					{
//						strQuery = dsDynamicForm.Tables[i].Rows[j][0].ToString();
//						strQuery = strQuery.Replace("GUID", UniqueID);
//						Zaxis.Common.CommonBase objCommon = new Zaxis.Common.CommonBase();
//						iResult = Convert.ToInt16(objCommon.Execute(CommandType.Text, strQuery, transaction));		
//						if (iResult >= 1)
//							return;
//					}
//				}
//			}
		}

		#endregion
		
		#region ReplaceQuotes

		public DataSet ReplaceQuotes(DataSet dsData)
		{
			int iTableCount = dsData.Tables.Count;
			int iRowCount = 0;
			DataRow drRowData;
			// loof through tables
			for(int iTblCount = 0; iTblCount < iTableCount; iTblCount++)
			{	
				iRowCount = dsData.Tables[iTblCount].Rows.Count;
				// loof through Rows
				for(int iRCount = 0; iRCount < iRowCount; iRCount++)
				{
					drRowData = dsData.Tables[iTblCount].Rows[iRCount];
					// Iterating through Columns
					for(int iCCount = 0; iCCount < drRowData.ItemArray.Length; iCCount++)
					{
						string strRowValue = drRowData[iCCount].ToString();  
						// re
						int iindex = strRowValue.IndexOf("'");
						if(iindex!=-1)
						{
							strRowValue = strRowValue.Replace("'", "''"); 
							drRowData[iCCount] = strRowValue;
						}
					}
				}
			}
			return dsData;
		}
		#endregion

		#region CRUD Methods
		
		public abstract void Create(BusinessData businessdata);
		public abstract void Update(BusinessData businessdata);
		public abstract void Delete(BusinessData businessdata);
		public abstract bool CodeExists(string Code);
	
		#endregion

	}
}

