#region  Page Level Comments

/*******************************************************************************************
/*File Name	      :			FServiceBase.cs
 *Project Name    :			USD 1.0
 *Object          :			FServiceBase
 *Purpose         :			
 *Author          :			desayya.namala
 *Date            :			13-5-2006 
 *ModuleName      :			
 *This file is provided as part of Zaxis-USD project.
 *Copyright � 2004-07, Zaxis-USD Technologies, All rights reserved
 * ************************************ Revision History************************************
 *
 *  Date            Done by             Method             Change Description


*******************************************************************************************/

#endregion

#region  NameSpace Declaration

//System NameSpaces

using System;
using System.EnterpriseServices;

//Zaxis-USD NameSpaces
using Zaxis.Definitions;

#endregion


namespace Zaxis.BaseClasses
{

	/// <summary>
	/// Implements the transactional object
	/// </summary>
	[Transaction(TransactionOption.Required), EventTrackingEnabled(true)]
	public class FServiceBase : ServicedComponent
	{

		#region CRUD Methods

		/// <summary>
		/// Invokes the server-side DataPortal Create method within
		/// a COM+ transaction.
		/// </summary>
		/// <param name="criteria"></param>
		/// <param name="businessdata"></param>
		/// <returns></returns>
		[AutoComplete(true)]
		public object Create(object criteria, BusinessData businessdata)
		{
			FRemoteBase remotebase = new FRemoteBase();
			return remotebase.Create(criteria, businessdata);
		}


		#endregion
	}
}
