
#region  Page Level Comments

/*******************************************************************************************
/*File Name	      :			FacadeBase.cs
 *Project Name    :			USD 1.0
 *Object          :			FacadeBase
 *Purpose         :			
 *Author          :			desayya.namala
 *Date            :			12-5-2006 
 *ModuleName      :			Baseclasses
 *This file is provided as part of Zaxis-USD project.
 *Copyright � 2004-07, Zaxis-USD Technologies, All rights reserved
 * ************************************ Revision History************************************
 *
 *  Date            Done by             Method             Change Description

*******************************************************************************************/

#endregion

#region  NameSpace Declaration

//System NameSpaces

using System;
using System.Data;

//Zaxis-USD NameSpaces
using Zaxis.Definitions;
using Zaxis.Common;

//using Zaxis.Common;

#endregion


namespace Zaxis.BaseClasses
{

	/// <summary>
	/// Provides System Specific functionality like initializing and committing the transactions
	/// and also calls the PostEentSuccess and PostEventFailurs based on the response status.
	/// </summary>

	public class FacadeBase : IDisposable
	{

		#region Local Variables

		private IDbTransaction  dbTransaction = null;
		private CommonBase cbObject = null;

		#endregion

		#region Constructor

		/// <summary>
		/// Empty Constructor
		/// </summary>

		public FacadeBase()
		{
		}

		#endregion

		#region Initialize

		public void Initialize(BusinessData businessdata)
		{
			cbObject = new CommonBase();
			businessdata.Transaction = cbObject.GetTransaction();
			cbObject = null;
		}
		
		#endregion
		
		#region Validate Response

		/// <summary>
		/// This method commits or rollbacks the transaction based on the response object status
		/// and also call the PostEentSuccess/PostEventFailure methods
		/// </summary>
		/// <param name="businessdata">Business Data Object</param>
		/// <returns>Reruns Result in the form of Response Object </returns>

		public Response Validate(BusinessData businessdata)
		{
			Response response = null;
			Zaxis.Common.CommonAB objCommon = new  Zaxis.Common.CommonAB();
			if (businessdata.Response.Status.Equals(Definitions.Common.Status.Success))
			{
				businessdata.Transaction.Commit();
				// Calling Post Event Success 
				objCommon.PostEventSuccess(businessdata.OldEntity, businessdata.NewEntity, businessdata.HashValues);
			}
			else
			{
				businessdata.Transaction.Rollback();
				// Calling Post Event Failure 
				objCommon.PostEventFailure(businessdata.Response.ExceptionObject, businessdata.HashValues);
			}

			response = businessdata.Response;

			// Clearing the objects
			objCommon = null;
			businessdata = null;

			return response;
		}

		#endregion

		#region Dispose

		/// <summary>
		/// This object will be cleaned up by the Dispose method.
		/// Therefore, you should call GC.SupressFinalize to
		/// take this object off the finalization queue 
		/// and prevent finalization code for this object
		/// from executing a second time.
		/// </summary>

		public void Dispose()
		{
			GC.SuppressFinalize(this);
		}

		#endregion
	}
}
