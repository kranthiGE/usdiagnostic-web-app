#region  Page Level Comments

/*******************************************************************************************
/*File Name	      :			TransactionalAttribute.cs
 *Project Name    :			USD 1.0
 *Object          :			TransactionalAttribute
 *Purpose         :			
 *Author          :			desayya.namala
 *Date            :			13-5-2006 
 *ModuleName      :			
 *This file is provided as part of Zaxis-USD project.
 *Copyright � 2004-07, Zaxis-USD Technologies, All rights reserved
 * ************************************ Revision History************************************
 *
 *  Date            Done by             Method             Change Description


*******************************************************************************************/

#endregion

#region  NameSpace Declaration

//System NameSpaces

using System;

#endregion

namespace Zaxis.BaseClasses
{
	/// <summary>
	/// Allows us to mark the DataPortal_xxx methods in our business
	/// classes as transactional.
	/// </summary>
	/// <remarks>
	/// When a method is marked as transactional, the DataPortal
	/// mechanism runs the method within a COM+ transactional
	/// context, so the data access is protected by a 2-phase
	/// distributed transaction.
	/// </remarks>
	
	[AttributeUsage(AttributeTargets.Method)]
	public class TransactionalAttribute : Attribute
	{}

}
