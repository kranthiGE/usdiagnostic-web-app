#region Page Level Comments

/*File Name		: BELBase
* Project		: USD 1.0
* Object		: BELBase
* Purpose		: 
* Author		: N.Desayya
* Date			: 13-5-2006
* Module Name	: Common
* This file is provided as part of the Zaxis-USD project
* Copyright � 2004-06, Zaxus Technologies , All rights reserved
* *********************** Revision History ****************************************************************
*	Date            Done by             Change Description
* ***********************************************************************************************************
*/

#endregion

#region Namespace Declaration

// System Namesapaces
using System;
using System.Data;
using System.Xml;
using System.Xml.XPath;

#endregion

namespace Zaxis.BaseClasses
{
	/// <summary>
	/// Summary description for BELBase.
	/// </summary>
	
	public class BELBase
	{

		#region Constructor
		
		/// <summary>
		/// Empty Constructor
		/// </summary>
		
		public BELBase()
		{
		}

		#endregion

		#region Local Variable Declaration

		private string _UniqueID;

		#endregion

		#region Constructor : UniqueID

		/// <summary>
		/// Provides UniqueID
		/// </summary>
		
		public string UniqueID
		{
			set
			{
				_UniqueID = value;
			}

			get
			{
				return _UniqueID; 
			}
		}

		#endregion

		#region Execute Dynamic Form

		/// <summary>
		/// This method inserts the Dyanamic Column data into respective table
		/// </summary>
		/// <param name="dsDynamicForm">Dataset Dynamic FOmr</param>
		/// <param name="transaction">Transaction Object</param>
		
		public void ExecuteDynamicForm(DataSet dsDynamicForm, IDbTransaction transaction)
		{
			int iTableCount = dsDynamicForm.Tables.Count;
			string strQuery = "";
			int iRowCount = 0;
			int iResult = 0;
			for(int i = 0; i < iTableCount; i++)
			{
				if (dsDynamicForm.Tables[i].TableName.ToString().EndsWith("EXTENDED"))
				{
					iRowCount = dsDynamicForm.Tables[i].Rows.Count;
					for(int j = 0; j < iRowCount; j++)
					{
						strQuery = dsDynamicForm.Tables[i].Rows[j][0].ToString();
						strQuery = strQuery.Replace("GUID", UniqueID);
						strQuery = strQuery.Replace("''", "'");
						Zaxis.Common.CommonBase objCommon = new Zaxis.Common.CommonBase();
						iResult = Convert.ToInt16(objCommon.Execute(CommandType.Text, strQuery, transaction));		
						if (iResult >= 1)
							return;
					}
				}
			}
		}

		#endregion
		
		#region ReplaceQuotes

		public DataSet ReplaceQuotes(DataSet dsData)
		{
			int iTableCount = dsData.Tables.Count;
			int iRowCount = 0;
			DataRow drRowData;
			// loof through tables
			for(int iTblCount = 0; iTblCount < iTableCount; iTblCount++)
			{	
				iRowCount = dsData.Tables[iTblCount].Rows.Count;
				// loof through Rows
				for(int iRCount = 0; iRCount < iRowCount; iRCount++)
				{
					drRowData = dsData.Tables[iTblCount].Rows[iRCount];
					// Iterating through Columns
					for(int iCCount = 0; iCCount < drRowData.ItemArray.Length; iCCount++)
					{
						string strRowValue = drRowData[iCCount].ToString();  
						// re
						int iindex = strRowValue.IndexOf("'");
						if(iindex!=-1)
						{
							strRowValue = strRowValue.Replace("'", "''"); 
							drRowData[iCCount] = strRowValue;
						}
					}
				}
			}
			return dsData;
		}
		#endregion

		#region Xml API related Methods

		/// <summary>
		/// this method is used to get the specified node value from xml string 
		/// </summary>
		/// <param name="strNodeText">Node Text</param>
		/// <param name="strXMLFile">XML File</param>
		/// <returns></returns>

		public string getNodeXml(string strNodeText, string strXMLFile)
		{
			try
			{
				XmlDocument xmlDoc = new XmlDocument();
				XmlNodeList   xmlNode; 
				xmlDoc.LoadXml(strXMLFile);
				xmlNode = xmlDoc.DocumentElement.GetElementsByTagName(strNodeText);
				return xmlNode[0].InnerText;
			}
			catch(Exception )
			{
				return "null";
			}
		}//end of getNodeText


		/// <summary>
		/// this method is used to get the specified attribute value from xml string 
		/// </summary>
		/// <param name="strAttribute">Atributes</param>
		/// <param name="strXMLFile">XML File</param>
		/// <returns></returns>

		public string getAttributeXml(string strAttribute, string strXMLFile)
		{
			try
			{
				XmlDocument xmlDoc = new XmlDocument();
				XmlNodeList   xmlNode; 
				xmlDoc.LoadXml(strXMLFile);
				xmlNode = xmlDoc.DocumentElement.GetElementsByTagName("TABLE");
				string strValue = "";						
				int iCount = 0;
				foreach(XmlNode _node in xmlNode)
				{			
					foreach(XmlAttribute  _attrib  in _node.Attributes)
					{
						if (_node.Attributes[iCount].Name == strAttribute)
						{
							strValue= _node.Attributes[iCount].Value ;
							if(strValue != "")
							{
								return strValue;
							}
							break;
						}						
						iCount++;
					}
				}
				return strValue;
			}
			catch(Exception )
			{
				return "null";
			}
		}//end of getNodeText
	
		#endregion
	}
}
