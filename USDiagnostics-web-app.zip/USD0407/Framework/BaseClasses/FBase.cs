
#region  Page Level Comments

/*******************************************************************************************
/*File Name	      :			FacadeBase.cs
 *Project Name    :			USD 1.0
 *Object          :			FacadeBase
 *Purpose         :			
 *Author          :			desayya.namala
 *Date            :			13-5-2006 
 *ModuleName      :			Baseclasses
 *This file is provided as part of Zaxis-USD project.
 *Copyright � 2004-07, Zaxis-USD Technologies, All rights reserved
 * ************************************ Revision History************************************
 *
 *  Date            Done by             Method             Change Description

*******************************************************************************************/

#endregion

#region  NameSpace Declaration

//System NameSpaces

using System;
using System.Data;
using System.Reflection;
using System.Configuration;
using System.Collections;
using System.Runtime.Remoting;
using System.Runtime.Remoting.Channels;
using System.Runtime.Remoting.Channels.Http;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

//Zaxis-USD NameSpaces
using Zaxis.Definitions;
using Zaxis.Common;
//using Zaxis.Common;

#endregion


namespace Zaxis.BaseClasses
{

	/// <summary>
	/// Provides System Specific functionality like initializing and committing the transactions
	/// and also calls the PostEentSuccess and PostEventFailurs based on the response status.
	/// </summary>

	[Serializable()]
	public class FBase : IDisposable
	{

		#region Local Variables

		private CommonBase commonbase = null;
		private BusinessData businessdata = null;
		//static FRemoteBase remotebase;

		#endregion

		#region Business Properties
		
		/// <summary>
		/// Sets or Gets the BusinessData Object
		/// </summary>
		public BusinessData BusinessData
		{
			set
			{
				businessdata = value;
			}
			get
			{
				return businessdata;
			}
		}


		/// <summary>
		/// Returns Remote server URI
		/// </summary>
		static private string RemoteServer
		{
			get
			{
				return ConfigurationSettings.AppSettings["RemoteServer"];
			}
		}


		/// <summary>
		/// Returns Serviced server URI
		/// </summary>
		static private string ServicedServer
		{
			get
			{
				return ConfigurationSettings.AppSettings["ServicedServer"];
			}
		}

		#endregion

		#region Constructor

		/// <summary>
		/// Empty Constructor
		/// </summary>

		static FBase()
		{
			if(RemoteServer.Length > 0)
			{
				// create and register our custom HTTP channel
				// that uses the binary formatter
				Hashtable properties = new Hashtable();
				properties["name"] = "HttpBinary";

				BinaryClientFormatterSinkProvider formatter = 
					new BinaryClientFormatterSinkProvider();

				HttpChannel channel = new HttpChannel(properties, formatter, null);

				ChannelServices.RegisterChannel(channel);
				RemotingConfiguration.RegisterWellKnownClientType(
					typeof(BaseClasses.FRemoteBase), 
					RemoteServer);
			}
		}

		#endregion

		#region Initialize

		private void Initialize(BusinessData businessdata)
		{
			commonbase = new CommonBase();
			businessdata.Transaction = commonbase.GetTransaction();
			commonbase = null;
		}
		
		#endregion
		
		#region Validate Response

		/// <summary>
		/// This method commits or rollbacks the transaction based on the response object status
		/// and also call the PostEentSuccess/PostEventFailure methods
		/// </summary>
		/// <param name="businessdata">Business Data Object</param>
		/// <returns>Reruns Result in the form of Response Object </returns>

		public Response Validate(BusinessData businessdata)
		{
			Response response = null;
			Zaxis.Common.CommonAB objCommon = new  Zaxis.Common.CommonAB();
			if(ConfigurationSettings.AppSettings["TransactionSupport"].ToString()=="ADO.NET")
			{
				if (businessdata.Response.Status.Equals(Definitions.Common.Status.Success))
				{
					businessdata.Transaction.Commit();
					// Calling Post Event Success 
					objCommon.PostEventSuccess(businessdata.OldEntity, businessdata.NewEntity, businessdata.HashValues);
				}
				else
				{
					businessdata.Transaction.Rollback();
					// Calling Post Event Failure 
					objCommon.PostEventFailure(businessdata.Response.ExceptionObject, businessdata.HashValues);
				}
			}

			response = businessdata.Response;

			// Clearing the objects
			objCommon = null;
			businessdata = null;

			return response;
		}

		#endregion

		#region Dispose

		/// <summary>
		/// This object will be cleaned up by the Dispose method.
		/// Therefore, you should call GC.SupressFinalize to
		/// take this object off the finalization queue 
		/// and prevent finalization code for this object
		/// from executing a second time.
		/// </summary>

		public void Dispose()
		{
			GC.SuppressFinalize(this);
		}

		#endregion
		
		#region Save 

		/// <summary>
		/// Calls the Facade class CRUD Methods based on the BusinessData.Method
		/// </summary>
		/// <remarks>
		/// <para>
		/// Calling this method starts the save operation, causing the object
		/// to be inserted, updated or deleted within the database based on the
		/// object's current state.
		/// </para>
		/// </para>
		/// </remarks>
		/// <returns>Response object contains execution status of the object</returns>
		public Response Save(BusinessData businessdata)
		{
//			if(IsTransactionalMethod(Zaxis.Definitions.Common.GetMethod(
//				this.GetType(), businessdata.MethodName)))
			if (ServicedServer.Length >0)
			{
				FServiceBase servicebase = new FServiceBase();
				Response response = (Response)servicebase.Create(this, businessdata);
				servicebase.Dispose();
				return response;
			}
			else
			{
				//Initialize(businessdata);
				FRemoteBase remotebase = new FRemoteBase();
				Response response = (Response)remotebase.Create(this, businessdata);
				//Validate(businessdata);
				remotebase.Dispose();
				return response;
			}
		}

		#endregion
		
		#region Get Dataset
		
		/// <summary>
		/// Called by a factory method in a Facade class to retrieve
		/// an Dataset, which is loaded with values from the database.
		/// </summary>
		/// <param name="module">Name of the module</param>
		/// <param name="queryName">Name of the query to access</param>
		/// <param name="whereString">Where string in the form of XML</param>
		/// <returns>Dataset populated with values from the database</returns>
		public DataSet GetDataset(string module, string queryName, string whereString)
		{
			return FRemoteBase.GetDataset(module, queryName, whereString);
		}
		
		/// <summary>
		/// Called by a factory method in a Facade class to retrieve
		/// an Dataset, which is loaded with values from the database.
		/// </summary>
		/// <param name="module">Name of the module</param>
		/// <param name="queryName">Name of the query to access</param>
		/// <param name="whereString">Where string in the form of XML</param>
		/// <param name="transaction">Tranasaction Objecct</param>
		/// <returns>Dataset populated with values from the database</returns>
		public DataSet GetDataset(string module, System.Collections.ArrayList queryName, string whereString)
		{
			return FRemoteBase.GetDataset(module, queryName, whereString);
		}


		#endregion

		#region Helper Methods

		/// <summary>
		/// 
		/// </summary>
		/// <param name="method">Method info object</param>
		/// <returns>True/False</returns>
		static private bool IsTransactionalMethod(MethodInfo method)
		{
			return Attribute.IsDefined(method, typeof(TransactionalAttribute));
		}

		#endregion

	}
}
