#region  Page Level Comments

//File Name		: FRemoteBase
//Project		: USD 1.0
//Object		: FRemoteBase
//Purpose		: This can used for accessing the Facade class remmotely
//Author		: N. Desayya
//Date			: 13-05-2006
//Module Name	: BaseClasses
//This file is provided as part of the Zaxis-USD project
//Copyright (C) 2004-06, Zaxus Technologies , All rights reserved
//*********************** Revision History ****************************************************************
//'***********************************************************************************************************

#endregion

#region  NameSpace Declaration

//System NameSpaces
using System;
using System.Reflection;
using System.Data;
using System.Text;
using System.Configuration;

//Zaxis-USD NameSpaces
using Zaxis.Definitions;
using Zaxis.DataAccess;
using Zaxis.Common;


#endregion

namespace Zaxis.BaseClasses
{
	/// <summary>
	/// Summary description for FRemoteBase.
	/// </summary>
	public class FRemoteBase : MarshalByRefObject, IDisposable
	{
		#region Local Variables

		private CommonBase commonbase = null;

		#endregion

		#region Initialize

		/// <summary>
		/// This method will initialize the transaction and 
		/// assign it to Business object
		/// </summary>
		/// <param name="businessdata"></param>
		private void Initialize(BusinessData businessdata)
		{
			commonbase = new CommonBase();
			businessdata.NewEntity = ReplaceQuotes(businessdata.NewEntity);
			businessdata.Transaction = commonbase.GetTransaction();
			commonbase = null;
		}
		
		#endregion
		
		#region Validate Response

		/// <summary>
		/// This method commits or rollbacks the transaction based on the response object status
		/// and also call the PostEentSuccess/PostEventFailure methods
		/// </summary>
		/// <param name="businessdata">Business Data Object</param>
		/// <returns>Reruns Result in the form of Response Object </returns>

		public Response Validate(BusinessData businessdata)
		{
			Response response = null;
			//Zaxis.Common.CommonAB objCommon = new  Zaxis.Common.CommonAB();
			if (businessdata.Response.Status.Equals(Definitions.Common.Status.Success))
			{
				businessdata.Transaction.Commit();
				// Calling Post Event Success 
				//objCommon.PostEventSuccess(businessdata.OldEntity, businessdata.NewEntity, businessdata.HashValues);
			}
			else
			{
				businessdata.Transaction.Rollback();
				// Calling Post Event Failure 
				//objCommon.PostEventFailure(businessdata.Response.ExceptionObject, businessdata.HashValues);
			}

			response = businessdata.Response;

			// Clearing the objects
			//objCommon = null;
			businessdata = null;

			return response;
		}

		#endregion

		
		#region CRUD Methods

		/// <summary>
		/// Called by a factory method in a business class to create 
		/// a new object, which is loaded with default
		/// values from the database.
		/// </summary>
		/// <param name="criteria"></param>
		/// <param name="businessdata"></param>
		/// <returns></returns>
		public  object Create(object criteria, BusinessData businessdata)
		{
			Initialize(businessdata);
			System.Diagnostics.EventLog.WriteEntry("Application", "In Fremobase Create");
			// create an instance of the business object
			//object fbase = Definitions.Common.CreateBusinessObject(criteria);

			// tell the business object to fetch its data
			Definitions.Common.CallMethod(criteria, businessdata.MethodName, businessdata);
			return Validate(businessdata);
		}


		#endregion

		#region Fetch Methods

		/// <summary>
		/// Called by a factory method in a Facade class to retrieve
		/// an Dataset, which is loaded with values from the database.
		/// </summary>
		/// <param name="module">Name of the module</param>
		/// <param name="queryName">Name of the query to access</param>
		/// <param name="whereString">Where string in the form of XML</param>
		/// <returns>Dataset populated with values from the database</returns>
		public static DataSet GetDataset(string module, string queryName, string whereString)
		{
			IQueryAccess iQueryAccess = GetQueryHelper(module);
			string strQuery = iQueryAccess.GetQueryString(queryName, whereString);
			
			iQueryAccess = null;
			DataSet dsReturn = null;
			try
			{
				dsReturn = ExecuteDataset(strQuery);
			}
			catch(Exception ex)
			{
				throw ex;
			}
			return dsReturn;
		}

		/// <summary>
		/// Called by a factory method in a Facade class to retrieve
		/// an Dataset, which is loaded with values from the database.
		/// </summary>
		/// <param name="module">Name of the module</param>
		/// <param name="queryName">Name of the query to access</param>
		/// <param name="whereString">Where string in the form of XML</param>
		/// <param name="transaction">Tranasaction Objecct</param>
		/// <returns>Dataset populated with values from the database</returns>
		public static DataSet GetDataset(string module, string queryName, string whereString, IDbTransaction transaction)
		{
			IQueryAccess iQueryAccess = GetQueryHelper(module);
			string strQuery = iQueryAccess.GetQueryString(queryName, whereString);
			iQueryAccess = null;

			DataSet dataSet = new DataSet();
			IDataReader datareader = null;
			DAL dal = new DAL();
			try
			{
				datareader = dal.ExecuteReader(transaction, CommandType.Text, strQuery);

				if (datareader != null)
				{
					DataTable schemaTable = datareader.GetSchemaTable();
					DataTable dataTable = new DataTable();

					if ( schemaTable != null )
					{
						// A query returning records was executed

						for ( int i = 0; i < schemaTable.Rows.Count; i++ )
						{
							DataRow dataRow = schemaTable.Rows[ i ];
							// Create a column name that is unique in the data table
							string columnName = ( string )dataRow[ "ColumnName" ]; //+ "<C" + i + "/>";
							// Add the column definition to the data table
							DataColumn column = new DataColumn( columnName, ( Type )dataRow[ "DataType" ] );
							dataTable.Columns.Add( column );
						}

						dataSet.Tables.Add( dataTable );

						// Fill the data table we just created

						while ( datareader.Read() )
						{
							DataRow dataRow = dataTable.NewRow();

							for ( int i = 0; i < datareader.FieldCount; i++ )
								dataRow[ i ] = datareader.GetValue( i );

							dataTable.Rows.Add( dataRow );
						}
						datareader.Close();
					}
				}
			}
			catch(Exception ex)
			{
				throw ex;
			}
			return dataSet;
		}

		/// <summary>
		///  this methods executes and returns the dataset against the module
		/// </summary>
		/// <param name="module" type="string">
		///		Name of the Module
		/// </param>
		/// <param name="queryName" type="ArrayList">
		///		List of the Queries as Array List
		/// </param>
		/// <param name="whereString" type="string">
		///		Where Condition as string in XMLFormat
		/// </param>
		/// <returns>DataSet</returns>
		public static DataSet GetDataset(string module, System.Collections.ArrayList queryName, string whereString)
		{
			IQueryAccess iQueryAccess = GetQueryHelper(module);
			string strQuery = iQueryAccess.GetQueryString(queryName, whereString);
			iQueryAccess = null;

			DataSet dsReturn = null;
			try
			{
				dsReturn = ExecuteDataset(strQuery);
			}
			catch(Exception ex)
			{
				throw ex;
			}
			return dsReturn;
		}
		
		
		#endregion

		#region Query Helper

		/// <summary>
		///  for getting the Query Helper Object
		/// </summary>
		/// <param name="module" type="string">
		///		Name of module 
		/// </param>
		/// <returns>IQueryAccess Object</returns>
		
		private static IQueryAccess GetQueryHelper(string module)
		{
			StringBuilder sbClassName = new StringBuilder("Zaxis-USD.");
			StringBuilder sbPath = new StringBuilder();
			
			sbClassName.Append(module);
			sbClassName.Append(".QueryHelper");
			
			sbPath.Append(sbClassName.ToString());
			sbClassName.Append(".");
			sbClassName.Append(ConfigurationSettings.AppSettings["QueryHelper"]);
			return (Zaxis.Definitions.IQueryAccess)Assembly.Load(sbPath.ToString()).CreateInstance(sbClassName.ToString());
		}

		/// <summary>
		///  this private methods executes and returns the dataset against the query
		/// </summary>
		/// <param name="query" type="string">
		///		Sql Select Query
		/// </param>
		/// <returns>DataSet</returns>
		
		private static DataSet ExecuteDataset(string query)
		{
			DAL dal = new DAL();
			 
			DataSet dsReturn = null; 
			try
			{
				dsReturn = dal.ExecuteDataset(CommandType.Text, query);
			}
			catch(Exception ex)
			{
				dal = null;
				throw ex;
			}
			dal = null;
			return dsReturn;
		}

		#endregion

		#region Dispose

		/// <summary>
		/// This object will be cleaned up by the Dispose method.
		/// Therefore, you should call GC.SupressFinalize to
		/// take this object off the finalization queue 
		/// and prevent finalization code for this object
		/// from executing a second time.
		/// </summary>

		public void Dispose()
		{
			GC.SuppressFinalize(this);
		}

		#endregion

		#region Replace Single Quote
		
		public static DataSet ReplaceQuotes(DataSet dsData)
		{
			int iTableCount = dsData.Tables.Count;
			int iRowCount = 0;
			DataRow drRowData;
			// loof through tables
			for(int iTblCount = 0; iTblCount < iTableCount; iTblCount++)
			{	
				iRowCount = dsData.Tables[iTblCount].Rows.Count;
				// loof through Rows
				for(int iRCount = 0; iRCount < iRowCount; iRCount++)
				{
					drRowData = dsData.Tables[iTblCount].Rows[iRCount];
					// Iterating through Columns
					for(int iCCount = 0; iCCount < drRowData.ItemArray.Length; iCCount++)
					{
						string strRowValue = drRowData[iCCount].ToString();  
						// re
						int iindex = strRowValue.IndexOf("'");
						if(iindex!=-1)
						{
							strRowValue = strRowValue.Replace("'", "''"); 
							drRowData[iCCount] = strRowValue;
						}
					}
				}
			}
			return dsData;
		}
		#endregion
	}
}
