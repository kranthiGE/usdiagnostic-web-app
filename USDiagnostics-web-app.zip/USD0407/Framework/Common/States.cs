#region Page Level Comments

//File Name		: States
//Project		: eXensys 3.0
//Object		: Zaxis.Common
//Purpose		: 
//Author		: N. Dasayya
//Date			: 26-9-2005
//Module Name	: Common
//This file is provided as part of the Z-Axis project
//Copyright � 2004-06, Z-Axis Techonologies, All rights reserved
//*********************** Revision History ****************************************************************
//	Date            Done by             Change Description
//'***********************************************************************************************************

#endregion

#region Namespace Declaration

// System Namespaces
using System;

#endregion

namespace Zaxis.Common
{
	/// <summary>
	/// Summary description for States.
	/// </summary>
	
	public class States
	{

		#region Module Codes

		public const string MM =  "MM";
		public const string DynamicForms = "DF";
		public const string HRToursTravels = "HRTT";
		public const string HRRecruitment = "HRRecruit";
		public const string HRMaster = "HRM";
		public const string HRAdvanceLoan = "HRAdv";
		public const string WORKFLOW = "WF";
		public const string SALES = "SALES";
		public const string SECURITY = "SEC";
		public const string HRPolicy = "HRPolicy";
		public const string POS = "POS";
		public const string HREmployeeInfo = "HREI";
		public const string GLOBALPARAMETERS = "GP";
		public const string HRLeaves = "HRLeaves";
		public const string REPORTS = "Reports";
		public const string HR = "HR";
		public const string MANUFACTURING = "MFG";
		public const string TAXATION = "TX";
		public const string HRConfigurator = "HRConfig";
		public const string HRPayroll = "HRPayroll";
		public const string PURCHASE = "PURCHASE";
		public const string ACCOUNTS = "FA";
		public const string SERVICES = "SRV";
		public const string QAQC = "QAC";
		public const string FIXEDASSETS = "AM";
		public const string FINANCIALS = "FIN";
		#endregion 
 		
		#region WSStates

		/// <summary>
		/// Provides WFStates Information
		/// </summary>
		
		public enum WFStates
		{ 
			Open,
			SubmittedToWF,
			InProgress,
			Accepted,
			Rejected,
			Differ,
			Recalled,
			Cancel
		}

		#endregion

		#region PSStates

		/// <summary>
		/// Provides PSStates Information
		/// </summary>
		
		public enum PSStates
		{ 
			Active,
			InActive,
			Closed,
			InProgress,
			Pending,
			Open,
			Cancelled,
			Confirmed
		}

		#endregion

	}
}
