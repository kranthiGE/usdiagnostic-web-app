
#region  Page Level Comments

/*******************************************************************************************
/*File Name	      :			DALBase.cs
 *Project Name    :			eXensys 3.0
 *Object          :			DALBAse
 *Purpose         :			
 *Author          :			desayya.namala
 *Date            :			12-5-2006 
 *ModuleName      :			
 *This file is provided as part of Z-Axis  project.
 *Copyright � 2004-06, Z-Axis Techonologies, All rights reserved
 * ************************************ Revision History************************************
 * Modified By	      Date           Description
 *
 *******************************************************************************************/

#endregion

#region  NameSpace Declaration

//System NameSpaces
using System;
using System.Reflection;
using System.Configuration;
using System.Data;
using System.Text; 
using System.IO; 

//eXensys NameSpaces
using Zaxis.Definitions;
using Microsoft.Practices.EnterpriseLibrary.Data;   
#endregion


namespace Zaxis.DataAccess
{

	/// <summary>
	/// This class provides the base functionality to the DAL
	/// </summary>

	public class DALBase
	{
		
		#region Default Constructor
		
		/// <summary>
		/// Empty Constructor
		/// </summary>
		protected IDBAccess  idbAccess; 

		public Microsoft.Practices.EnterpriseLibrary.Data.Database  dbInstance;   
		public DALBase()
		{		
			Interface();
		}

		#endregion

		#region  Local Variable Declaration

		public static string strDatabase = ConfigurationSettings.AppSettings["Helper"].ToString();
		//protected IDBAccess idbAccess = null;
		
		#endregion

		#region Check Null
		
		/// <summary>
		/// this method checks the null values
		/// </summary>
		/// <param name="dr">object</param>
		/// <returns>string</returns>
		
		public string CheckNull(object dr)
		{

			if(dr == System.DBNull.Value)
			{
				return "null";
			}
			else
				return dr.ToString();
			
		}

		#endregion

		#region DateToDB

		/// <summary>
		/// Returns the DateTime as string
		/// </summary>
		/// <returns>DateTime as string</returns>

		public string DateToDB()
		{
			DateTime TheDate ;
			string strDateTime = "";
			TheDate = DateTime.Now ;
			
			switch(strDatabase)
			{
				case "SqlHelper" :
					strDateTime = "'" + TheDate.Year.ToString() + "-" + TheDate.Month.ToString().PadLeft(2, '0') + "-" + TheDate.Day.ToString().PadLeft(2, '0') + " " + TheDate.Hour.ToString().PadLeft(2, '0') + ":" + TheDate.Minute.ToString().PadLeft(2, '0') + ":" + TheDate.Second.ToString().PadLeft(2, '0') + ".000" + "'";
					break;

				case "OracleHelper":
					strDateTime = TheDate.Year.ToString() + "-" + TheDate.Month.ToString().PadLeft(2, '0') + "-" + TheDate.Day.ToString().PadLeft(2, '0') + " " + TheDate.Hour.ToString().PadLeft(2, '0') + ":" + TheDate.Minute.ToString().PadLeft(2, '0') + ":" + TheDate.Second.ToString().PadLeft(2, '0');
					strDateTime = "TO_DATE('" + strDateTime + "', 'YYYY-MM-DD HH24:MI:SS')";
					break;
			}
			//return "'" + strDateTime + "'";
			return strDateTime;
		}

		/// <summary>
		/// Returns the DateTime as string
		/// </summary>
		/// <param name="dr">Object</param>
		/// <returns>DateTime as string</returns>


		public string DateToDB(object dr)
		{
			if(dr.ToString() == "")                              
				return "null";                              

			string strDate = dr.ToString();
			DateTime TheDate ;
			string strDateTime = "";
			if (strDate.Equals("") ||  strDate.Equals(null))
				TheDate = DateTime.Now ;
			else
				TheDate = Convert.ToDateTime(strDate);

			switch(strDatabase)
			{
				case "SqlHelper" :
					strDateTime = "'" + TheDate.Year.ToString() + "-" + TheDate.Month.ToString().PadLeft(2, '0') + "-" + TheDate.Day.ToString().PadLeft(2, '0') + " " + TheDate.Hour.ToString().PadLeft(2, '0') + ":" + TheDate.Minute.ToString().PadLeft(2, '0') + ":" + TheDate.Second.ToString().PadLeft(2, '0') + ".000" + "'";
					break;

				case "OracleHelper":
					strDateTime = TheDate.Year.ToString() + "-" + TheDate.Month.ToString().PadLeft(2, '0') + "-" + TheDate.Day.ToString().PadLeft(2, '0') + " " + TheDate.Hour.ToString().PadLeft(2, '0') + ":" + TheDate.Minute.ToString().PadLeft(2, '0') + ":" + TheDate.Second.ToString().PadLeft(2, '0');
					strDateTime = "TO_DATE('" + strDateTime + "', 'YYYY-MM-DD HH24:MI:SS')";
					break;
			}
//			return "'" + strDateTime + "'";
			return strDateTime ;
		}

		#endregion

		#region Interface

		/// <summary>
		/// This method provides the specified DAL object based on the configuration by using reflection
		/// </summary>

		public void Interface()
		{
			// Retrieves the number data member.
			/// Look up the DAL implementation we should be using
			//string path = "Holool.eXensys.DAL";
			//string path = "eXensys.DAL";
//			string className = path + "." + strDatabase;//".OracleHelper" ; //
//			// Using the evidence given in the config file load the appropriate assembly and class
//			idbAccess = (Holool.Common.AB.DataAccess.IDAL.IDBAccess)Assembly.Load(path).CreateInstance(className);

			//idbAccess = (Zaxis.Definitions.IDBAccess )Assembly.Load(path).CreateInstance(className);

			dbInstance = DatabaseFactory.CreateDatabase();
			

		}

		#endregion

		#region GetPhoto
		/// <summary>
		/// This method converts 
		/// </summary>
		public  byte[] GetPhoto(string filePath)
		{
			FileStream fs = new FileStream(filePath, FileMode.Open, FileAccess.Read);
			BinaryReader br = new BinaryReader(fs);
			byte[] photo = br.ReadBytes((int)fs.Length);
			br.Close();
			fs.Close();
			return photo;
		}
		#endregion       

		#region ConvertToByte
		
		/// <summary>
		/// This method converts given string to Binary Format		
		/// </summary>
		/// <param name="strToConvert"></param>
		/// <returns>Array Of Bytes</returns>
		public byte[] ConvertToByte(string strToConvert)
		{
			byte[] bytByte = new byte[strToConvert.Length]; 			            
			Encoding.ASCII.GetBytes(strToConvert.ToCharArray(),0,strToConvert.Length,bytByte,0);
			return bytByte;
		}
		#endregion

		#region ConvertToString
		/// <summary>
		/// This method converts given array of bytes to a string		
		/// </summary>
		/// <param name="bytes"></param>
		/// <returns>string</returns>
		public string ConvertToString(byte[] bytes)
		{
			string str = "";
			str = Encoding.ASCII.GetString(bytes,0,bytes.Length);
			return str;
		}        
		#endregion
   
		
	}
}
