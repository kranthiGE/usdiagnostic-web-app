#region  Page Level Comments

/*******************************************************************************************
/*File Name	      :			DAL.cs
 *Project Name    :			eXensys 3.0
 *Object          :			Data Access Layer
 *Purpose         :			
 *Author          :			desayya.namala
 *Date            :			12-20-2004
 *ModuleName      :			
 *This file is provided as part of Z-Axis  project.
 *Copyright � 2004-06, Z-Axis techonologies, All rights reserved
 * ************************************ Revision History************************************
 * Modified By	      Date           Description
 *
 *******************************************************************************************/

#endregion

#region  NameSpace Declaration

//System NameSpaces
using System;
using System.Data;
using System.Xml;
using System.Xml.Xsl;
using System.Xml.XPath;
using System.Configuration;
using System.Data.SqlClient;
//using System.Data.OracleClient;
using System.Data.OleDb;      
using System.Collections;  

using System.Text;  
using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;


//eXensys NameSpaces
using Zaxis.Definitions;

#endregion

namespace Zaxis.DataAccess
{
	/// <summary>
	/// Summary description for DAL.
	/// </summary>
	
	public class DAL : DALBase
	{
	
		//public Database dbInstance;

		#region Default Constructor
		
		/// <summary>
		/// Empty Constructor
		/// </summary>
		
		public DAL()
		{
		  //dbInstance = DatabaseFactory.CreateDatabase();  	
		}

		#endregion
		
		#region Local Variables

		public static DataSet ds;
		string strPath = ConfigurationSettings.AppSettings["ApplicationPath"];
		
		#endregion
		
		#region Commented
//		#region Added by Desayya
//		public int Create(DataSet dsFormData, bool bDBTransaction, string strWhere)
//		{
//			int iTableCount = dsFormData.Tables.Count;
//			int iRowCoount = 0;
//			int iColumnCount = 0;
//			string strQuery = "";
//			string strTableName = "";
//
//			if (idbAccess == null)
//				throw new Exception("No Connection");
//			
//			IDbConnection con = idbAccess.GetConnection();
//			IDbTransaction trans = null;
//			
//			//calling AssignDBNames for Data Column Name mapping
//			//AssignDBNames(ref dsFormData);
//			
//			if (bDBTransaction)
//				trans = con.BeginTransaction();
//			int iResult = 0;
//			try
//			{
//				for(int iTblCount = 0; iTblCount < iTableCount; iTblCount++)
//				{
//					iRowCoount = dsFormData.Tables[iTblCount].Rows.Count;
//					iColumnCount = dsFormData.Tables[iTblCount].Columns.Count;
//					strTableName = dsFormData.Tables[iTblCount].TableName;
//
//					for(int iRowCnt = 0; iRowCnt < iRowCoount; iRowCnt++)
//					{
//						DataRow drFormData = dsFormData.Tables[iTblCount].Rows[iRowCnt];
//						if (drFormData["Status"].ToString().Equals("Insert"))
//							strQuery = GenerateInsertString(drFormData, iColumnCount, strTableName);
//
//						iResult = idbAccess.ExecuteNonQuery(trans, CommandType.Text, strQuery);
//					}
//				}
//				trans.Commit();
//			}
//			catch(Exception ex)
//			{
//				//				ExceptionManager.Publish(ex);
//				//				throw new CustomException();]
//				string s=ex.ToString(); 
//			}
//			return 0;
//		}
//
//		public  DataSet GetDataSet(CommandType commType, string commText, string strFormName)
//		{	
////			DataSet dsResult = idbAccess.ExecuteDataset(commType,  SQLHelper.SQLSerer.GetQueryString("Employee"));	
////			//AssignScreenNames(ref dsResult);
//			return null;
//		}
//
//		private int WithTransaction(DataSet dsFormData, IDbTransaction trans)
//		{
//			return 0;
//		}
//
//		private int WithoutTransaction(DataSet dsFormData)
//		{
//			return 0;
//		}
//
//		private string GenerateInsertString(DataRow drFormData, int iColumnCount, string strTableName)
//		{
//			XPathDocument xpathDoc = new XPathDocument(strPath + "\\" + strTableName + ".xml");
//			XPathNodeIterator xpathIterator =  null;
//			string strColumns = "";
//			string strColumnsData = "";
//			string strColumName = "";
//			string strDataColum = "";
//
//			xpathIterator = xpathDoc.CreateNavigator().Select("//Control");
//			while (xpathIterator.MoveNext()) 
//			{
//				// get the control name
//				strColumName = xpathIterator.Current.GetAttribute("Name", "");
//				strDataColum = xpathIterator.Current.GetAttribute("DataColumn", "");
//				
//				// append the correct filled out information
//				strColumns = strColumns + strDataColum + ", ";
//				for(int iColCount = 0; iColCount < iColumnCount ; iColCount++)
//				{
//					if (strColumName.Equals(drFormData.Table.Columns[iColCount].ColumnName))
//						strColumnsData = strColumnsData + ", '" +  drFormData[iColCount].ToString() + "'";	
//				}
//			}
//			strColumns  = strColumns.Remove(strColumns.LastIndexOf(","), 1);
//			
//			strColumnsData = strColumnsData.Substring(1);
//			//			strColumnsData  = strColumnsData.Substring(strColumnsData.IndexOf(",") + 1);  
//			//			strColumnsData = "'" + GUID + "' ," + strColumnsData;
//			
//			return "insert into  " + strTableName + " (" + strColumns + ") values (" + strColumnsData + ")";
//		}
//
//		private int Update()
//		{
//			return 0;
//		}
//
//		private int Delete()
//		{
//			return 0;
//		}
//
//		private void AssignDBNames(ref DataSet dsFormData)
//		{
//
//			int iTableCount = 0;
//			string strTableName = "";
//			XPathNodeIterator xpathIterator =  null;
//
//			
//			if ((iTableCount = dsFormData.Tables.Count) > 0)
//			{
//				for(int iTblCount = 0; iTblCount < iTableCount; iTblCount++)
//				{
//					strTableName = dsFormData.Tables[iTblCount].TableName;
//					XPathDocument xpathDoc = new XPathDocument(strPath + "\\" + strTableName + ".xml");
//				
//					int iColCount = dsFormData.Tables[iTblCount].Columns.Count;
//					for(int i = 0; i < iColCount; i++)
//					{
//						xpathIterator = xpathDoc.CreateNavigator().Select("//Control");
//						while (xpathIterator.MoveNext()) 
//						{
//							// get the control name
//							string strColumName = xpathIterator.Current.GetAttribute("Name", "");
//							string strDataColum = xpathIterator.Current.GetAttribute("DataColumn", "");
//
//							if (dsFormData.Tables[iTblCount].Columns[i].ColumnName.Equals(strColumName))
//							{
//								dsFormData.Tables[iTblCount].Columns[i].ColumnName = strDataColum;
//								break;
//							}
//						}
//					}
//				}
//			}
//		}
//
//		private void AssignScreenNames(ref DataSet dsFormData)
//		{
//			int iTableCount = 0;
//			string strTableName = "";
//			string strPath = ConfigurationSettings.AppSettings["ApplicationPath"];
//			XPathNodeIterator xpathIterator =  null;
//			if ((iTableCount = dsFormData.Tables.Count) > 0)
//			{
//				for(int iTblCount = 0; iTblCount < iTableCount; iTblCount++)
//				{
//					strTableName = dsFormData.Tables[iTblCount].TableName;
//					XPathDocument xpathDoc = new XPathDocument(strPath + "\\" + strTableName + ".xml");
//					
//					int iColCount = dsFormData.Tables[iTblCount].Columns.Count;
//					for(int i = 0; i < iColCount; i++)
//					{
//						xpathIterator = xpathDoc.CreateNavigator().Select("//Control");
//						while (xpathIterator.MoveNext()) 
//						{
//							// get the control name
//							string strColumName = xpathIterator.Current.GetAttribute("Name", "");
//							string strDataColum = xpathIterator.Current.GetAttribute("DataColumn", "");
//
//							if (dsFormData.Tables[iTblCount].Columns[i].ColumnName.Equals(strDataColum))
//							{
//								dsFormData.Tables[iTblCount].Columns[i].ColumnName = strColumName;
//								break;
//							}
//						}
//					}
//				}
//			}
//
//		}
//
//		#endregion
		#endregion

		#region GetConnection

		/// <summary>
		/// Executes a Method that takes no parameters and returns a connection object based on the configuraion settings 
		/// </summary>
		/// <remarks>
		/// e.g.:  
		///  IdbConnection idbCon = dalObj.GetConnection();
		///<returns>A connection object containing the connection string generated by the method</returns>  
	
		public IDbConnection GetConnection()
		{			
		   IDbConnection idbCon;
           idbCon = dbInstance.GetConnection();
		   idbCon.Open(); 			
		   return idbCon;
		}
		#endregion 
		
		#region GetTransaction
		/// <summary>
		/// Executes a Method that takes no parameters and returns a transaction object based on the connection object
		/// </summary>
		/// <remarks>
		/// e.g.:  
		/// IdbTransaction  idbTrans = dalObj.GetTransaction();
		///<returns>A transaction object containing the connection string generated by the method</returns>
		public IDbTransaction GetTransaction()
		{			
			IDbTransaction idbTrans; 
			IDbConnection idbCon = GetConnection();
			idbTrans = idbCon.BeginTransaction(); 
			return  idbTrans;
		}   
		#endregion				
	
		#region ExecuteDataSet

		/// <summary>
		/// Execute a IDbCommand (that returns a resultset and takes no parameters) against the database specified in 
		/// the connection 
		/// </summary>
		/// <remarks>
		/// e.g.:  
		///  DataSet ds = ExecuteDataset(conn, CommandType.StoredProcedure, "getProductsByCategory",new SqlParameter("@CategoryID",1));
		/// </remarks>
		/// <param name="connection">A valid  IDbConnection</param>
		/// <param name="commandType">The CommandType (stored procedure, text, etc.)</param>
		/// <param name="commandText">The stored procedure name or command name</param>
		/// <param name="commandParameters">An array of IDataParameter used to execute the command</param>
		/// <returns>A dataset containing the resultset generated by the command</returns>
		public   DataSet ExecuteDataset(string storedProcedureName, params object[] commandParameters)
		{			
			return dbInstance.ExecuteDataSet(storedProcedureName,commandParameters);
		}

		/// <summary>
		/// Execute a IDbCommand (that returns a resultset and takes no parameters) against the database specified in 
		/// the IDbTransaction 
		/// </summary>
		/// <remarks>
		/// e.g.:  
		///  DataSet ds = ExecuteDataset(trans, CommandType.StoredProcedure, "getProductsByCategory",new SqlParameter("@CategoryID",1));
		/// </remarks>
		/// <param name="transaction">A valid  IDbTransaction</param>
		/// <param name="commandType">The CommandType (stored procedure, text, etc.)</param>
		/// <param name="commandText">The stored procedure name or command name</param>
		/// <param name="commandParameters">An array of IDataParameter used to execute the command</param>
		/// <returns>A dataset containing the resultset generated by the command</returns>

		public   DataSet ExecuteDataset(DBCommandWrapper dbCommmandWrapper,IDbTransaction transaction)
		{					
			return dbInstance.ExecuteDataSet(dbCommmandWrapper,transaction);  			
		}

		/// <summary>
		/// Execute a IDbCommand (that returns a resultset and takes no parameters) against the database specified in 
		/// the connection. 
		/// </summary>
		/// <remarks>
		/// e.g.:  
		///  DataSet ds = ExecuteDataset(trans, CommandType.StoredProcedure, "GetOrders",);
		/// </remarks>
		/// <param name="transaction">A valid  IDbTransaction</param>
		/// <param name="commandType">The CommandType (stored procedure, text, etc.)</param>
		/// <param name="commandText">The stored procedure name or command name</param>
		
		/// <returns>A dataset containing the resultset generated by the command</returns>

		public   DataSet ExecuteDataset(IDbTransaction transaction, CommandType  commandType, string commandText)
		{				
			return dbInstance.ExecuteDataSet(transaction,CommandType.Text,commandText);  			
		}


		/// <summary>
		/// Execute a IDbCommand (that returns a resultset and takes no parameters) against the database specified in 
		/// the connection. 
		/// </summary>
		/// <remarks>
		/// e.g.:  
		///  DataSet ds = ExecuteDataset(conn, CommandType.StoredProcedure, "GetOrders");
		/// </remarks>
		/// <param name="connection">A valid connection string for a IDbConnection</param>
		/// <param name="commandType">The CommandType (stored procedure, text, etc.)</param>
		/// <param name="commandText">The stored procedure name or command name</param>
		/// <returns>A dataset containing the resultset generated by the command</returns>

		public   DataSet ExecuteDataset(DBCommandWrapper dbCommmandWrapper)
		{
			
			return dbInstance.ExecuteDataSet(dbCommmandWrapper); 
		}

		/// <summary>
		/// Execute a IDbCommand (that returns a resultset and takes no parameters) against the database specified in 
		/// the connection. 
		/// </summary>
		/// <remarks>
		/// e.g.:  
		///  DataSet ds = ExecuteDataset(CommandType.StoredProcedure, "getProductsByCategory",new SqlParameter("@CategoryID",1));
		/// </remarks>
		/// <param name="commandType">The CommandType (stored procedure, text, etc.)</param>
		/// <param name="commandText">The stored procedure name or command name</param>
		/// <param name="commandParameters">An array of IDataParameter used to execute the command</param>
		/// <returns>A dataset containing the resultset generated by the command</returns>
		public   DataSet ExecuteDataset(IDbTransaction transaction, string storedProcedureName, params object[] commandParameters)
		{		    
			return dbInstance.ExecuteDataSet(transaction,storedProcedureName,commandParameters); 
		}

		/// <summary>
		/// Execute a IDbCommand (that returns a resultset and takes no parameters) against the database specified in 
		/// the connection. 
		/// </summary>
		/// <remarks>
		/// e.g.:  
		///  DataSet ds = ExecuteDataset(CommandType.StoredProcedure, "getOrders");
		/// </remarks>
		/// <param name="commandType">The CommandType (stored procedure, text, etc.)</param>
		/// <param name="commandText">The stored procedure name or command name</param>
		/// <returns>A dataset containing the resultset generated by the command</returns>

		public   DataSet ExecuteDataset(CommandType  commandType, string commandText)
		{ 			
			return dbInstance.ExecuteDataSet(commandType,commandText); 	 			
		}

		public DataSet ExecuteDataset(CommandType commandType, string commandText,params IDataParameter[] commandParameters)
		{

			if(commandType == CommandType.StoredProcedure)
			{
				int iParamLength = commandParameters.Length;
				object[] paramArray = new object[iParamLength];
				for(int i=0;i<iParamLength;++i)
				{
					paramArray[i] = commandParameters[i].Value;
				}

				return dbInstance.ExecuteDataSet(commandText,paramArray); 
			}
			else
			{
				return null;
			}

		}
      
		#endregion

		#region ExecuteReader

		/// <summary>
		/// Create and prepare a IDbCommand, and call ExecuteReader with the appropriate CommandBehavior.
		/// </summary>
		/// <remarks>
		/// If we created and opened the connection, we want the connection to be closed when the DataReader is closed.
		/// 
		/// If the caller provided the connection, we want to leave it to them to manage.
		/// </remarks>
		/// <param name="connection">A valid IDbConnection, on which to execute this command</param>
		/// <param name="transaction">A valid IDbTransaction, or 'null'</param>
		/// <param name="commandType">The CommandType (stored procedure, text, etc.)</param>
		/// <param name="commandText">The stored procedure name or command</param>
		/// <param name="commandParameters">An array of IDbParameters to be associated with the command or 'null' if no parameters are required</param>
		/// <param name="connectionOwnership">Indicates whether the connection parameter was provided by the caller, or created by DAL</param>
		/// <returns>IDataReader containing the results of the command</returns>
		public   IDataReader ExecuteReader(string  storedProcedureName, object[] commandParameters)
		{			
			return dbInstance.ExecuteReader(storedProcedureName,commandParameters);			
		}

		
		/// <summary>
		/// Execute a IDbCommand (that returns a resultset and takes no parameters) against the database specified in 
		/// the connection. 
		/// </summary>
		/// <remarks>
		/// e.g.:  
		///  SqlDataReader dr = ExecuteReader(conn, CommandType.StoredProcedure, "getProductsByCategory",new SplParameter("@CategoryId",1));
		/// </remarks>
		/// <param name="connection">A valid  IDbConnection</param>
		/// <param name="commandType">The CommandType (stored procedure, text, etc.)</param>
		/// <param name="commandText">The stored procedure name or command</param>
		/// <param name="commandParameters">An array of IDataParameter used to execute the command</param> 
		/// <returns>A IDataReader containing the resultset generated by the command</returns>
		public   IDataReader ExecuteReader(DBCommandWrapper dbCommmandWrapper,IDbTransaction transaction)
		{
			return dbInstance.ExecuteReader(dbCommmandWrapper,transaction);
		}
   
		/// <summary>
		/// Execute a IDbCommand (that returns a resultset and takes no parameters) against the database specified in 
		/// the connection. 
		/// </summary>
		/// <remarks>
		/// e.g.:  
		///  SqlDataReader dr = ExecuteReader(trans, CommandType.StoredProcedure, "getProductsByCategory",new SqlParameter("@CategoryID",1));
		/// </remarks>
		/// <param name="transaction">A valid  IDbtransaction</param> 
		/// <param name="commandType">The CommandType (stored procedure, text, etc.)</param>
		/// <param name="commandText">The stored procedure name or command</param>
		/// <param name="commandParameters">An array of IDbParameters to be associated with the command or 'null' if no parameters are required</param> 
		/// <returns>A IDataReader containing the resultset generated by the command</returns>
      
		public   IDataReader ExecuteReader(IDbTransaction transaction, CommandType  commandType, string commandText)
		{			
			return dbInstance.ExecuteReader(transaction,commandType,commandText); 
		}
		/// <summary>
		/// Execute a IDbCommand (that returns a resultset and takes no parameters) against the database specified in 
		/// the connection. 
		/// </summary>
		/// <remarks>
		/// e.g.:  
		///  SqlDataReader dr = ExecuteReader(conn, CommandType.StoredProcedure, "GetOrders");
		/// </remarks>
		/// <param name="connection">A valid  IDbConnection</param>
		/// <param name="commandType">The CommandType (stored procedure, text, etc.)</param>
		/// <param name="commandText">The stored procedure name or command</param>
		/// <returns>A IDataReader containing the resultset generated by the command</returns>

		public   IDataReader ExecuteReader(DBCommandWrapper dbCommmandWrapper)
		{
			return dbInstance.ExecuteReader(dbCommmandWrapper);
		}

		/// <summary>
		/// Execute a IDbCommand (that returns a resultset and takes no parameters) against the database specified in 
		/// the connection. 
		/// </summary>
		/// <remarks>
		/// e.g.:  
		///  SqlDataReader dr = ExecuteReader(CommandType.StoredProcedure, "getProductsByCategory",new SqlParameter("@CategoryID",1));
		/// </remarks>
		/// <param name="commandType">The CommandType (stored procedure, text, etc.)</param>
		/// <param name="commandText">The stored procedure name or command</param>
		/// <param name="commandParameters">An array of IDbParameters to be associated with the command or 'null' if no parameters are required</param> 
		/// <returns>A IDataReader containing the resultset generated by the command</returns>
		public   IDataReader ExecuteReader(IDbTransaction transaction, string storedProcedureName, params object[] commandParameters)
		{
			return dbInstance.ExecuteReader(transaction, storedProcedureName,commandParameters);
		}
		/// <summary>
		/// Execute a IDbCommand (that returns a resultset and takes no parameters) against the database specified in 
		/// the connection. 
		/// </summary>
		/// <remarks>
		/// e.g.:  
		///  SqlDataReader dr = ExecuteReader(CommandType.StoredProcedure, "GetOrders");
		/// </remarks>
		/// <param name="commandType">The CommandType (stored procedure, text, etc.)</param>
		/// <param name="commandText">The stored procedure name or command</param>
		/// <returns>A IDataReader containing the resultset generated by the command</returns>
		public   IDataReader ExecuteReader(CommandType commandType, string commandText)
		{			
			return dbInstance.ExecuteReader(commandType,commandText); 			
		}
		

		public IDataReader ExecuteReader(CommandType commandType, string commandText,params IDataParameter[] commandParameters)
		{
			if(commandType == CommandType.StoredProcedure)
			{
				int iParamLength = commandParameters.Length;
				object[] paramArray = new object[iParamLength];
				for(int i=0;i<iParamLength;++i)
				{
					paramArray[i] = commandParameters[i].Value;
				}

				return dbInstance.ExecuteReader(commandText,paramArray); 
			}
			else
			{
				return null;
			}
		}

		#endregion

		#region ExecuteScalar
		/// <summary>
		/// Execute a IDbCommand (that returns a 1x1 resultset and takes no parameters) against the database specified in 
		/// the connection. 
		/// </summary>
		/// <remarks>
		/// e.g.:  
		///  int orderCount = (int)ExecuteScalar(trans, CommandType.StoredProcedure, "getProductsByCategory",new SqlParameter("@CategoryID",1));
		/// </remarks>
		/// <param name="transaction">A valid  IDbtransaction</param> 
		/// <param name="commandType">The CommandType (stored procedure, text, etc.)</param>
		/// <param name="commandText">The stored procedure name or command</param>
		/// <param name="commandParameters">An array of IDbParameters to be associated with the command or 'null' if no parameters are required</param> 
		/// <returns>An object containing the value in the 1x1 resultset generated by the command</returns>

		public  object ExecuteScalar(string  storedProcedureName, object[] commandParameters)
		{
			
			return dbInstance.ExecuteScalar(storedProcedureName,commandParameters);
		}
		/// <summary>
		/// Execute a IDbCommand (that returns a 1x1 resultset and takes no parameters) against the database specified in 
		/// the connection. 
		/// </summary>
		/// <remarks>
		/// e.g.:  
		///  int orderCount = (int)ExecuteScalar(trans, CommandType.StoredProcedure, "getOrders");
		/// </remarks>
		/// <param name="transaction">A valid  IDbtransaction</param> 
		/// <param name="commandType">The CommandType (stored procedure, text, etc.)</param>
		/// <param name="commandText">The stored procedure name or command</param>
		/// <returns>An object containing the value in the 1x1 resultset generated by the command</returns>
           
		public  object ExecuteScalar(DBCommandWrapper dbCommmandWrapper,IDbTransaction transaction)
		{			
			return dbInstance.ExecuteScalar(dbCommmandWrapper,transaction);
		}
		/// <summary>
		/// Execute a IDbCommand (that returns a 1x1 resultset and takes no parameters) against the database specified in 
		/// the connection. 
		/// </summary>
		/// <remarks>
		/// e.g.:  
		///  int orderCount = (int)ExecuteScalar(conn, CommandType.StoredProcedure, "getProductsByCategory",new SqlParameter("@CategoryID",1));
		/// </remarks>
		/// <param name="connection">A valid  IDbConnection</param>
		/// <param name="commandType">The CommandType (stored procedure, text, etc.)</param>
		/// <param name="commandText">The stored procedure name or command</param>
		/// <param name="commandParameters">An array of IDbParameters to be associated with the command or 'null' if no parameters are required</param> 
		/// <returns>An object containing the value in the 1x1 resultset generated by the command</returns>
		public  object ExecuteScalar(IDbTransaction transaction, CommandType  commandType, string commandText)
		{			
			return dbInstance.ExecuteScalar(transaction,commandType,commandText);
		}
		/// <summary>
		/// Execute a IDbCommand (that returns a 1x1 resultset and takes no parameters) against the database specified in 
		/// the connection. 
		/// </summary>
		/// <remarks>
		/// e.g.:  
		///  int orderCount = (int)ExecuteScalar(conn, CommandType.StoredProcedure, "getOrders");
		/// </remarks>
		/// <param name="connection">A valid  IDbConnection</param>
		/// <param name="commandType">The CommandType (stored procedure, text, etc.)</param>
		/// <param name="commandText">The stored procedure name or command</param>
		/// <returns>An object containing the value in the 1x1 resultset generated by the command</returns>
         
		public  object ExecuteScalar(DBCommandWrapper dbCommmandWrapper)
		{			
			return dbInstance.ExecuteScalar(dbCommmandWrapper);
		}
		/// <summary>
		/// Execute a IDbCommand (that returns a 1x1 resultset and takes no parameters) against the database specified in 
		/// the connection. 
		/// </summary>
		/// <remarks>
		/// e.g.:  
		///  int orderCount = (int)ExecuteScalar(CommandType.StoredProcedure, "getProductsByCategory",new SqlParameter("@CategoryID",1));
		/// </remarks>
		/// <param name="commandType">The CommandType (stored procedure, text, etc.)</param>
		/// <param name="commandText">The stored procedure name or command</param>
		/// <param name="commandParameters">An array of IDbParameters to be associated with the command or 'null' if no parameters are required</param> 
		/// <returns>An object containing the value in the 1x1 resultset generated by the command</returns>

		public  object ExecuteScalar(IDbTransaction transaction, string storedProcedureName, params object[] commandParameters)
		{ 			
			return dbInstance.ExecuteScalar(transaction,storedProcedureName,commandParameters);
		}
		/// <summary>
		/// Execute a IDbCommand (that returns a 1x1 resultset and takes no parameters) against the database specified in 
		/// the connection. 
		/// </summary>
		/// <remarks>
		/// e.g.:  
		///  int orderCount = (int)ExecuteScalar(CommandType.StoredProcedure, "getOrders");
		/// </remarks>
		/// <param name="commandType">The CommandType (stored procedure, text, etc.)</param>
		/// <param name="commandText">The stored procedure name or command</param>
		/// <returns>An object containing the value in the 1x1 resultset generated by the command</returns>

		public  object ExecuteScalar(CommandType commandType, string commandText)
		{			
			return dbInstance.ExecuteScalar(commandType,commandText);
		}



		public  object ExecuteScalar(CommandType commandType, string commandText,params IDataParameter[] commandParameters)
		{		
			if(commandType == CommandType.StoredProcedure)
			{
				int iParamLength = commandParameters.Length;
				object[] paramArray = new object[iParamLength];
				for(int i=0;i<iParamLength;++i)
				{
					paramArray[i] = commandParameters[i].Value;
				}

				return dbInstance.ExecuteScalar(commandText,paramArray); 
			}
			else
			{
				return null;
			}
		}


//		public object[] ExecuteScalar(string StoredProcedureName,IDataParameter[] Params)
//		{
//			ArrayList alResult = new ArrayList();
//			int iParamsLength = Params.Length;
//			Database db = DatabaseFactory.CreateDatabase();
//			DBCommandWrapper dbCommandWrapper = db.GetStoredProcCommandWrapper(StoredProcedureName);
//			for(int i=0;i<iParamsLength;i++)
//			{
//				if(Params[i].Direction == ParameterDirection.Input)				
//				{
//					dbCommandWrapper.AddInParameter(Params[i].ParameterName, Params[i].DbType, Params[i].Value);										
//				}
//				else
//				{
//					alResult.Add(Params[i].ParameterName);
//					dbCommandWrapper.AddOutParameter(Params[i].ParameterName,Params[i].DbType,50);
//				}			            
//			}
//			
//			db.ExecuteScalar(dbCommandWrapper);
//			object[] obResult = new object[alResult.Count];
//			for(int j=0;j<alResult.Count;j++)
//			{
//				obResult[j] = dbCommandWrapper.GetParameterValue(alResult[j].ToString());
//
//			} 
//			alResult = null;
//			db = null;
//			dbCommandWrapper = null;
//			return obResult;						
//		}

		#endregion		

		#region ExecuteNonQuery

		/// <summary>
		/// Execute a IDbCommand (that returns no resultset) against the specified IDbConnection 
		/// using the provided parameters.
		/// </summary>
		/// <remarks>
		/// e.g.:  
		///  int result = ExecuteNonQuery(trans, CommandType.StoredProcedure, "PublishOrders", new SqlParameter("@prodid", 24));
		/// </remarks>
		/// <param name="transaction">A valid IDbTransaction</param> 
		/// <param name="commandType">The CommandType (stored procedure, text, etc.)</param>
		/// <param name="commandText">The stored procedure name or command</param>
		/// <param name="commandParameters">An array of IDataParamters used to execute the command</param>
		/// <returns>An int representing the number of rows affected by the command</returns>
		public int ExecuteNonQuery(string  storedProcedureName, object[] commandParameters)
		{       
			return dbInstance.ExecuteNonQuery(storedProcedureName,commandParameters);
		}

		/// <summary>
		/// Execute a IDbCommand (that returns no resultset) against the specified IDbConnection 
		/// using the provided parameters.
		/// </summary>
		/// <remarks>
		/// e.g.:  
		///  int result = ExecuteNonQuery(trans, CommandType.StoredProcedure, "PublishOrders");
		/// </remarks>
		/// <param name="transaction">A valid IDbTransaction</param> 
		/// <param name="commandType">The CommandType (stored procedure, text, etc.)</param>
		/// <param name="commandText">The stored procedure name or command</param>
		/// <returns>An int representing the number of rows affected by the command</returns>

		public void ExecuteNonQuery(DBCommandWrapper dbCommmandWrapper,IDbTransaction transaction)
		{			
			dbInstance.ExecuteNonQuery(dbCommmandWrapper,transaction); 			
		}
		/// <summary>
		/// Execute a IDbCommand (that returns no resultset) against the specified IDbConnection 
		/// using the provided parameters.
		/// </summary>
		/// <remarks>
		/// e.g.:  
		///  int result = ExecuteNonQuery(trans, CommandType.StoredProcedure, "PublishOrders", new SqlParameter("@prodid", 24));
		/// </remarks>
		/// <param name="connection">A valid IDbConnection</param> 
		/// <param name="commandType">The CommandType (stored procedure, text, etc.)</param>
		/// <param name="commandText">The stored procedure name or command</param>
		/// <param name="commandParameters">An array of IDataParamters used to execute the command</param>
		/// <returns>An int representing the number of rows affected by the command</returns>

		public int ExecuteNonQuery(IDbTransaction transaction, CommandType  commandType, string commandText)
		{
//			if(transaction == null)
//             return dbInstance.ExecuteNonQuery(commandType,commandText); 
//			else
			 return dbInstance.ExecuteNonQuery(transaction,commandType,commandText);
		}
		/// <summary>
		/// Execute a IDbCommand (that returns no resultset) against the specified IDbConnection 
		/// using the provided parameters.
		/// </summary>
		/// <remarks>
		/// e.g.:  
		///  int result = ExecuteNonQuery(conn, CommandType.StoredProcedure, "PublishOrders");
		/// </remarks>
		/// <param name="connection">A valid IDbTransaction</param> 
		/// <param name="commandType">The CommandType (stored procedure, text, etc.)</param>
		/// <param name="commandText">The stored procedure name or command</param>
		/// <returns>An int representing the number of rows affected by the command</returns>

		public void ExecuteNonQuery(DBCommandWrapper dbCommmandWrapper)
		{
			dbInstance.ExecuteNonQuery(dbCommmandWrapper);
		}
		/// <summary>
		/// Execute a IDbCommand (that returns no resultset) against the specified IDbConnection 
		/// using the provided parameters.
		/// </summary>
		/// <remarks>
		/// e.g.:  
		///  int result = ExecuteNonQuery( CommandType.StoredProcedure, "PublishOrders", new SqlParameter("@prodid", 24));
		/// </remarks>
		/// <param name="commandType">The CommandType (stored procedure, text, etc.)</param>
		/// <param name="commandText">The stored procedure name or command</param>
		/// <param name="commandParameters">An array of IDataParamters used to execute the command</param>
		/// <returns>An int representing the number of rows affected by the command</returns>

		public int ExecuteNonQuery(IDbTransaction transaction, string storedProcedureName, params object[] commandParameters)
		{
			return dbInstance.ExecuteNonQuery(transaction,storedProcedureName,commandParameters);
		}
		/// <summary>
		/// Execute a IDbCommand (that returns no resultset) against the specified IDbConnection 
		/// using the provided parameters.
		/// </summary>
		/// <remarks>
		/// e.g.:  
		/// int result = ExecuteNonQuery(connString, CommandType.StoredProcedure, "PublishOrders");
		/// </remarks>
		/// <param name="commandType">The CommandType (stored procedure, text, etc.)</param>
		/// <param name="commandText">The stored procedure name or command</param>
		/// <returns>An int representing the number of rows affected by the command</returns>

		public int ExecuteNonQuery(CommandType commandType, string commandText)
		{			
			return dbInstance.ExecuteNonQuery(commandType,commandText); 		
		}


		public  int ExecuteNonQuery(CommandType commandType, string commandText,params IDataParameter[] commandParameters)
		{            
			if(commandType == CommandType.StoredProcedure)
			{
				int iParamLength = commandParameters.Length;
				object[] paramArray = new object[iParamLength];
				for(int i=0;i<iParamLength;++i)
				{
					paramArray[i] = commandParameters[i].Value;
				}

				return dbInstance.ExecuteNonQuery(commandText,paramArray); 
			}
			else
			{
				return 0;
			}
		}
		#endregion  
	
		#region ExecuteDataTable
 
		public   DataTable  ExecuteDatatable(CommandType  commandType, string commandText)
		{			
			return idbAccess.ExecuteDatatable(commandType, commandText);
		}


		#endregion


	}
}
