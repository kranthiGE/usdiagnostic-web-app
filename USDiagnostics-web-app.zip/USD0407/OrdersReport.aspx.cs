
#region  Page Level Comments

/*******************************************************************************************
/*File Name	      :			OrdersReport.cs
 *Project Name    :			USD 1.0
 *Object          :			Code Behind
 *Purpose         :			
 *Author          :			Kiran J
 *Date            :			1-6-2006 
 *ModuleName      :			USD
 *This file is provided as part of Zaxis-USD project.
 *Copyright � 2004-07, Zaxis-USD Technologies, All rights reserved
 * ************************************ Revision History************************************
 *
 *  Date            Done by             Method             Change Description

*******************************************************************************************/

#endregion

#region NameSpaces

using System.Data;
using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

//Zaxis Namespaces
using Zaxis.USD.BusinessLogic;
using Zaxis.Definitions;

#endregion

namespace Zaxis.USD.Web
{
	/// <summary>
	/// Summary description for OrdersReport.
	/// </summary>
	public class OrdersReport : PageBase
	{
		#region Local Variables

		protected System.Web.UI.WebControls.Label lblFromDate;
		protected System.Web.UI.WebControls.TextBox txtFromDate;
		protected System.Web.UI.WebControls.Label lblToDate;
		protected System.Web.UI.WebControls.TextBox txtToDate;
		protected System.Web.UI.WebControls.Button btnExportExcel;
		protected System.Web.UI.WebControls.Button btnGet;
		protected string strTodaysDate = string.Empty;

		TechnicianBLL oBll = new TechnicianBLL();
		protected System.Web.UI.WebControls.DataGrid dgOrdersRpt;
		protected static int iGridItemCount = 0;
		Hashtable htParamValues = new Hashtable(); 
		private static DataTable dtDatable = null;

		#endregion

		#region Page Load

		/// <summary>
		/// Page Load Event
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void Page_Load(object sender, System.EventArgs e)
		{
			bCheckUserID = true;
			// Put user code to initialize the page here
			PermissionID = "11";
		    
			strTodaysDate = DateTime.Now.Date.ToString();
			// Put user code to initialize the page here
			btnGet.Attributes.Add("onclick","return RequiredValidation();");

			htParamValues.Add("@To_Date",txtToDate.Text);
			htParamValues.Add("@From_Date",txtFromDate.Text);
			btnExportExcel.Attributes.Add("onclick","return ValidateExport();");
		}

		#endregion

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.btnGet.Click += new System.EventHandler(this.btnGet_Click);
			this.btnExportExcel.Click += new System.EventHandler(this.btnExportExcel_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		#region Build Grid

		/// <summary>
		/// Build Grid 
		/// </summary>
		private void BuildGrid()
		{
			try
			{
				dtDatable =  oBll.GetData("sp_USD_OrdersReport",htParamValues).Tables[0];
				dgOrdersRpt.DataSource = dtDatable;
				dgOrdersRpt.DataBind();

				iGridItemCount = dgOrdersRpt.Items.Count;
			}
			catch(Exception ex)
			{
				string strEx = ex.Message;
			}
		}

		#endregion

		#region Export to Excel

		/// <summary>
		/// Exports the Data to EXcel
		/// </summary>
		private void ExcellExport()
		{
			
			try
			{
				//export to excel

				Response.Clear();
				Response.Buffer= true;
				Response.ContentType = "application/vnd.ms-excel";
				Response.Charset = "";
				this.EnableViewState = false;

				System.IO.StringWriter oStringWriter = new System.IO.StringWriter();
				System.Web.UI.HtmlTextWriter oHtmlTextWriter = new System.Web.UI.HtmlTextWriter(oStringWriter);

				//this.ClearControls(dgOrdersRpt);
				dgOrdersRpt.RenderControl(oHtmlTextWriter);

				Response.Write(oStringWriter.ToString());

				Response.End();
			}
			catch(Exception ex)
			{
				string strEx = ex.Message;
				Response.End();
				
			}

		}
		
		/// <summary>
		/// Export Button Click Event
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void btnExportExcel_Click(object sender, System.EventArgs e)
		{
			ExcellExport();

		}

		#endregion		

		#region Get Button Click

		/// <summary>
		/// Show the Report based on the dates
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void btnGet_Click(object sender, System.EventArgs e)
		{
			BuildGrid();
		}

		#endregion

	}
}
