SET NOCOUNT ON
-- Restricts volume of output to errors and
-- messages that use the PRINT function

PRINT 'CREATING User dbo'
if not exists (select * from dbo.sysusers where name = N'dbo' and uid < 16382)
	EXEC sp_grantdbaccess N'dbo'
GO



PRINT 'CREATING User innovia'
if not exists (select * from dbo.sysusers where name = N'innovia' and uid < 16382)
	EXEC sp_grantdbaccess N'innovia', N'innovia'
GO



PRINT 'CREATING TABLE Contact'
CREATE TABLE [Contact] (
	[ContactID] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[FirstName] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[MiddleName] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[LastName] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Sex] [int] NULL ,
	[Address1] [varchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Address2] [varchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[City] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[State] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Zip] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Country] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[HomePhone] [varchar] (15) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[WorkPhone] [varchar] (15) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[CellPhone] [varchar] (15) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Fax] [varchar] (15) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[EMail] [varchar] (15) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[URL] [varchar] (100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Buffer01] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Buffer02] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Buffer03] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Buffer04] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Buffer05] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[IsActive] [tinyint] NULL ,
	CONSTRAINT [PK_CONTACT_ContactID] PRIMARY KEY  CLUSTERED 
	(
		[ContactID]
	)  ON [PRIMARY] 
) ON [PRIMARY]
GO




PRINT 'CREATING TABLE Permission'
CREATE TABLE [Permission] (
	[PermissionID] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[Name] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Buffer01] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Buffer02] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Buffer03] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Buffer04] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Buffer05] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[IsActive] [tinyint] NULL ,
	CONSTRAINT [PK_Permission_PermissionID] PRIMARY KEY  CLUSTERED 
	(
		[PermissionID]
	)  ON [PRIMARY] 
) ON [PRIMARY]
GO




PRINT 'CREATING TABLE Role'
CREATE TABLE [Role] (
	[RoleID] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[Name] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Buffer01] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Buffer02] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Buffer03] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Buffer04] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Buffer05] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[IsActive] [tinyint] NULL ,
	CONSTRAINT [PK_Role_RoleID] PRIMARY KEY  CLUSTERED 
	(
		[RoleID]
	)  ON [PRIMARY] 
) ON [PRIMARY]
GO




PRINT 'CREATING TABLE Role_Permission'
CREATE TABLE [Role_Permission] (
	[RoleID] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[PermissionID] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Buffer01] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Buffer02] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Buffer03] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Buffer04] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Buffer05] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[IsActive] [tinyint] NULL ,
	CONSTRAINT [FK_Role_Permission_PermissionID] FOREIGN KEY 
	(
		[PermissionID]
	) REFERENCES [Permission] (
		[PermissionID]
	),
	CONSTRAINT [FK_Role_Permission_RoleID] FOREIGN KEY 
	(
		[RoleID]
	) REFERENCES [Role] (
		[RoleID]
	)
) ON [PRIMARY]
GO




PRINT 'CREATING TABLE UserInfo'
CREATE TABLE [UserInfo] (
	[UserID] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[LoginID] [varchar] (15) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Password] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Question] [varchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Answer] [varchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Technition] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[ModifyRecord] [tinyint] NULL ,
	[ContactID] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[CompanyID] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[BranchID] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Buffer01] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Buffer02] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Buffer03] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Buffer04] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Buffer05] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[IsActive] [tinyint] NULL ,
	CONSTRAINT [PK_User_UserID] PRIMARY KEY  CLUSTERED 
	(
		[UserID]
	)  ON [PRIMARY] ,
	CONSTRAINT [FK_UserInfo_Contact_ContactID] FOREIGN KEY 
	(
		[ContactID]
	) REFERENCES [Contact] (
		[ContactID]
	)
) ON [PRIMARY]
GO




PRINT 'CREATING TABLE User_Permission'
CREATE TABLE [User_Permission] (
	[UserID] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[PermissionID] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Buffer01] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Buffer02] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Buffer03] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Buffer04] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Buffer05] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[IsActive] [tinyint] NULL ,
	CONSTRAINT [FK_User_Permission_PermissionID] FOREIGN KEY 
	(
		[PermissionID]
	) REFERENCES [Permission] (
		[PermissionID]
	),
	CONSTRAINT [FK_User_Permission_UserID] FOREIGN KEY 
	(
		[UserID]
	) REFERENCES [UserInfo] (
		[UserID]
	)
) ON [PRIMARY]
GO




PRINT 'CREATING TABLE User_Role'
CREATE TABLE [User_Role] (
	[RoleID] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[UserID] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Buffer01] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Buffer02] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Buffer03] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Buffer04] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Buffer05] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[IsActive] [tinyint] NULL ,
	CONSTRAINT [FK_User_Role_RoleID] FOREIGN KEY 
	(
		[RoleID]
	) REFERENCES [Role] (
		[RoleID]
	),
	CONSTRAINT [FK_User_Role_UserID] FOREIGN KEY 
	(
		[UserID]
	) REFERENCES [UserInfo] (
		[UserID]
	)
) ON [PRIMARY]
GO




PRINT 'CREATING User Defined Function fUserPermissionCheck'
SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

create  FUNCTION fUserPermissionCheck (@userId VARCHAR(50), @permissionId VARCHAR(50))
RETURNS INT
AS
BEGIN
	DECLARE @intResult AS INT

	IF EXISTS (SELECT * FROM User_Permission WHERE IsActive=1 AND UserId=@userId AND PermissionId=@permissionId)
		SELECT @intResult = 1
	ELSE IF EXISTS (SELECT * FROM User_Role ur INNER JOIN Role_Permission rp 
				ON ur.RoleId=rp.RoleId AND ur.IsActive=1 AND rp.IsActive=1
			WHERE ur.UserId=@userId AND rp.PermissionId=@permissionId)
		SELECT @intResult = 1

	ELSE
		SELECT @intResult = 0

	RETURN @intResult
END


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO



PRINT 'CREATING TABLE CodeType'
CREATE TABLE [CodeType] (
	[CodeTypeID] [int] NOT NULL ,
	[CodeType] [varchar] (30) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Buffer01] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Buffer02] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Buffer03] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Buffer04] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Buffer05] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[IsActive] [tinyint] NULL ,
	CONSTRAINT [PK_CodeType_CodeTypeID] PRIMARY KEY  CLUSTERED 
	(
		[CodeTypeID]
	)  ON [PRIMARY] 
) ON [PRIMARY]
GO




PRINT 'CREATING TABLE Code'
CREATE TABLE [Code] (
	[CodeID] [int] NOT NULL ,
	[TypeID] [int] NULL ,
	[Seq] [int] NULL ,
	[Encode] [varchar] (15) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Decode] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Buffer01] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Buffer02] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Buffer03] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Buffer04] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Buffer05] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[IsActive] [tinyint] NULL ,
	CONSTRAINT [PK_Code_CodeID] PRIMARY KEY  CLUSTERED 
	(
		[CodeID]
	)  ON [PRIMARY] ,
	CONSTRAINT [FK_Code_CodeType_CodeTypeID] FOREIGN KEY 
	(
		[TypeID]
	) REFERENCES [CodeType] (
		[CodeTypeID]
	)
) ON [PRIMARY]
GO




PRINT 'CREATING TABLE Company'
CREATE TABLE [Company] (
	[CompanyID] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[CompanyName] [varchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Address] [varchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[ParentID] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Buffer01] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Buffer02] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Buffer03] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Buffer04] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Buffer05] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[IsActive] [tinyint] NULL ,
	CONSTRAINT [PK_Company_CompanyID] PRIMARY KEY  CLUSTERED 
	(
		[CompanyID]
	)  ON [PRIMARY] 
) ON [PRIMARY]
GO




PRINT 'CREATING TABLE dummy'
CREATE TABLE [dummy] (
	[sno] [varchar] (30) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[name] [varchar] (30) COLLATE SQL_Latin1_General_CP1_CI_AS NULL 
) ON [PRIMARY]
GO




PRINT 'CREATING TABLE History'
CREATE TABLE [History] (
	[HistoryID] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[ActionByID] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[ActionDate] [datetime] NULL ,
	[ActionID] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[SubjectID] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[PermissionID] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Description] [varchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	CONSTRAINT [PK_History_HistoryID] PRIMARY KEY  CLUSTERED 
	(
		[HistoryID]
	)  ON [PRIMARY] 
) ON [PRIMARY]
GO




PRINT 'CREATING TABLE Orders'
CREATE TABLE [Orders] (
	[OrderID] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[OrderNo] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[OrderDate] [datetime] NULL ,
	[Physician] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[OrderingNurse] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[SourceContactID] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[ContactTypeID] [int] NULL ,
	[Signature] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Diagnosis] [varchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[CompanyID] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[BranchID] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Buffer01] [int] IDENTITY (1, 1) NOT NULL ,
	[Buffer02] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Buffer03] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Buffer04] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Buffer05] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[IsActive] [tinyint] NULL ,
	CONSTRAINT [PK_Order_OrderID] PRIMARY KEY  CLUSTERED 
	(
		[OrderID]
	)  ON [PRIMARY] 
) ON [PRIMARY]
GO




PRINT 'CREATING TABLE Patient'
CREATE TABLE [Patient] (
	[PatientID] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[DOB] [datetime] NULL ,
	[SSN] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[MedicareNo] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[MedicaidNO] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[RoomNo] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[ContactID] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[PatientInsuranceCode] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[InsuranceContactID] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[CompanyID] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[BranchID] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Buffer01] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Buffer02] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Buffer03] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Buffer04] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Buffer05] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[IsActive] [tinyint] NULL ,
	[Comments] [varchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	CONSTRAINT [PK_Patient_PatientID] PRIMARY KEY  CLUSTERED 
	(
		[PatientID]
	)  ON [PRIMARY] ,
	CONSTRAINT [FK_Patinet_Contact_ContactID] FOREIGN KEY 
	(
		[ContactID]
	) REFERENCES [Contact] (
		[ContactID]
	),
	CONSTRAINT [FK_Patinet_Contact_InsuranceContactID] FOREIGN KEY 
	(
		[InsuranceContactID]
	) REFERENCES [Contact] (
		[ContactID]
	)
) ON [PRIMARY]
GO




PRINT 'CREATING TABLE Patient_Order'
CREATE TABLE [Patient_Order] (
	[PatientID] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[OrderID] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[IsActive] [tinyint] NULL 
) ON [PRIMARY]
GO




PRINT 'CREATING TABLE Procedures'
CREATE TABLE [Procedures] (
	[ProcedureID] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[Name] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[ProcedureCodeID] [int] NULL ,
	[Buffer01] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Buffer02] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Buffer03] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Buffer04] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Buffer05] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[IsActive] [tinyint] NULL ,
	CONSTRAINT [PK_Procedure_ProcedureID] PRIMARY KEY  CLUSTERED 
	(
		[ProcedureID]
	)  ON [PRIMARY] ,
	CONSTRAINT [FK_Procedure_Code_ProcedureCodeID] FOREIGN KEY 
	(
		[ProcedureCodeID]
	) REFERENCES [Code] (
		[CodeID]
	)
) ON [PRIMARY]
GO




PRINT 'CREATING TABLE Patient_Procedure'
CREATE TABLE [Patient_Procedure] (
	[PatientID] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[ProcedureID] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[OrderID] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[TechnicianID] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[DueDate] [datetime] NULL ,
	[TestDate] [datetime] NULL ,
	[PriorityID] [int] NULL ,
	[ZoneID] [int] NULL ,
	[Comments] [varchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[StatusID] [int] NULL ,
	[OrderTyp] [int] NULL ,
	[Buffer01] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Buffer02] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Buffer03] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Buffer04] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Buffer05] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[IsActive] [tinyint] NULL ,
	CONSTRAINT [FK_PatientProcedure_Order_OrderID] FOREIGN KEY 
	(
		[OrderID]
	) REFERENCES [Orders] (
		[OrderID]
	),
	CONSTRAINT [FK_PatientProcedure_PatientID] FOREIGN KEY 
	(
		[PatientID]
	) REFERENCES [Patient] (
		[PatientID]
	),
	CONSTRAINT [FK_PatientProcedure_PriorityID] FOREIGN KEY 
	(
		[PriorityID]
	) REFERENCES [Code] (
		[CodeID]
	),
	CONSTRAINT [FK_PatientProcedure_ProcedureID] FOREIGN KEY 
	(
		[ProcedureID]
	) REFERENCES [Procedures] (
		[ProcedureID]
	),
	CONSTRAINT [FK_PatientProcedure_StatusID] FOREIGN KEY 
	(
		[StatusID]
	) REFERENCES [Code] (
		[CodeID]
	),
	CONSTRAINT [FK_PatientProcedure_UserID] FOREIGN KEY 
	(
		[TechnicianID]
	) REFERENCES [UserInfo] (
		[UserID]
	)
) ON [PRIMARY]
GO




PRINT 'CREATING TABLE States'
CREATE TABLE [States] (
	[StateID] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[Name] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Description] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	CONSTRAINT [PK_States_StateID] PRIMARY KEY  CLUSTERED 
	(
		[StateID]
	)  ON [PRIMARY] 
) ON [PRIMARY]
GO




PRINT 'CREATING STORED PROCEDURE sp_USD_CEODashBoard_Consolidated'
SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

CREATE   procedure sp_USD_CEODashBoard_Consolidated as
DECLARE @OrderStatusId int
declare @OrderStatus varchar(50)


    create table #temptbl_ConsolidatedOrder_Status
    (
        OrderCount int,
        OrderStatus varchar(50)
        
    )


    DECLARE ConsolidatedOrder_Status CURSOR FOR
    select CodeId,Decode from Code where TypeId = 7


    OPEN ConsolidatedOrder_Status

    FETCH NEXT FROM ConsolidatedOrder_Status
    INTO @OrderStatusId,@OrderStatus

    WHILE @@FETCH_STATUS = 0
    BEGIN
        insert into #temptbl_ConsolidatedOrder_Status --(OrderCount,OrderStatus) values(@OrderStatusId,@OrderStatus)
        select  count(statusid) as OrderCount,@OrderStatus as Status from patient_procedure where statusid =  @OrderStatusId

        FETCH NEXT FROM ConsolidatedOrder_Status
        INTO @OrderStatusId,@OrderStatus
    END 



    CLOSE ConsolidatedOrder_Status
    DEALLOCATE ConsolidatedOrder_Status


    select OrderStatus as Status,OrderCount as Total   from #temptbl_ConsolidatedOrder_Status



GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO



PRINT 'CREATING STORED PROCEDURE sp_USD_CEODashBoard_ConsolidatedDisp'
SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO




/**
*   Auther : Kiran
*   Date   : 8-6-2006
*   Purpose:
*/


CREATE  procedure sp_USD_CEODashBoard_ConsolidatedDisp
(
    @Xvalue int,
    @Yvalye int
)
 as
    create table #temptbl_ConsolidatedOrder_PendVsDisp
    (
        OrderStatus varchar(50),
        OrderCount int
    )

    if @Xvalue is not null
    begin
        insert into #temptbl_ConsolidatedOrder_PendVsDisp
        select (select Decode from code where codeid = @Xvalue) as status,(select  count(statusid) as OrderCount from patient_procedure 
where statusid = @Xvalue ) as [Count] --from code
    end

    if @Yvalye is not null
    begin
        insert into #temptbl_ConsolidatedOrder_PendVsDisp
        select (select Decode from code where codeid = @Yvalye) as status,(select  count(statusid) as OrderCount from patient_procedure 
where statusid = @Yvalye ) as [Count] --from code
    end

    select OrderStatus as Status,OrderCount as Total  from #temptbl_ConsolidatedOrder_PendVsDisp


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO



PRINT 'CREATING STORED PROCEDURE sp_USD_CeoDashBoard_OrdersComp'
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


-------------

CREATE     procedure sp_USD_CeoDashBoard_OrdersComp
@From_Date varchar(10),
@To_Date varchar(10)
as

SELECT a.OrderNo, a.[Patient Name], a.[Test Name], a.[Test Type], a.[Order Date], a.[Order Time]
FROM
(SELECT DISTINCT o.OrderNo, c.FirstName AS [Patient Name], pro.Name AS [Test Name], 
	cod.Decode AS [Test Type], CONVERT(VARCHAR(10),pp.DueDate,101) AS [Order Date], 
	SUBSTRING(CONVERT(VARCHAR(16), pp.DueDate,120),12,5) AS [Order Time], pp.DueDate OrderDate
FROM Orders o INNER JOIN Patient_Procedure pp ON o.OrderID = pp.OrderID 
	INNER JOIN Patient p ON pp.PatientID = p.PatientID 
	INNER JOIN Contact c ON p.ContactID = c.ContactID 
	INNER JOIN Procedures pro ON pp.ProcedureID = pro.ProcedureID 
	INNER JOIN Code cod ON pro.ProcedureCodeID = cod.CodeID AND pp.StatusID = 25
	and convert(varchar(10), pp.DueDate, 120)  between @From_Date and @To_Date
) a
ORDER BY a.OrderDate DESC



GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO



PRINT 'CREATING STORED PROCEDURE sp_USD_CeoDashBoard_OrdersDisp'
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


CREATE     procedure   sp_USD_CeoDashBoard_OrdersDisp
	@From_Date varchar(10),
    	@To_Date varchar(10)
as

SELECT a.OrderNo, a.[Patient Name], a.[Test Name], a.[Test Type], a.[Order Date], a.[Order Time] 
FROM 
(SELECT DISTINCT o.OrderNo, c.FirstName AS [Patient Name], pro.Name AS [Test Name], cod.Decode AS [Test Type], 
	CONVERT(VARCHAR(10),pp.DueDate,101) AS [Order Date], SUBSTRING(CONVERT(VARCHAR(16), 
	pp.DueDate,120),12,5) AS [Order Time], pp.DueDate oOrderDate
FROM Orders o INNER JOIN Patient_Procedure pp ON o.OrderID = pp.OrderID 
	INNER JOIN Patient p ON pp.PatientID = p.PatientID 
	INNER JOIN Contact c ON p.ContactID = c.ContactID 
	INNER JOIN Procedures pro ON pp.ProcedureID = pro.ProcedureID 
	INNER JOIN Code cod ON pro.ProcedureCodeID = cod.CodeID AND pp.StatusID = 27
	and convert(varchar(10), pp.DueDate, 120)  between @From_Date and @To_Date
) a
ORDER BY a.oOrderDate DESC



GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO



PRINT 'CREATING STORED PROCEDURE sp_USD_CeoDashBoard_OrdersPend'
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


--------------------

CREATE     procedure sp_USD_CeoDashBoard_OrdersPend
@From_Date varchar(10),
@To_Date varchar(10)
as
SELECT a.OrderNo, a.[Patient Name], a.[Test Name], a.[Test Type], a.[Order Date], a.[Order Time]
FROM
(SELECT DISTINCT o.OrderNo, c.FirstName AS [Patient Name], pro.Name AS [Test Name], 
	cod.Decode AS [Test Type], CONVERT(VARCHAR(10),pp.DueDate,101) AS [Order Date], 
	SUBSTRING(CONVERT(VARCHAR(16), pp.DueDate,120),12,5) AS [Order Time],
	pp.DueDate OrderDate
FROM Orders o INNER JOIN Patient_Procedure pp ON o.OrderID = pp.OrderID 
	INNER JOIN Patient p ON pp.PatientID = p.PatientID 
	INNER JOIN Contact c ON p.ContactID = c.ContactID 
	INNER JOIN Procedures pro ON pp.ProcedureID = pro.ProcedureID 
	INNER JOIN Code cod ON pro.ProcedureCodeID = cod.CodeID AND pp.StatusID = 26
	and convert(varchar(10), pp.DueDate, 120)  between @From_Date and @To_Date
) a
ORDER BY a.OrderDate DESC


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO



PRINT 'CREATING STORED PROCEDURE sp_USD_CEODashBoard_OrderStatusBreakUp'
SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO



--select * from orders



--exec sp_USD_CEODashBoard_OrderStatusBreakUp '01/06/06','06/06/06'

CREATE   procedure sp_USD_CEODashBoard_OrderStatusBreakUp
(
    @From_Date varchar(12),
    @To_Date varchar(12)
--exec sp_USD_CEODashBoard_ConsolidatedDisp 25,26
)
 as
    create table #temptbl_ConsolidatedOrder_StatusParts
    (
        OrderStatus varchar(50),
        OrderCount int
    )

    if @From_Date is not null and  @To_Date is not null
    begin
        declare Order_Status_Partly cursor for
        select CodeId,Decode from Code where TypeId = 7

        declare @SattusId int
        declare @Status varchar(50)


        OPEN Order_Status_Partly

        FETCH NEXT FROM Order_Status_Partly
        INTO @SattusId,@Status

            WHILE @@FETCH_STATUS = 0
            BEGIN
	

                --select convert(varchar(12),orderdate,101) as odate from orders
        
                insert into #temptbl_ConsolidatedOrder_StatusParts
                select (select Decode from code where codeid = @SattusId) as status,(select  count(patient_procedure.statusid) as 
OrderCount from patient_procedure,orders  where patient_procedure.statusid = @SattusId  and patient_procedure.orderid = 
orders.orderid and  convert(varchar(12),orders.orderdate,101)  between convert(varchar(12),'06/01/06',101) and 
convert(varchar(12),'06/06/06',101) ) as [Count] --from code   patient_procedure.orderid = orders.orderid and
                --end

                FETCH NEXT FROM Order_Status_Partly INTO @SattusId,@Status

            END 
        CLOSE Order_Status_Partly
        DEALLOCATE Order_Status_Partly
    end

    select OrderStatus as Status,OrderCount as Total  from #temptbl_ConsolidatedOrder_StatusParts
    --drop table  #temptbl_ConsolidatedOrder_PendVsDisp

    
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO



PRINT 'CREATING STORED PROCEDURE sp_USD_CEODashBoard_OrderStatusCurYearVSLastYear'
SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO








--select * from orders



--exec sp_USD_CEODashBoard_OrderStatusBreakUp '01/06/06','06/06/06'

CREATE      procedure sp_USD_CEODashBoard_OrderStatusCurYearVSLastYear
 as

declare  @From_Date   datetime
declare   @To_Date  datetime
set @From_Date = CAST(CONVERT(VARCHAR(4),DATEADD(YEAR,-1,GETDATE()),120)+'01'+'01' AS DATETIME)
set @To_Date = CAST(CONVERT(VARCHAR(4),DATEADD(YEAR,-1,GETDATE()),120)+'12'+'31' AS DATETIME)

--select @From_Date as From_Date ,@To_Date as To_Date

    create table #temptbl_ConsolidatedOrder_StatusParts
    (
        OrderStatus varchar(50),
        OrderCount int
    )

    if @From_Date is not null and  @To_Date is not null
    begin
        declare Order_Status_Partly cursor for
        select CodeId,Decode from Code where TypeId = 7

        declare @SattusId int
        declare @Status varchar(50)


        OPEN Order_Status_Partly

        FETCH NEXT FROM Order_Status_Partly
        INTO @SattusId,@Status

            WHILE @@FETCH_STATUS = 0
            BEGIN
	

                --select convert(varchar(12),orderdate,101) as odate from orders
        
                insert into #temptbl_ConsolidatedOrder_StatusParts
                select (select Decode from code where codeid = @SattusId)+'(Last Year)' as status,(select  count(patient_procedure.statusid) as 
OrderCount from patient_procedure,orders  where patient_procedure.statusid = @SattusId  and patient_procedure.orderid = 
orders.orderid and  convert(varchar(12),orders.orderdate,120)  between convert(varchar(12),@From_Date,120) and 
convert(varchar(12),@To_Date,120) ) as [Count] --from code   patient_procedure.orderid = orders.orderid and
                --end

                FETCH NEXT FROM Order_Status_Partly INTO @SattusId,@Status

            END 
        CLOSE Order_Status_Partly
        DEALLOCATE Order_Status_Partly
    end

   -- select OrderStatus as Status,OrderCount as Total  from #temptbl_ConsolidatedOrder_StatusParts
    --drop table  #temptbl_ConsolidatedOrder_PendVsDisp

    








--declare  @From_Date   datetime
--declare   @To_Date  datetime
set @From_Date = CAST(CONVERT(VARCHAR(4),DATEADD(YEAR,0,GETDATE()),120)+'01'+'01' AS DATETIME)
set @To_Date = GETDATE()

--select @From_Date as From_Date ,@To_Date as To_Date

    
    if @From_Date is not null and  @To_Date is not null
    begin
        declare Order_Status_Partly cursor for
        select CodeId,Decode from Code where TypeId = 7

        --declare @SattusId int
        --declare @Status varchar(50)


        OPEN Order_Status_Partly

        FETCH NEXT FROM Order_Status_Partly
        INTO @SattusId,@Status

            WHILE @@FETCH_STATUS = 0
            BEGIN
	

                --select convert(varchar(12),orderdate,101) as odate from orders
        
                insert into #temptbl_ConsolidatedOrder_StatusParts
                select (select Decode from code where codeid = @SattusId)+'(Cur Year)' as status,(select  count(patient_procedure.statusid) as 
OrderCount from patient_procedure,orders  where patient_procedure.statusid = @SattusId  and patient_procedure.orderid = 
orders.orderid and  convert(varchar(12),orders.orderdate,120)  between convert(varchar(12),@From_Date,120) and 
convert(varchar(12),@To_Date,120) ) as [Count] --from code   patient_procedure.orderid = orders.orderid and
                --end

                FETCH NEXT FROM Order_Status_Partly INTO @SattusId,@Status

            END 
        CLOSE Order_Status_Partly
        DEALLOCATE Order_Status_Partly
    end

    select OrderStatus as Status,OrderCount as Total  from #temptbl_ConsolidatedOrder_StatusParts order by Status
    --drop table  #temptbl_ConsolidatedOrder_PendVsDisp

    













GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO



PRINT 'CREATING STORED PROCEDURE sp_USD_CEODashBoard_OrderStatusLastMonth'
SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO







--select * from orders



--exec sp_USD_CEODashBoard_OrderStatusBreakUp '01/06/06','06/06/06'

CREATE      procedure sp_USD_CEODashBoard_OrderStatusLastMonth
 as

declare  @From_Date   datetime
declare   @To_Date  datetime
set @From_Date = CAST(CONVERT(VARCHAR(8),DATEADD(MONTH,-1,GETDATE()),120)+'01' AS DATETIME)
set @To_Date = DATEADD(day, -datepart(day,getdate()), GetDate())

--select @From_Date as From_Date ,@To_Date as To_Date

    create table #temptbl_ConsolidatedOrder_StatusParts
    (
        OrderStatus varchar(50),
        OrderCount int
    )

    if @From_Date is not null and  @To_Date is not null
    begin
        declare Order_Status_Partly cursor for
        select CodeId,Decode from Code where TypeId = 7

        declare @SattusId int
        declare @Status varchar(50)


        OPEN Order_Status_Partly

        FETCH NEXT FROM Order_Status_Partly
        INTO @SattusId,@Status

            WHILE @@FETCH_STATUS = 0
            BEGIN
	

                --select convert(varchar(12),orderdate,101) as odate from orders
        
                insert into #temptbl_ConsolidatedOrder_StatusParts
                select (select Decode from code where codeid = @SattusId)+'(Last Month)' as status,(select  count(patient_procedure.statusid) as 
OrderCount from patient_procedure,orders  where patient_procedure.statusid = @SattusId  and patient_procedure.orderid = 
orders.orderid and  convert(varchar(12),orders.orderdate,101)  between convert(varchar(12),@From_Date,101) and 
convert(varchar(12),@To_Date,101) ) as [Count] --from code   patient_procedure.orderid = orders.orderid and
                --end

                FETCH NEXT FROM Order_Status_Partly INTO @SattusId,@Status

            END 
        CLOSE Order_Status_Partly
        DEALLOCATE Order_Status_Partly
    end

   -- select OrderStatus as Status,OrderCount as Total  from #temptbl_ConsolidatedOrder_StatusParts
    --drop table  #temptbl_ConsolidatedOrder_PendVsDisp

    








--declare  @From_Date   datetime
--declare   @To_Date  datetime
set @From_Date = CAST(CONVERT(VARCHAR(8),DATEADD(MONTH,0,GETDATE()),120)+'01' AS DATETIME)
set @To_Date = getdate()--DATEADD(day, -datepart(day,getdate()), GetDate())

--select @From_Date as From_Date ,@To_Date as To_Date

    
    if @From_Date is not null and  @To_Date is not null
    begin
        declare Order_Status_Partly cursor for
        select CodeId,Decode from Code where TypeId = 7

        --declare @SattusId int
        --declare @Status varchar(50)


        OPEN Order_Status_Partly

        FETCH NEXT FROM Order_Status_Partly
        INTO @SattusId,@Status

            WHILE @@FETCH_STATUS = 0
            BEGIN
	

                --select convert(varchar(12),orderdate,101) as odate from orders
        
                insert into #temptbl_ConsolidatedOrder_StatusParts
                select (select Decode from code where codeid = @SattusId)+'(Cur Month)' as status,(select  count(patient_procedure.statusid) as 
OrderCount from patient_procedure,orders  where patient_procedure.statusid = @SattusId  and patient_procedure.orderid = 
orders.orderid and  convert(varchar(12),orders.orderdate,101)  between convert(varchar(12),@From_Date,101) and 
convert(varchar(12),@To_Date,101) ) as [Count] --from code   patient_procedure.orderid = orders.orderid and
                --end

                FETCH NEXT FROM Order_Status_Partly INTO @SattusId,@Status

            END 
        CLOSE Order_Status_Partly
        DEALLOCATE Order_Status_Partly
    end

    select OrderStatus as Status,OrderCount as Total  from #temptbl_ConsolidatedOrder_StatusParts order by Status
    --drop table  #temptbl_ConsolidatedOrder_PendVsDisp

    












GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO



PRINT 'CREATING STORED PROCEDURE sp_USD_CEODashBoard_OrderStatusLastWeek'
SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO







--select * from orders



--exec sp_USD_CEODashBoard_OrderStatusBreakUp '01/06/06','06/06/06'

CREATE      procedure sp_USD_CEODashBoard_OrderStatusLastWeek
 as

declare  @From_Date   datetime
declare   @To_Date  datetime
set @From_Date = getdate()-7
set @To_Date = getdate()-14
    create table #temptbl_ConsolidatedOrder_StatusParts
    (
        OrderStatus varchar(50),
        OrderCount int
    )

    if @From_Date is not null and  @To_Date is not null
    begin
        declare Order_Status_Partly cursor for
        select CodeId,Decode from Code where TypeId = 7

        declare @SattusId int
        declare @Status varchar(50)


        OPEN Order_Status_Partly

        FETCH NEXT FROM Order_Status_Partly
        INTO @SattusId,@Status

            WHILE @@FETCH_STATUS = 0
            BEGIN
	

                --select convert(varchar(12),orderdate,101) as odate from orders
        
                insert into #temptbl_ConsolidatedOrder_StatusParts
                select (select Decode from code where codeid = @SattusId)+'(Last Week)' as status,(select  count(patient_procedure.statusid) as 
OrderCount from patient_procedure,orders  where patient_procedure.statusid = @SattusId  and patient_procedure.orderid = 
orders.orderid and  convert(varchar(12),orders.orderdate,101)  between convert(varchar(12),@From_Date,101) and 
convert(varchar(12),@To_Date,101) ) as [Count] --from code   patient_procedure.orderid = orders.orderid and
                --end

                FETCH NEXT FROM Order_Status_Partly INTO @SattusId,@Status

            END 
        CLOSE Order_Status_Partly
        DEALLOCATE Order_Status_Partly
    end

    --select OrderStatus as Status,OrderCount as Total  from #temptbl_ConsolidatedOrder_StatusParts
    --drop table  #temptbl_ConsolidatedOrder_PendVsDisp

    






set @From_Date = getdate()
set @To_Date = getdate()-7
    

    if @From_Date is not null and  @To_Date is not null
    begin
        declare Order_Status_Partly cursor for
        select CodeId,Decode from Code where TypeId = 7

      --  declare @SattusId int
        --declare @Status varchar(50)


        OPEN Order_Status_Partly

        FETCH NEXT FROM Order_Status_Partly
        INTO @SattusId,@Status

            WHILE @@FETCH_STATUS = 0
            BEGIN
	

                --select convert(varchar(12),orderdate,101) as odate from orders
        
                insert into #temptbl_ConsolidatedOrder_StatusParts
                select (select Decode from code where codeid = @SattusId)+'(Cur Week)' as status,(select  count(patient_procedure.statusid) as 
OrderCount from patient_procedure,orders  where patient_procedure.statusid = @SattusId  and patient_procedure.orderid = 
orders.orderid and  convert(varchar(12),orders.orderdate,101)  between convert(varchar(12),@From_Date,101) and 
convert(varchar(12),@To_Date,101) ) as [Count] --from code   patient_procedure.orderid = orders.orderid and
                --end

                FETCH NEXT FROM Order_Status_Partly INTO @SattusId,@Status

            END 
        CLOSE Order_Status_Partly
        DEALLOCATE Order_Status_Partly
    end

    select OrderStatus as Status,OrderCount as Total  from #temptbl_ConsolidatedOrder_StatusParts
    --drop table  #temptbl_ConsolidatedOrder_PendVsDisp

    











GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO



PRINT 'CREATING STORED PROCEDURE sp_USD_CEODashBoard_OrderStatusToday'
SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO





--select * from orders



--exec sp_USD_CEODashBoard_OrderStatusBreakUp '01/06/06','06/06/06'

CREATE    procedure sp_USD_CEODashBoard_OrderStatusToday

 as

declare  @From_Date   datetime
declare   @To_Date  datetime
set @From_Date = getdate()
set @To_Date = getdate()
    create table #temptbl_ConsolidatedOrder_StatusParts
    (
        OrderStatus varchar(50),
        OrderCount int
    )

    if @From_Date is not null and  @To_Date is not null
    begin
        declare Order_Status_Partly cursor for
        select CodeId,Decode from Code where TypeId = 7

        declare @SattusId int
        declare @Status varchar(50)


        OPEN Order_Status_Partly

        FETCH NEXT FROM Order_Status_Partly
        INTO @SattusId,@Status

            WHILE @@FETCH_STATUS = 0
            BEGIN
	

                --select convert(varchar(12),orderdate,101) as odate from orders
        
                insert into #temptbl_ConsolidatedOrder_StatusParts
                select (select Decode from code where codeid = @SattusId) as status,(select  count(patient_procedure.statusid) as 
OrderCount from patient_procedure,orders  where patient_procedure.statusid = @SattusId  and patient_procedure.orderid = 
orders.orderid and  convert(varchar(12),orders.orderdate,101)  between convert(varchar(12),@From_Date,101) and 
convert(varchar(12),@To_Date,101) ) as [Count] --from code   patient_procedure.orderid = orders.orderid and
                --end

                FETCH NEXT FROM Order_Status_Partly INTO @SattusId,@Status

            END 
        CLOSE Order_Status_Partly
        DEALLOCATE Order_Status_Partly
    end

    select OrderStatus as Status,OrderCount as Total  from #temptbl_ConsolidatedOrder_StatusParts
    --drop table  #temptbl_ConsolidatedOrder_PendVsDisp

    


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO



PRINT 'CREATING STORED PROCEDURE sp_USD_CEODashBoard_OrderStatusYestarday'
SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO





--select * from orders



--exec sp_USD_CEODashBoard_OrderStatusBreakUp '01/06/06','06/06/06'

create    procedure sp_USD_CEODashBoard_OrderStatusYestarday
 as

declare  @From_Date   datetime
declare   @To_Date  datetime
set @From_Date = getdate()-1
set @To_Date = getdate()-1
    create table #temptbl_ConsolidatedOrder_StatusParts
    (
        OrderStatus varchar(50),
        OrderCount int
    )

    if @From_Date is not null and  @To_Date is not null
    begin
        declare Order_Status_Partly cursor for
        select CodeId,Decode from Code where TypeId = 7

        declare @SattusId int
        declare @Status varchar(50)


        OPEN Order_Status_Partly

        FETCH NEXT FROM Order_Status_Partly
        INTO @SattusId,@Status

            WHILE @@FETCH_STATUS = 0
            BEGIN
	

                --select convert(varchar(12),orderdate,101) as odate from orders
        
                insert into #temptbl_ConsolidatedOrder_StatusParts
                select (select Decode from code where codeid = @SattusId) as status,(select  count(patient_procedure.statusid) as 
OrderCount from patient_procedure,orders  where patient_procedure.statusid = @SattusId  and patient_procedure.orderid = 
orders.orderid and  convert(varchar(12),orders.orderdate,101)  between convert(varchar(12),@From_Date,101) and 
convert(varchar(12),@To_Date,101) ) as [Count] --from code   patient_procedure.orderid = orders.orderid and
                --end

                FETCH NEXT FROM Order_Status_Partly INTO @SattusId,@Status

            END 
        CLOSE Order_Status_Partly
        DEALLOCATE Order_Status_Partly
    end

    select OrderStatus as Status,OrderCount as Total  from #temptbl_ConsolidatedOrder_StatusParts
    --drop table  #temptbl_ConsolidatedOrder_PendVsDisp

    


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO



PRINT 'CREATING STORED PROCEDURE sp_USD_CEODashBoard_OrdStatTodayVSYestarday'
SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO







--select * from orders



--exec sp_USD_CEODashBoard_OrdStatTodayVSYestarday

CREATE     procedure sp_USD_CEODashBoard_OrdStatTodayVSYestarday
 as

declare  @From_Date   datetime
declare   @To_Date  datetime
set @From_Date = getdate()
set @To_Date = getdate()
    create table #temptbl_ConsolidatedOrder_StatusParts
    (
        OrderStatus varchar(50),
        OrderCount int
    )

    if @From_Date is not null and  @To_Date is not null
    begin
        declare Order_Status_Partly cursor for
        select CodeId,Decode from Code where TypeId = 7

        declare @SattusId int
        declare @Status varchar(50)


        OPEN Order_Status_Partly

        FETCH NEXT FROM Order_Status_Partly
        INTO @SattusId,@Status

            WHILE @@FETCH_STATUS = 0
            BEGIN
	

                --select convert(varchar(12),orderdate,101) as odate from orders
        
                insert into #temptbl_ConsolidatedOrder_StatusParts
                select (select Decode from code where codeid = @SattusId)+'(Today)' as status,(select  count(patient_procedure.statusid) as 
OrderCount from patient_procedure,orders  where patient_procedure.statusid = @SattusId  and patient_procedure.orderid = 
orders.orderid and  convert(varchar(12),orders.orderdate,101)  between convert(varchar(12),@From_Date,101) and 
convert(varchar(12),@To_Date,101) ) as [Count] --from code   patient_procedure.orderid = orders.orderid and
                --end

                FETCH NEXT FROM Order_Status_Partly INTO @SattusId,@Status

            END 
        CLOSE Order_Status_Partly
        DEALLOCATE Order_Status_Partly
    end

    --select OrderStatus as Status,OrderCount as Total  from #temptbl_ConsolidatedOrder_StatusParts
    --drop table  #temptbl_ConsolidatedOrder_PendVsDisp

    




--declare  @From_Date   datetime
--declare   @To_Date  datetime
set @From_Date = getdate()-1
set @To_Date = getdate()-1
   /* create table #temptbl_ConsolidatedOrder_StatusParts
    (
        OrderStatus varchar(50),
        OrderCount int
    )*/

    if @From_Date is not null and  @To_Date is not null
    begin
        declare Order_Status_Partly cursor for
        select CodeId,Decode from Code where TypeId = 7

      --  declare @SattusId int
      --  declare @Status varchar(50)


        OPEN Order_Status_Partly

        FETCH NEXT FROM Order_Status_Partly
        INTO @SattusId,@Status

            WHILE @@FETCH_STATUS = 0
            BEGIN
	

                --select convert(varchar(12),orderdate,101) as odate from orders
        
                insert into #temptbl_ConsolidatedOrder_StatusParts
                select (select Decode from code where codeid = @SattusId)+'(Yestarday)' as status,(select  count(patient_procedure.statusid) as 
OrderCount from patient_procedure,orders  where patient_procedure.statusid = @SattusId  and patient_procedure.orderid = 
orders.orderid and  convert(varchar(12),orders.orderdate,101)  between convert(varchar(12),@From_Date,101) and 
convert(varchar(12),@To_Date,101) ) as [Count] --from code   patient_procedure.orderid = orders.orderid and
                --end

                FETCH NEXT FROM Order_Status_Partly INTO @SattusId,@Status

            END 
        CLOSE Order_Status_Partly
        DEALLOCATE Order_Status_Partly
    end

    select OrderStatus as Status,OrderCount as Total  from #temptbl_ConsolidatedOrder_StatusParts order by OrderStatus
    --drop table  #temptbl_ConsolidatedOrder_PendVsDisp

    












GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO



PRINT 'CREATING STORED PROCEDURE sp_USD_CeoDashBoard_Tech'
SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO





--exec sp_USD_CeoDashBoard_Tech 


CREATE   procedure sp_USD_CeoDashBoard_Tech
AS

	SELECT  con.FirstName [Technician], cod.Decode as [Type], 
		COUNT(CASE StatusId WHEN 26 THEN StatusId ELSE NULL END) AS [Pending],
		COUNT(CASE StatusId WHEN 27 THEN StatusId ELSE NULL END) AS [Dispathed],
		COUNT(CASE StatusId WHEN 25 THEN StatusId ELSE NULL END) AS [Closed]
	FROM Patient_Procedure pp INNER JOIN UserInfo ui ON pp.TechnicianID = ui.UserID 
		INNER JOIN Contact con ON ui.ContactID = con.ContactID 
		INNER JOIN Procedures p ON pp.ProcedureID = p.ProcedureID 
		INNER JOIN Code cod ON p.ProcedureCodeID = cod.CodeID
	GROUP BY cod.Decode, con.FirstName
	ORDER BY con.FirstName, cod.Decode
/*

SELECT  distinct    Code.Decode as [Type],Contact.FirstName [Technician],(select count(orderid) from Patient_Procedure where 
Patient_Procedure.statusid = 26) as [Curent Orders],(select count(orderid) from Patient_Procedure where Patient_Procedure.statusid = 25) 
as [Reported],
(select decode from code where codeid = Patient_Procedure.zoneid) as Territory

FROM         Patient_Procedure INNER JOIN
                      UserInfo ON Patient_Procedure.TechnicianID = UserInfo.UserID INNER JOIN
                      Contact ON UserInfo.ContactID = Contact.ContactID INNER JOIN
                      Procedures ON Patient_Procedure.ProcedureID = Procedures.ProcedureID INNER JOIN
                      Code ON Procedures.ProcedureCodeID = Code.CodeID
*/





GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO



PRINT 'CREATING STORED PROCEDURE sp_USD_Dispatch_OrdersDisp'
SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO



--------------------------------------------------

CREATE      procedure   sp_USD_Dispatch_OrdersDisp
	@From_Date varchar(10),
    	@To_Date varchar(10)
as

SELECT a.OrderNo, a.[Patient Name], a.[Test Name], a.[Test Type], a.[Order Date], a.[Order Time] 
FROM 
(SELECT DISTINCT Orders.OrderNo, Contact.FirstName AS [Patient Name], Procedures.Name AS [Test Name], Code.Decode AS [Test Type], 
	CONVERT(VARCHAR(10),Orders.OrderDate,101) AS [Order Date], SUBSTRING(CONVERT(VARCHAR(16), 
	Patient_Procedure.DueDate,120),12,5) AS [Order Time], OrderDate oOrderDate
FROM Orders INNER JOIN
	Patient_Procedure ON Orders.OrderID = Patient_Procedure.OrderID INNER JOIN
	Patient ON Patient_Procedure.PatientID = Patient.PatientID INNER JOIN
	Contact ON Patient.ContactID = Contact.ContactID INNER JOIN
	Procedures ON Patient_Procedure.ProcedureID = Procedures.ProcedureID INNER JOIN
	Code ON Procedures.ProcedureCodeID = Code.CodeID AND Patient_Procedure.StatusID = 27 and Patient_Procedure.IsActive = 1 and Patient_Procedure.IsActive = 1
and convert(varchar(10),orders.orderdate, 120)  between 
@From_Date and @To_Date) a
ORDER BY a.oOrderDate DESC



GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO



PRINT 'CREATING STORED PROCEDURE sp_USD_Dispatch_Tech'
SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO






--exec sp_USD_CeoDashBoard_Tech 


create    procedure sp_USD_Dispatch_Tech
AS

	SELECT  con.FirstName [Technician], cod.Decode as [Type], 
		COUNT(CASE StatusId WHEN 26 THEN StatusId ELSE NULL END) AS [Pending],
		COUNT(CASE StatusId WHEN 27 THEN StatusId ELSE NULL END) AS [Dispathed],
		COUNT(CASE StatusId WHEN 25 THEN StatusId ELSE NULL END) AS [Closed]
	FROM Patient_Procedure pp INNER JOIN UserInfo ui ON pp.TechnicianID = ui.UserID 
		INNER JOIN Contact con ON ui.ContactID = con.ContactID 
		INNER JOIN Procedures p ON pp.ProcedureID = p.ProcedureID 
		INNER JOIN Code cod ON p.ProcedureCodeID = cod.CodeID 
	GROUP BY cod.Decode, con.FirstName
	ORDER BY con.FirstName, cod.Decode
/*

SELECT  distinct    Code.Decode as [Type],Contact.FirstName [Technician],(select count(orderid) from Patient_Procedure where 
Patient_Procedure.statusid = 26) as [Curent Orders],(select count(orderid) from Patient_Procedure where Patient_Procedure.statusid = 25) 
as [Reported],
(select decode from code where codeid = Patient_Procedure.zoneid) as Territory

FROM         Patient_Procedure INNER JOIN
                      UserInfo ON Patient_Procedure.TechnicianID = UserInfo.UserID INNER JOIN
                      Contact ON UserInfo.ContactID = Contact.ContactID INNER JOIN
                      Procedures ON Patient_Procedure.ProcedureID = Procedures.ProcedureID INNER JOIN
                      Code ON Procedures.ProcedureCodeID = Code.CodeID
*/






GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO



PRINT 'CREATING STORED PROCEDURE sp_USD_DispatchOrdersPend'
SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO


CREATE     procedure sp_USD_DispatchOrdersPend
	@From_Date varchar(10),
    	@To_Date varchar(10)
as

SELECT a.OrderNo, a.[Patient Name], a.[Test Name], a.[Test Type], a.[Order Date], a.[Order Time]
FROM
(SELECT DISTINCT Orders.OrderNo, Contact.FirstName AS [Patient Name], Procedures.Name AS [Test Name], 
	Code.Decode AS [Test Type], CONVERT(VARCHAR(10),Orders.OrderDate,101) AS [Order Date], 
	SUBSTRING(CONVERT(VARCHAR(16), Patient_Procedure.DueDate,120),12,5) AS [Order Time],
	Orders.OrderDate
FROM Orders INNER JOIN
	Patient_Procedure ON Orders.OrderID = Patient_Procedure.OrderID INNER JOIN
	Patient ON Patient_Procedure.PatientID = Patient.PatientID INNER JOIN
	Contact ON Patient.ContactID = Contact.ContactID INNER JOIN
	Procedures ON Patient_Procedure.ProcedureID = Procedures.ProcedureID INNER JOIN
	Code ON Procedures.ProcedureCodeID = Code.CodeID AND Patient_Procedure.StatusID = 26 and Patient_Procedure.IsActive = 1
AND
	convert(varchar(10),orders.orderdate,120)  between 
	@From_Date and @To_Date) a
ORDER BY a.OrderDate DESC


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO



PRINT 'CREATING STORED PROCEDURE sp_USD_OrdersReport'
SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

CREATE procedure sp_USD_OrdersReport
--sp_USD_OrderReports '06/01/06', '06/06/06'
    @From_Date varchar(12),
    @To_Date varchar(12)
as
    SELECT DISTINCT  Orders.OrderNo as [Order No],convert(varchar(12),Orders.OrderDate,101) AS [Date], Contact.FirstName AS 
[Name], (SELECT DISTINCT isnull(Contact.FirstName, '') + ' ' + isnull(Contact.MiddleName, '') + ' ' + isnull(Contact.LastName, '') from 
contact where contact.contactid = 	(select contactid from userinfo where userinfo.userid = patient_procedure.technicianid)) as Technician,  Procedures.Name AS [Prcedures], 
                           ( select Decode from code where code.codeid = Patient_Procedure.StatusID ) as [Status]
    FROM         Orders INNER JOIN
                          Patient_Procedure ON Orders.OrderID = Patient_Procedure.OrderID INNER JOIN
                          Patient ON Patient_Procedure.PatientID = Patient.PatientID INNER JOIN
                          Contact ON Patient.ContactID = Contact.ContactID INNER JOIN
                          Procedures ON Patient_Procedure.ProcedureID = Procedures.ProcedureID INNER JOIN
                          Code ON Procedures.ProcedureCodeID = Code.CodeID  and  convert(varchar(12),orders.orderdate,101)  between 
convert(varchar(12),@From_Date,101) and convert(varchar(12),@To_Date,101) and Patient_Procedure.IsActive = 1 and Orders.IsActive = 1


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO



PRINT 'CREATING STORED PROCEDURE sp_USD_TechnicianRpt'
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


CREATE  procedure sp_USD_TechnicianRpt
-- sp_USD_TechnicianRpt '2006-06-24','2006-06-27'
	@From_Date DATETIME,
	@To_Date DATETIME
    --@TechnicianId int
as


	SELECT tTechnicianId as Technicianid, tName Technician, tOrderDate as [Date], tCount as [Total Procedures],
		tComp as [Completed], tPend as [Pending]
	FROM  
		(SELECT DISTINCT pp.TechnicianId tTechnicianId, c.FirstName tName, o.OrderDate tOrderDate
		FROM Patient_Procedure pp INNER JOIN Orders o ON pp.OrderId=o.OrderId 
			LEFT OUTER JOIN UserInfo ui ON pp.TechnicianId=ui.UserId
			LEFT OUTER JOIN Contact c ON ui.ContactId=c.ContactId
		WHERE pp.IsActive=1 AND o.IsActive=1 AND CONVERT(VARCHAR(10),o.OrderDate,120) BETWEEN CONVERT(VARCHAR(10),@From_Date,120) 
			AND CONVERT(VARCHAR(10),@To_Date,120)) t
		LEFT OUTER JOIN 
		(SELECT pp.TechnicianId cTechnicianId, pp.DueDate tDueDate, COUNT(*) tCount, 
			COUNT(CASE WHEN pp.StatusId=25 THEN 1 ELSE NULL END) tComp,
			COUNT(CASE WHEN pp.StatusId=27 THEN 1 ELSE NULL END) tPend
		FROM Patient_Procedure pp 
		WHERE pp.IsActive=1 AND CONVERT(VARCHAR(10),pp.DueDate,120) BETWEEN CONVERT(VARCHAR(10),@From_Date,120) 
			AND CONVERT(VARCHAR(10),@To_Date,120)
		GROUP BY pp.TechnicianId, pp.DueDate) c
		ON t.tTechnicianId=c.cTechnicianId AND t.tOrderDate=c.tDueDate
	


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO



PRINT 'CREATING STORED PROCEDURE sp_USD_TechnicianStatusRpt'
SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

CREATE procedure sp_USD_TechnicianStatusRpt
--sp_USD_TechnicianRpt '06/01/06', '06/06/06'
	@TechnicianId VARCHAR(50),
	@From_Date DATETIME,
	@To_Date DATETIME
as
	SELECT DISTINCT 
                      Orders.OrderNo as [Order No],convert(varchar(12),Orders.OrderDate,101) AS [Date], 
			Contact.FirstName AS [Name],
			Contact.FirstName AS 
[Name],(SELECT DISTINCT isnull(Contact.FirstName, '') + ' ' + isnull(Contact.MiddleName, '') + ' ' + isnull(Contact.LastName, '') from 
contact where contact.contactid = 	(select contactid from userinfo where userinfo.userid = patient_procedure.technicianid)) as 
Technician, 
			Procedures.Name AS [Prcedures], 
                       ( select Decode from code where code.codeid = Patient_Procedure.StatusID ) as [Status]
	FROM  Orders INNER JOIN Patient_Procedure ON Orders.OrderID = Patient_Procedure.OrderID 
		INNER JOIN Patient ON Patient_Procedure.PatientID = Patient.PatientID 
		INNER JOIN Contact ON Patient.ContactID = Contact.ContactID 
		INNER JOIN Procedures ON Patient_Procedure.ProcedureID = Procedures.ProcedureID 
		INNER JOIN Code ON Procedures.ProcedureCodeID = Code.CodeID 
	AND convert(varchar(10),orders.orderdate,120)  between 
				convert(varchar(10),@From_Date,120) and convert(varchar(10),@To_Date,120) 
			and Patient_Procedure.TechnicianId = @TechnicianId and Patient_Procedure.IsActive = 1 
			and Orders.IsActive = 1



GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO



PRINT 'CREATING STORED PROCEDURE usp_UpdatePatientProcedure'
SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

CREATE  PROCEDURE usp_UpdatePatientProcedure (@inXmlDoc text)
AS
BEGIN
	DECLARE @strOrderId VARCHAR(50)
	DECLARE @idoc int

	EXEC sp_xml_preparedocument @idoc OUTPUT, @inXmlDoc
	SELECT * INTO #tblInTable FROM OPENXML (@idoc, '/NewDataSet/Procedure',2)
            	WITH (PatientID  VARCHAR(50), ProcedureID VARCHAR(50), OrderID VARCHAR(50), TechnicianID VARCHAR(50),
			DueDate VARCHAR(25), PriorityID INT, Comments VARCHAR(255), StatusID INT, OrderTyp INT, IsActive TINYINT)

	UPDATE #tblInTable SET DueDate=REPLACE(DueDate, 'T', ' ')

	SELECT TOP 1 @strOrderId = OrderId FROM #tblInTable

	-- Deleted records
	UPDATE Patient_Procedure SET IsActive=0
	FROM Patient_Procedure pp INNER JOIN
--	SELECT * FROM 
	(SELECT pp.*
	FROM Patient_Procedure pp WHERE pp.OrderId = @strOrderId AND pp.IsActive = 1
		AND pp.ProcedureId NOT IN
		(SELECT it.ProcedureId FROM #tblInTable it WHERE it.OrderId=pp.OrderId AND it.PatientId=pp.PatientId)) d
	ON pp.IsActive=1 AND pp.OrderId=d.OrderId AND pp.ProcedureId=d.ProcedureId AND pp.PatientId=d.PatientId

/*	-- Exist records
	UPDATE Patient_Procedure SET  
		DueDate =CAST (SUBSTRING(u.DueDate,1,19) AS DATETIME), PriorityID = u.PriorityId, 
		Comments = u.Comments, StatusID = u.StatusId, OrderTyp = u.OrderTyp
	FROM Patient_Procedure pp INNER JOIN
--	SELECT * FROM
	(SELECT it.*
	FROM #tblInTable it INNER JOIN Patient_Procedure pp ON it.OrderId=pp.OrderId AND it.PatientId=pp.PatientId
		AND it.ProcedureId=pp.ProcedureId AND pp.IsActive=1) u
	ON pp.IsActive=1 AND pp.OrderId=u.OrderId AND pp.ProcedureId=u.ProcedureId AND pp.PatientId=u.PatientId
*/
	-- Not existed records 
	INSERT INTO Patient_Procedure (PatientId, ProcedureId, OrderId, /*TechnicianId,*/ DueDate, 
		TestDate, PriorityId, ZoneId, Comments, StatusId, 
		OrderTyp, IsActive)
	SELECT n.PatientId, n.ProcedureId, n.OrderId, /*n.TechnicianId, CAST (SUBSTRING(n.DueDate,1,19) AS DATETIME)*/ getdate() ,
		null, n.PriorityId, null, n.Comments, n.StatusId, n.OrderTyp, 1 FROM
	(SELECT it.*
	FROM #tblInTable it WHERE it.ProcedureId NOT IN 
		(SELECT pp.ProcedureId FROM Patient_Procedure pp 
		WHERE it.OrderId=pp.OrderId AND it.PatientId=pp.PatientId AND pp.IsActive=1)) n

END

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO



