USE [master]

IF EXISTS (SELECT name FROM master.dbo.sysdatabases WHERE name = N'USD')
	DROP DATABASE [USD]
GO

CREATE DATABASE [USD]
GO
