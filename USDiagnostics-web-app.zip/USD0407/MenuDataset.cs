using System;
using System.Xml.Serialization;
using System.Collections;

namespace Zaxis.USD.Web.UI.Components.Navigation
{
	/// <summary>
	/// Option used when merging to determine where to merge data.
	/// </summary>
	public enum MergeLocation
	{
		Before,
		After
	}
	
	[XmlRoot("SectionInfo", Namespace="", IsNullable=false)]
	public class MenuDataSet : ICloneable
	{
	    
		[XmlElement("Section")]
		public MenuSection[] Sections;

		/// <summary>
		/// Merges the provided data set with this dataset placing the sections before or after
		/// the existing data.
		/// </summary>
		/// <param name="ds">The data set to merge with.</param>
		/// <param name="opt">The location where to merge the provided data.</param>
		public void Merge(MenuDataSet ds, MergeLocation opt)
		{
			//check for nulls
			if (ds.Sections == null || ds.Sections.Length == 0)
				return;
			
			//check for nulls
			if (Sections == null || Sections.Length == 0)
			{
				Sections = (MenuSection[])ds.Sections.Clone();
				return;
			}
			
			//create new array
			MenuSection[] newItems = new MenuSection[Sections.Length + ds.Sections.Length];
			switch(opt)
			{
				case MergeLocation.Before:
					Array.Copy(ds.Sections, 0, newItems, 0, ds.Sections.Length);
					Array.Copy(Sections, 0, newItems, ds.Sections.Length, Sections.Length);
					break;

				case MergeLocation.After:
					Array.Copy(Sections, 0, newItems, 0, Sections.Length);
					Array.Copy(ds.Sections, 0, newItems, Sections.Length, ds.Sections.Length);
					break;
			}

			this.Sections = newItems;
		}

		/// <summary>
		/// Copy all data set elements
		/// </summary>
		/// <returns>A copy of this data set</returns>
		public object Clone()
		{
			MenuDataSet ds = new MenuDataSet();
			if (Sections != null)
			{
				ds.Sections = new MenuSection[Sections.Length];
				for(int i = 0; i < Sections.Length; ++i)
					ds.Sections[i] = (MenuSection)Sections[i].Clone();
			}
			return ds;
		}
	}

	/// <remarks/>
	public class MenuSection : ICloneable
	{	    
		/// <remarks/>
		[XmlElement("SubSection")]
		public MenuSubSection[] SubSections;
	    
		/// <remarks/>
		[XmlAttribute()]
		public string Caption;
	    
		/// <remarks/>
		[XmlAttribute()]
		public bool New;
	    
		/// <remarks/>
		[XmlAttribute()]
		public bool External; 

		/// <remarks/>
		[XmlAttribute()]
		public bool Visible = true;
       
		public object Clone()
		{
			MenuSection sec = new MenuSection();
			if (SubSections != null)
			{
				sec.SubSections = new MenuSubSection[SubSections.Length];
				for(int i = 0; i < SubSections.Length; ++i)
					sec.SubSections[i] = (MenuSubSection)SubSections[i].Clone();
			}
			sec.Caption = this.Caption;
			sec.New = this.New;
			sec.External = this.External;
			sec.Visible = this.Visible;
			return sec;
		}

		public IEnumerator GetEnumerator() 
		{
			return new MenuSectionEnumerator( this );
		}

	}

	/// <remarks/>
	public class MenuSubSection : ICloneable
	{
	    
		/// <remarks/>
		[XmlElement("Item")]
		public MenuItem[] Items;
	    
		/// <remarks/>
		[XmlAttribute()]
		public string Caption;
	    
		/// <remarks/>
		[XmlAttribute()]
		public bool New;
	    
		/// <remarks/>
		[XmlAttribute()]
		public bool External;

		/// <remarks/>
		[XmlAttribute()]
		public bool Visible = true;
        
		/// <summary>
		/// Copy menu section
		/// </summary>
		/// <returns>A copy of the menu section</returns>
		public object Clone()
		{
			MenuSubSection sub = new MenuSubSection();
			if (Items != null)
			{
				sub.Items = new MenuItem[Items.Length];
				for(int i = 0; i < Items.Length; ++i)
					sub.Items[i] = (MenuItem)Items[i].Clone();
			}
			sub.Caption = this.Caption;
			sub.New = this.New;
			sub.External = this.External;
			sub.Visible = this.Visible;
			return sub;
		}

		public IEnumerator GetEnumerator() 
		{
			return new MenuSubSectionEnumerator( this );
		}

	}

	/// <remarks/>
	public class MenuItem : ICloneable 
	{	    
		/// <remarks/>
		[XmlAttribute()]
		public string Url;
	    
		/// <remarks/>
		[XmlAttribute()]
		public string Caption;
	    
		/// <remarks/>
		[XmlAttribute()]
		public bool New;
	    
		/// <remarks/>
		[XmlAttribute()]
		public bool External;

		/// <remarks/>
		[XmlAttribute()]
		public bool Visible = true;
          
		/// <summary>
		/// Copy menu item
		/// </summary>
		/// <returns>A copy of the menu item</returns>
		public object Clone()
		{
			MenuItem item = new MenuItem();
			item.Url = this.Url;
			item.Caption = this.Caption;
			item.New = this.New;
			item.External = this.External;
			item.Visible = this.Visible;
			return item;
		}
	}

	public class MenuSubSectionEnumerator : IEnumerator 
	{

		private MenuSubSection _mss = null;
		private int _index;

		public MenuSubSectionEnumerator( MenuSubSection mss ) 
		{
			_mss = mss;
			_index = -1;
		}

		public object Current 
		{

			get 
			{
			
				object current = null;

				if ( _index != -1 && _index < _mss.Items.Length ) 
				{
					current = _mss.Items[ _index ];
				}

				return current;
			
			}

		}

		public bool MoveNext() 
		{
			
			if ( ++_index >= _mss.Items.Length ) 
			{
			
				_index = 0;
				return false;
			
			} 
			else 
			{
				return true;
			}

		}

		public void Reset() 
		{
			_index = -1;
		}
		
	}

	public class MenuSectionEnumerator : IEnumerator 
	{

		private MenuSection _ms = null;
		private int _index;

		public MenuSectionEnumerator( MenuSection ms ) 
		{
			_ms = ms;
			_index = -1;
		}

		public object Current 
		{

			get 
			{
			
				object current = null;

				if ( _index != -1 && _index < _ms.SubSections.Length ) 
				{
					current = _ms.SubSections[ _index ];
				}

				return current;
			
			}

		}

		public bool MoveNext() 
		{
			
			if ( ++_index >= _ms.SubSections.Length ) 
			{
			
				_index = 0;
				return false;
			
			} 
			else 
			{
				return true;
			}

		}

		public void Reset() 
		{
			_index = -1;
		}
		
	}

}	
